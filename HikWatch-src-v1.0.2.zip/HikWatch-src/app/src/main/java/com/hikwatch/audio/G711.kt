package com.hikwatch.audio

/**
 * G.711 编解码（海康默认音频编码）。
 * μ-law / A-law -> 16bit 线性 PCM，纯函数，便于单元测试。
 */
object G711 {

    /** μ-law (PCMU, payload type 0) */
    fun ulawToLinear(value: Int): Int {
        val u = value.inv() and 0xFF
        var t = ((u and 0x0F) shl 3) + 0x84
        t = t shl ((u and 0x70) shr 4)
        return if ((u and 0x80) != 0) 0x84 - t else t - 0x84
    }

    /** A-law (PCMA, payload type 8) */
    fun alawToLinear(value: Int): Int {
        val a = value xor 0x55
        var t = (a and 0x0F) shl 4
        val seg = (a and 0x70) shr 4
        when (seg) {
            0 -> t += 8
            1 -> t += 0x108
            else -> {
                t += 0x108
                t = t shl (seg - 1)
            }
        }
        return if ((a and 0x80) != 0) t else -t
    }

    /** 整块解码：把 G.711 字节流解成 PCM16 小端字节流 */
    fun decodeToPcm16(data: ByteArray, offset: Int, length: Int, alaw: Boolean, out: ShortArray): Int {
        val n = minOf(length, out.size)
        for (i in 0 until n) {
            val b = data[offset + i].toInt() and 0xFF
            out[i] = (if (alaw) alawToLinear(b) else ulawToLinear(b)).toShort()
        }
        return n
    }
}
