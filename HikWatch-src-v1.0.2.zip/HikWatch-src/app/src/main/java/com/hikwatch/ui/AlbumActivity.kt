package com.hikwatch.ui

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hikwatch.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 相册：浏览 App 保存的截图与录像 */
class AlbumActivity : Activity() {

    private data class Item(val uri: Uri, val video: Boolean, val name: String, val date: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var gridBox: LinearLayout
    private lateinit var countLabel: TextView
    private lateinit var emptyLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildRoot())
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        head.addView(Ui.label(this, "相册", 13f, Ui.TEXT, bold = true))
        countLabel = Ui.label(this, "", 8.5f, Ui.TEXT3)
        head.addView(countLabel)
        root.addView(
            head,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@AlbumActivity, 16f) }
        )

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(gridBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@AlbumActivity, 48f)
                bottomMargin = Ui.dp(this@AlbumActivity, 46f)
                leftMargin = Ui.dp(this@AlbumActivity, 24f)
                rightMargin = Ui.dp(this@AlbumActivity, 24f)
            }
        )

        emptyLabel = Ui.label(this, "还没有截图或录像\n在观看页点相机 / 录制", 9f, Ui.TEXT3)
        emptyLabel.gravity = Gravity.CENTER
        emptyLabel.visibility = View.GONE
        root.addView(
            emptyLabel,
            FrameLayout.LayoutParams(
                Ui.dp(this, 170f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        val back = Ui.iconButton(this, R.drawable.ic_back, 32f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 32f),
                Ui.dp(this, 32f),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@AlbumActivity, 6f) }
        )
        return root
    }

    private fun load() {
        scope.launch {
            val items = withContext(Dispatchers.IO) { query() }
            render(items)
        }
    }

    private fun query(): List<Item> {
        val result = ArrayList<Item>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED
        )
        val selection = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?"
        runCatching {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, selection, arrayOf("Pictures/HikWatch%"),
                MediaStore.MediaColumns.DATE_ADDED + " DESC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val name = cursor.getString(1) ?: "截图"
                    val date = cursor.getLong(2)
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    result.add(Item(uri, false, name, date))
                }
            }
        }
        runCatching {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, selection, arrayOf("Movies/HikWatch%"),
                MediaStore.MediaColumns.DATE_ADDED + " DESC"
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val name = cursor.getString(1) ?: "录像"
                    val date = cursor.getLong(2)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    result.add(Item(uri, true, name, date))
                }
            }
        }
        return result.sortedByDescending { it.date }
    }

    private fun render(items: List<Item>) {
        gridBox.removeAllViews()
        countLabel.text = items.size.toString() + " 个文件"
        emptyLabel.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (items.isEmpty()) return

        var row: LinearLayout? = null
        items.forEachIndexed { index, item ->
            if (index % 3 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                gridBox.addView(
                    row,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        Ui.dp(this, 62f)
                    ).apply { bottomMargin = Ui.dp(this@AlbumActivity, 6f) }
                )
            }
            val cell = buildCell(item)
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            params.leftMargin = Ui.dp(this, 3f)
            params.rightMargin = Ui.dp(this, 3f)
            row?.addView(cell, params)
        }
    }

    private fun buildCell(item: Item): View {
        val cell = FrameLayout(this)
        cell.background = Ui.solid(Ui.PANEL, Ui.dp(this, 12f).toFloat())
        cell.clipToOutline = true
        cell.isClickable = true
        val image = ImageView(this)
        image.scaleType = ImageView.ScaleType.CENTER_CROP
        cell.addView(
            image,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        if (item.video) {
            val badge = Ui.label(this, "▶", 10f, Ui.TEXT, bold = true)
            badge.setShadowLayer(3f, 0f, 1f, android.graphics.Color.BLACK)
            cell.addView(
                badge,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }
        cell.setOnClickListener { open(item) }
        scope.launch {
            val thumb = withContext(Dispatchers.IO) { thumbnail(item.uri) }
            if (thumb != null) image.setImageBitmap(thumb)
        }
        return cell
    }

    private fun thumbnail(uri: Uri): Bitmap? = runCatching {
        contentResolver.loadThumbnail(uri, Size(120, 120), null)
    }.getOrNull()

    private fun open(item: Item) {
        if (item.video) {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(item.uri, "video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            runCatching { startActivity(intent) }.onFailure {
                Ui.showMessage(this, "无法播放", "手表上没有可用的视频播放器。\n文件已在相册 Movies/HikWatch。")
            }
        } else {
            startActivity(Intent(this, ImageViewerActivity::class.java).setData(item.uri))
        }
    }
}

/** 截图全屏查看 */
class ImageViewerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(android.graphics.Color.BLACK)
        val image = ImageView(this)
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(
            image,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        intent.data?.let { uri ->
            runCatching {
                contentResolver.openInputStream(uri)?.use { stream ->
                    image.setImageBitmap(android.graphics.BitmapFactory.decodeStream(stream))
                }
            }
        }
        val back = Ui.iconButton(this, R.drawable.ic_back, 30f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 30f),
                Ui.dp(this, 30f),
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = Ui.dp(this@ImageViewerActivity, 4f) }
        )
        setContentView(root)
    }
}
