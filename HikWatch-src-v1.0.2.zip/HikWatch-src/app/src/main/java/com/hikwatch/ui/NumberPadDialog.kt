package com.hikwatch.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.ViewGroup
import android.view.Window
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 表盘数字键盘（毛玻璃）：比系统输入法更适合 1.5 英寸圆屏输入 IP / 端口 / 通道号。
 */
class NumberPadDialog(
    context: Context,
    private val title: String,
    initial: String,
    private val allowDot: Boolean,
    private val maxLength: Int,
    private val onResult: (String) -> Unit
) : Dialog(context) {

    private val contextRef = context
    private val buffer = StringBuilder(initial)
    private val display: TextView = Ui.label(context, "", 19f, Ui.TEXT, bold = true)

    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 8f), Ui.dp(context, 8f), Ui.dp(context, 8f), Ui.dp(context, 8f))
            background = Ui.glassPanel(context, 28f, Ui.PANEL_SOLID)
        }

        val head = Ui.label(context, title, 9.5f, Ui.TEXT3)
        head.gravity = Gravity.CENTER
        head.letterSpacing = 0.1f
        root.addView(head, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            Ui.dp(context, 13f)
        ))

        display.gravity = Gravity.CENTER
        display.letterSpacing = 0.06f
        display.background = Ui.solid(Ui.BG, Ui.dp(context, 13f).toFloat(), Ui.STROKE, Ui.dp(context, 1f).toFloat())
        root.addView(
            display,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(context, 22f)).apply {
                topMargin = Ui.dp(context, 4f)
                bottomMargin = Ui.dp(context, 5f)
            }
        )

        val keys = GridLayout(context).apply { columnCount = 3 }
        val labels = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", if (allowDot) "." else "", "0", "⌫")
        for ((index, text) in labels.withIndex()) {
            val cell = Ui.label(context, text, 13.5f, Ui.TEXT, bold = true)
            cell.gravity = Gravity.CENTER
            if (text.isNotEmpty()) {
                cell.background = Ui.ripple(Ui.solid(Ui.PANEL, Ui.dp(context, 11f).toFloat()))
                cell.isClickable = true
                cell.setOnClickListener { press(text) }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(index / 3),
                GridLayout.spec(index % 3)
            )
            params.width = Ui.dp(context, 30f)
            params.height = Ui.dp(context, 23f)
            params.setMargins(
                Ui.dp(context, 2f), Ui.dp(context, 2f),
                Ui.dp(context, 2f), Ui.dp(context, 2f)
            )
            keys.addView(cell, params)
        }
        root.addView(keys)

        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val cancel = Ui.label(context, "取消", 11f, Ui.TEXT2, bold = true)
        cancel.gravity = Gravity.CENTER
        cancel.background = Ui.ripple(Ui.solid(Ui.GLASS, Ui.dp(context, 12f).toFloat()))
        cancel.isClickable = true
        cancel.setOnClickListener { dismiss() }

        val ok = Ui.label(context, "确定", 11f, Ui.ACCENT_DARK, bold = true)
        ok.gravity = Gravity.CENTER
        ok.background = Ui.accentRipple(Ui.solid(Ui.ACCENT, Ui.dp(context, 12f).toFloat()))
        ok.isClickable = true
        ok.setOnClickListener {
            if (buffer.isNotEmpty()) {
                dismiss()
                onResult(buffer.toString())
            }
        }

        val rowParams = LinearLayout.LayoutParams(0, Ui.dp(context, 27f), 1f)
        actions.addView(cancel, LinearLayout.LayoutParams(rowParams).apply {
            rightMargin = Ui.dp(context, 5f)
        })
        actions.addView(ok, rowParams)
        root.addView(
            actions,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = Ui.dp(context, 4f) }
        )

        setContentView(root)
        updateDisplay()
        Ui.applyGlassWindow(this, 20f)
    }

    private fun press(key: String) {
        val view = window?.decorView
        view?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        when (key) {
            "⌫" -> if (buffer.isNotEmpty()) buffer.deleteCharAt(buffer.length - 1)
            "." -> if (allowDot && !buffer.contains(".") && buffer.isNotEmpty()) buffer.append('.')
            else -> if (buffer.length < maxLength) buffer.append(key)
        }
        updateDisplay()
    }

    private fun updateDisplay() {
        display.text = if (buffer.isEmpty()) "—" else buffer.toString()
    }

    fun showPad() {
        show()
        window?.setLayout(Ui.dp(contextRef, 126f), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
