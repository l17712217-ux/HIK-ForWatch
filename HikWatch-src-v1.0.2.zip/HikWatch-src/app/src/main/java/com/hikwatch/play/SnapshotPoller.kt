package com.hikwatch.play

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.hikwatch.model.Camera
import com.hikwatch.net.DigestHttp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 抓拍模式：当 RTSP 连不上时，用 ISAPI 连续抓图（JPEG）做低帧率预览。
 * 海康 ISAPI 支持摘要认证，兼容性最好。
 */
class SnapshotPoller(
    private val camera: Camera,
    private val intervalMs: Long = 450,
    private val callback: Callback
) {

    interface Callback {
        fun onFrame(bitmap: Bitmap)
        fun onError(message: String)
    }

    private var job: Job? = null
    private val http = DigestHttp(camera.user, camera.pass)

    fun start(scope: CoroutineScope) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            var failures = 0
            var reported = false
            while (isActive) {
                val started = System.currentTimeMillis()
                val result = http.get(camera.snapshotUrl(), 5000)
                if (result.code == 200 && result.body.size > 200) {
                    val bitmap = runCatching {
                        BitmapFactory.decodeByteArray(result.body, 0, result.body.size)
                    }.getOrNull()
                    if (bitmap != null) {
                        failures = 0
                        reported = false
                        withContext(Dispatchers.Main) { callback.onFrame(bitmap) }
                    } else {
                        failures++
                    }
                } else {
                    failures++
                    if (failures >= 3 && !reported) {
                        reported = true
                        val message = when {
                            result.code == 401 -> "抓拍认证失败"
                            result.code == 0 -> "网络异常：${result.error}"
                            else -> "抓拍失败：HTTP ${result.code}"
                        }
                        withContext(Dispatchers.Main) { callback.onError(message) }
                    }
                }
                val spent = System.currentTimeMillis() - started
                delay((intervalMs - spent).coerceAtLeast(80))
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }
}
