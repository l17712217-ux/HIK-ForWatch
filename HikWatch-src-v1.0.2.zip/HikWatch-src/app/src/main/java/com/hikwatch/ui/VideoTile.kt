package com.hikwatch.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 单路画面容器：TextureView（实时）或 ImageView（抓拍）。
 * 支持：画面比例（撑满/完整/16:9/4:3/自定义）、捏合缩放、双击、拖动、左右滑动切换、紧凑模式。
 */
@SuppressLint("ViewConstructor")
class VideoTile(context: Context) : FrameLayout(context) {

    val texture = TextureView(context)
    val image = ImageView(context)
    private val nameLabel = TextView(context)
    private val statusLabel = TextView(context)
    private val badgeLabel = TextView(context)

    private var videoAspect: Float = 16f / 9f

    /** true：画面完整落在圆屏内接区域（单路放大 + 完整画面时用） */
    var inscribed: Boolean = false

    /** 是否按「撑满」裁切（由 applyAspect 维护，保留旧字段兼容） */
    var fillScreen: Boolean = false

    var zoomEnabled: Boolean = false
    var swipeEnabled: Boolean = false
    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null

    /** +1 左滑（下一台），-1 右滑（上一台） */
    var onSwipe: ((Int) -> Unit)? = null

    /** 紧凑模式：6/9 宫格时隐藏名字，缩小状态字 */
    var compact: Boolean = false
        set(value) {
            field = value
            applyCompact()
        }

    private var aspectMode: String = "fill"
    private var ratio: Float = 0f

    private var scaleFactor = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var childWidth = 0
    private var childHeight = 0

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (!zoomEnabled) return false
                scaleFactor = (scaleFactor * detector.scaleFactor).coerceIn(1f, 5f)
                clampOffsets()
                applyTransform()
                return true
            }
        }
    )

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onTap?.invoke()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                onLongPress?.invoke()
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!zoomEnabled) return false
                if (scaleFactor > 1.05f) {
                    scaleFactor = 1f
                    offsetX = 0f
                    offsetY = 0f
                } else {
                    scaleFactor = 2.5f
                }
                clampOffsets()
                applyTransform()
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (!zoomEnabled || scaleFactor <= 1.01f) return false
                offsetX -= distanceX
                offsetY -= distanceY
                clampOffsets()
                applyTransform()
                return true
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (!swipeEnabled || !zoomEnabled && scaleFactor > 1.05f) return false
                if (scaleFactor > 1.05f || e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > abs(dy) * 1.6f && abs(dx) > Ui.dp(context, 30f)) {
                    onSwipe?.invoke(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        }
    )

    init {
        setBackgroundColor(Color.BLACK)
        clipChildren = true
        clipToPadding = true

        image.visibility = View.GONE
        image.scaleType = ImageView.ScaleType.MATRIX
        addView(image, LayoutParams(1, 1))
        addView(texture, LayoutParams(1, 1))

        nameLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        nameLabel.setTextColor(Color.WHITE)
        nameLabel.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        nameLabel.maxLines = 1
        nameLabel.background = Ui.solid(Color.argb(120, 6, 10, 16), Ui.dp(context, 7f).toFloat())
        nameLabel.setPadding(
            Ui.dp(context, 6f), Ui.dp(context, 2f),
            Ui.dp(context, 6f), Ui.dp(context, 2f)
        )
        addView(
            nameLabel,
            LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply {
                leftMargin = Ui.dp(context, 7f)
                topMargin = Ui.dp(context, 6f)
            }
        )

        statusLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        statusLabel.setTextColor(Ui.TEXT2)
        statusLabel.gravity = Gravity.CENTER
        statusLabel.background = Ui.solid(Color.argb(96, 4, 7, 12), Ui.dp(context, 10f).toFloat())
        statusLabel.setPadding(
            Ui.dp(context, 8f), Ui.dp(context, 3f),
            Ui.dp(context, 8f), Ui.dp(context, 3f)
        )
        statusLabel.visibility = View.GONE
        addView(
            statusLabel,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )

        badgeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8f)
        badgeLabel.setTextColor(Ui.WARN)
        badgeLabel.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        badgeLabel.visibility = View.GONE
        badgeLabel.background = Ui.solid(Color.argb(120, 6, 10, 16), Ui.dp(context, 7f).toFloat())
        badgeLabel.setPadding(
            Ui.dp(context, 5f), Ui.dp(context, 1f),
            Ui.dp(context, 5f), Ui.dp(context, 1f)
        )
        addView(
            badgeLabel,
            LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply {
                rightMargin = Ui.dp(context, 7f)
                topMargin = Ui.dp(context, 6f)
            }
        )
    }

    // ------------------------------------------------------------------ api

    fun setName(text: String) {
        nameLabel.text = text
    }

    fun setStatus(text: String) {
        statusLabel.text = text
        statusLabel.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    fun setBadge(text: String) {
        badgeLabel.text = text
        badgeLabel.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    /** 视频源宽高比（例如 1.777） */
    fun setSourceAspect(value: Float) {
        if (value <= 0.1f) return
        videoAspect = value
        requestLayout()
        applyChildLayout()
    }

    fun setAspect(value: Float) = setSourceAspect(value)

    /** 画面比例：fill / fit / 16:9 / 4:3 / custom */
    fun applyAspect(mode: String, custom: Float = 0f) {
        aspectMode = mode
        ratio = custom
        fillScreen = mode == "fill"
        requestLayout()
        applyChildLayout()
    }

    fun setLabelAnchor(anchor: Int) {
        if (compact) return
        val params = nameLabel.layoutParams as LayoutParams
        params.gravity = anchor
        val inset = Ui.dp(context, 8f)
        params.leftMargin = if (anchor and Gravity.END != 0) 0 else inset
        params.rightMargin = if (anchor and Gravity.END != 0) inset else 0
        params.topMargin = if (anchor and Gravity.BOTTOM != 0) 0 else inset
        params.bottomMargin = if (anchor and Gravity.BOTTOM != 0) inset else 0
        nameLabel.layoutParams = params
    }

    fun setActive(active: Boolean) {
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.BLACK)
            if (active) setStroke(Ui.dp(context, 1.5f), Ui.ACCENT)
        }
    }

    fun showSnapshot(bitmap: Bitmap) {
        image.setImageBitmap(bitmap)
        image.visibility = View.VISIBLE
        texture.visibility = View.INVISIBLE
        if (bitmap.width > 0 && bitmap.height > 0) {
            videoAspect = bitmap.width.toFloat() / bitmap.height
            applyChildLayout()
        }
    }

    fun showVideo() {
        image.visibility = View.GONE
        texture.visibility = View.VISIBLE
    }

    fun resetZoom() {
        scaleFactor = 1f
        offsetX = 0f
        offsetY = 0f
        applyTransform()
    }

    fun currentBitmap(): Bitmap? = runCatching {
        if (image.visibility == View.VISIBLE) {
            (image.drawable as? BitmapDrawable)?.bitmap
        } else {
            texture.bitmap
        }
    }.getOrNull()

    fun isShowingVideo(): Boolean = image.visibility != View.VISIBLE

    fun frameBitmap(maxSize: Int = 96): Bitmap? = runCatching {
        if (image.visibility == View.VISIBLE) {
            (image.drawable as? BitmapDrawable)?.bitmap
        } else {
            texture.getBitmap(maxSize, maxSize)
        }
    }.getOrNull()

    // -------------------------------------------------------------- layout

    private fun applyCompact() {
        nameLabel.visibility = if (compact) View.GONE else View.VISIBLE
        statusLabel.setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            if (compact) 8.5f else 10.5f
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyChildLayout()
    }

    private fun applyChildLayout() {
        val width = width
        val height = height
        if (width <= 0 || height <= 0) return
        val source = if (videoAspect > 0.1f) videoAspect else 16f / 9f

        var targetAspect = source
        var cover = false
        when (aspectMode) {
            "16:9" -> targetAspect = 16f / 9f
            "4:3" -> targetAspect = 4f / 3f
            "custom" -> if (ratio > 0.3f) targetAspect = ratio
            "fill" -> cover = true
        }

        var viewWidth: Int
        var viewHeight: Int
        if (cover) {
            viewWidth = width
            viewHeight = (width / source).toInt()
            if (viewHeight < height) {
                viewHeight = height
                viewWidth = (height * source).toInt()
            }
        } else if (inscribed) {
            val radius = min(width, height) / 2f
            val denominator = sqrt(targetAspect * targetAspect + 1.0).toFloat()
            val maxWidth = (2f * radius * targetAspect / denominator).toInt()
            val maxHeight = (2f * radius / denominator).toInt()
            viewWidth = min(width, maxWidth)
            viewHeight = (viewWidth / targetAspect).toInt()
            if (viewHeight > height || viewHeight > maxHeight) {
                viewHeight = min(height, maxHeight)
                viewWidth = (viewHeight * targetAspect).toInt()
            }
        } else {
            viewWidth = width
            viewHeight = (width / targetAspect).toInt()
            if (viewHeight > height) {
                viewHeight = height
                viewWidth = (height * targetAspect).toInt()
            }
        }

        if (viewWidth <= 0 || viewHeight <= 0) return
        childWidth = viewWidth
        childHeight = viewHeight
        for (view in arrayOf<View>(texture, image)) {
            val params = view.layoutParams as LayoutParams
            if (params.width != viewWidth || params.height != viewHeight) {
                params.width = viewWidth
                params.height = viewHeight
                view.layoutParams = params
            }
        }
        applyTransform()
    }

    private fun applyTransform() {
        if (childWidth <= 0 || childHeight <= 0) return
        for (view in arrayOf<View>(texture, image)) {
            view.pivotX = childWidth / 2f
            view.pivotY = childHeight / 2f
            view.scaleX = scaleFactor
            view.scaleY = scaleFactor
            view.translationX = offsetX
            view.translationY = offsetY
        }
    }

    private fun clampOffsets() {
        val maxX = (childWidth * (scaleFactor - 1f)) / 2f
        val maxY = (childHeight * (scaleFactor - 1f)) / 2f
        offsetX = offsetX.coerceIn(-maxX, maxX)
        offsetY = offsetY.coerceIn(-maxY, maxY)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(event)
        return true
    }
}
