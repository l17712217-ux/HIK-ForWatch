package com.hikwatch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Lightweight native bar chart. A null value means the platform does not expose that metric. */
class TelemetryBarChartView(context: Context) : View(context) {
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.TEXT2
        textSize = 10f * resources.displayMetrics.scaledDensity
        textAlign = Paint.Align.CENTER
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.withAlpha(Ui.TEXT3, 45) }
    private var cpu = 0f
    private var gpu: Float? = null
    private var memory = 0f
    private var pssMb = 0f

    fun setValues(cpuPercent: Float, gpuPercent: Float?, memoryPercent: Float, appPssMb: Float) {
        cpu = cpuPercent.coerceIn(0f, 100f)
        gpu = gpuPercent?.coerceIn(0f, 100f)
        memory = memoryPercent.coerceIn(0f, 100f)
        pssMb = appPssMb
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val labels = listOf("CPU", "GPU MEM", "RAM")
        val values = listOf(cpu, gpu, memory)
        val centers = floatArrayOf(width * 0.18f, width * 0.5f, width * 0.82f)
        val barWidth = 24f * density
        val top = 8f * density
        val bottom = height - 27f * density
        val barHeight = (bottom - top).coerceAtLeast(1f)
        labels.forEachIndexed { i, label ->
            val x = centers[i]
            val rect = android.graphics.RectF(x - barWidth / 2, top, x + barWidth / 2, bottom)
            canvas.drawRoundRect(rect, 7f * density, 7f * density, trackPaint)
            val value = values[i]
            if (value != null) {
                barPaint.color = when (i) { 0 -> Ui.ACCENT; 1 -> Ui.WARN; else -> Ui.TEXT }
                val filledTop = bottom - barHeight * value / 100f
                canvas.drawRoundRect(x - barWidth / 2, filledTop, x + barWidth / 2, bottom,
                    7f * density, 7f * density, barPaint)
                canvas.drawText("${value.toInt()}%", x, top - 1f * density + 0f, textPaint)
            } else {
                canvas.drawText("N/A", x, top + 13f * density, textPaint)
            }
            canvas.drawText(label, x, height - 8f * density, textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.textSize = 8f * resources.displayMetrics.scaledDensity
        canvas.drawText(String.format(java.util.Locale.CHINA, "应用内存 PSS %.1f MB", pssMb),
            2f * density, height - 1f * density, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 10f * resources.displayMetrics.scaledDensity
    }
}
