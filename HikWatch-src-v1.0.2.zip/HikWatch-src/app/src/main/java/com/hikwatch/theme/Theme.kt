package com.hikwatch.theme

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import com.hikwatch.ui.Ui

/**
 * 主题：以渐变为主的 6 套风格。每套决定 主色 / 极光背景三团光 / 玻璃底色。
 */
data class AppTheme(
    val id: String,
    val name: String,
    val tagline: String,
    val accent: Int,
    val glowTop: Int,
    val glowRight: Int,
    val glowBottom: Int,
    val base: Int
)

object Themes {

    val ALL: List<AppTheme> = listOf(
        AppTheme(
            id = "aurora", name = "极光", tagline = "青蓝紫 · 默认",
            accent = Color.parseColor("#2FE3B0"),
            glowTop = Color.parseColor("#2FE3B0"),
            glowRight = Color.parseColor("#5B9DFF"),
            glowBottom = Color.parseColor("#7C5CFF"),
            base = Color.parseColor("#05070A")
        ),
        AppTheme(
            id = "tropic", name = "热带", tagline = "橙粉绿 · 海岛日落",
            accent = Color.parseColor("#FFB03A"),
            glowTop = Color.parseColor("#FF7A45"),
            glowRight = Color.parseColor("#FF4D8D"),
            glowBottom = Color.parseColor("#19C8A8"),
            base = Color.parseColor("#0B0608")
        ),
        AppTheme(
            id = "glacier", name = "冰原", tagline = "冰蓝白 · 极地",
            accent = Color.parseColor("#7CD8FF"),
            glowTop = Color.parseColor("#A8E6FF"),
            glowRight = Color.parseColor("#5B9DFF"),
            glowBottom = Color.parseColor("#C9D6FF"),
            base = Color.parseColor("#04070C")
        ),
        AppTheme(
            id = "lava", name = "熔岩", tagline = "红橙 · 火山",
            accent = Color.parseColor("#FF7043"),
            glowTop = Color.parseColor("#FF3D2E"),
            glowRight = Color.parseColor("#FF9A3C"),
            glowBottom = Color.parseColor("#C1121F"),
            base = Color.parseColor("#0A0403")
        ),
        AppTheme(
            id = "forest", name = "森林", tagline = "绿金 · 深林",
            accent = Color.parseColor("#8BE05A"),
            glowTop = Color.parseColor("#3FD98A"),
            glowRight = Color.parseColor("#B7E86B"),
            glowBottom = Color.parseColor("#2E8B57"),
            base = Color.parseColor("#040805")
        ),
        AppTheme(
            id = "midnight", name = "午夜", tagline = "靛青 · 深夜",
            accent = Color.parseColor("#8E9BFF"),
            glowTop = Color.parseColor("#5C6BFF"),
            glowRight = Color.parseColor("#38E1FF"),
            glowBottom = Color.parseColor("#A26BFF"),
            base = Color.parseColor("#04050B")
        )
    )

    fun byId(id: String?): AppTheme = ALL.firstOrNull { it.id == id } ?: ALL.first()

    fun next(id: String): AppTheme {
        val index = ALL.indexOfFirst { it.id == id }
        return ALL[(index + 1).mod(ALL.size)]
    }
}

object ThemeManager {

    private const val PREFS = "hikwatch_v1"
    private const val KEY = "app_theme"

    private var prefs: SharedPreferences? = null

    var current: AppTheme = Themes.ALL.first()
        private set

    fun init(context: Context) {
        val store = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = store
        current = Themes.byId(store.getString(KEY, null))
        Ui.applyTheme(current)
    }

    fun select(theme: AppTheme) {
        current = theme
        prefs?.edit()?.putString(KEY, theme.id)?.apply()
        Ui.applyTheme(theme)
    }
}
