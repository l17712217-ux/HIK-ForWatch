package com.hikwatch.net

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger

data class HttpResult(val code: Int, val body: ByteArray, val error: String = "")

/**
 * 极简 HTTP Digest 客户端（海康 ISAPI 默认摘要认证）。
 * 首次 401 解析 challenge，之后复用 nonce 预置 Authorization，减少抓拍模式的往返次数。
 */
class DigestHttp(private val user: String, private val pass: String) {

    private var realm = ""
    private var nonce = ""
    private var qop = ""
    private var opaque = ""
    private var basicMode = false
    private val nc = AtomicInteger(1)

    @Volatile
    var lastError: String = ""
        private set

    fun get(url: String, timeoutMs: Int = 8000, maxBytes: Int = 32 * 1024 * 1024): HttpResult {
        var attempt = 0
        while (attempt < 3) {
            val sentAuth = nonce.isNotEmpty() || basicMode
            val conn = try {
                open(url, timeoutMs)
            } catch (e: Exception) {
                lastError = e.message ?: "URL 无效"
                return HttpResult(0, ByteArray(0), lastError)
            }
            try {
                val code = conn.responseCode
                if (code == 200) {
                    val bytes = readAll(conn.inputStream, maxBytes)
                    conn.disconnect()
                    return HttpResult(code, bytes)
                }
                if (code == 401) {
                    val challenge = conn.getHeaderField("WWW-Authenticate")
                        ?: conn.getHeaderField("Www-Authenticate")
                    conn.disconnect()
                    val stale = isStale(challenge)
                    if (sentAuth && !stale) {
                        lastError = "认证失败：账号或密码错误"
                        return HttpResult(401, ByteArray(0), lastError)
                    }
                    if (challenge != null && parseChallenge(challenge)) {
                        attempt++
                        continue
                    }
                    lastError = "认证失败：账号或密码错误"
                    return HttpResult(401, ByteArray(0), lastError)
                }
                conn.disconnect()
                lastError = "HTTP $code"
                return HttpResult(code, ByteArray(0), lastError)
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                runCatching { conn.disconnect() }
                return HttpResult(0, ByteArray(0), lastError)
            }
        }
        lastError = "认证失败：重试次数已用完"
        return HttpResult(0, ByteArray(0), lastError)
    }

    /** 取流（MJPEG）用：返回可读的输入流，由调用方负责关闭连接。 */
    fun openStream(url: String, timeoutMs: Int = 8000): InputStream? {
        var attempt = 0
        while (attempt < 3) {
            val sentAuth = nonce.isNotEmpty() || basicMode
            val conn = try {
                open(url, timeoutMs, streaming = true)
            } catch (e: Exception) {
                lastError = e.message ?: "URL 无效"
                return null
            }
            try {
                val code = conn.responseCode
                if (code == 200) return conn.inputStream
                if (code == 401) {
                    val challenge = conn.getHeaderField("WWW-Authenticate")
                    conn.disconnect()
                    val stale = isStale(challenge)
                    if (sentAuth && !stale) {
                        lastError = "认证失败：账号或密码错误"
                        return null
                    }
                    if (challenge != null && parseChallenge(challenge)) {
                        attempt++
                        continue
                    }
                    lastError = "认证失败：账号或密码错误"
                    return null
                }
                conn.disconnect()
                lastError = "HTTP $code"
                return null
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                runCatching { conn.disconnect() }
                return null
            }
        }
        return null
    }

    private fun isStale(challenge: String?): Boolean {
        if (challenge == null) return false
        val lower = challenge.lowercase()
        return lower.contains("stale=\"true\"") || lower.contains("stale=true")
    }

    private fun open(url: String, timeoutMs: Int, streaming: Boolean = false): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = timeoutMs
        conn.readTimeout = if (streaming) 25000 else timeoutMs
        conn.instanceFollowRedirects = false
        conn.useCaches = false
        conn.setRequestProperty("User-Agent", "HikWatch/1.0")
        conn.setRequestProperty("Accept", "*/*")
        if (!streaming) conn.setRequestProperty("Connection", "close")
        if (nonce.isNotEmpty() || basicMode) {
            conn.setRequestProperty("Authorization", authorization("GET", uriOf(url)))
        }
        return conn
    }

    private fun uriOf(url: String): String {
        return try {
            val u = URL(url)
            val file = u.file
            if (file.isNullOrEmpty()) "/" else if (file.startsWith("/")) file else "/$file"
        } catch (e: Exception) {
            "/"
        }
    }

    private fun authorization(method: String, uri: String): String {
        if (basicMode) {
            val raw = "$user:$pass".toByteArray(Charsets.UTF_8)
            return "Basic " + Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val ha1 = md5("$user:$realm:$pass")
        val ha2 = md5("$method:$uri")
        val useQop = qop.contains("auth", ignoreCase = true)
        val cnonce = randomToken()
        val ncValue = nc.getAndIncrement()
        val ncHex = String.format("%08x", ncValue)
        val response = if (useQop) {
            md5("$ha1:$nonce:$ncHex:$cnonce:auth:$ha2")
        } else {
            md5("$ha1:$nonce:$ha2")
        }
        val sb = StringBuilder()
        sb.append("Digest username=\"").append(user).append("\"")
        sb.append(", realm=\"").append(realm).append("\"")
        sb.append(", nonce=\"").append(nonce).append("\"")
        sb.append(", uri=\"").append(uri).append("\"")
        sb.append(", response=\"").append(response).append("\"")
        sb.append(", algorithm=MD5")
        if (useQop) sb.append(", qop=auth, nc=").append(ncHex).append(", cnonce=\"").append(cnonce).append("\"")
        if (opaque.isNotEmpty()) sb.append(", opaque=\"").append(opaque).append("\"")
        return sb.toString()
    }

    private fun parseChallenge(header: String): Boolean {
        val digestIdx = header.indexOf("Digest", ignoreCase = true)
        if (digestIdx < 0) {
            if (header.contains("Basic", ignoreCase = true)) {
                basicMode = true
                return true
            }
            return false
        }
        basicMode = false
        val params = header.substring(digestIdx + 6)
        for (item in splitParams(params)) {
            val eq = item.indexOf('=')
            if (eq <= 0) continue
            val key = item.substring(0, eq).trim().lowercase()
            var value = item.substring(eq + 1).trim()
            if (value.startsWith("\"")) value = value.trim('"')
            when (key) {
                "realm" -> realm = value
                "nonce" -> nonce = value
                "qop" -> qop = value
                "opaque" -> opaque = value
            }
        }
        return nonce.isNotEmpty()
    }

    private fun splitParams(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inQuote = false
        for (c in text) {
            when {
                c == '"' -> {
                    inQuote = !inQuote
                    sb.append(c)
                }
                c == ',' && !inQuote -> {
                    out.add(sb.toString())
                    sb.setLength(0)
                }
                else -> sb.append(c)
            }
        }
        if (sb.isNotBlank()) out.add(sb.toString())
        return out
    }

    private fun readAll(input: InputStream, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream(128 * 1024)
        val buf = ByteArray(32 * 1024)
        var total = 0
        try {
            while (total < maxBytes) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                out.write(buf, 0, n)
            }
        } catch (e: Exception) {
            // 返回已读取部分
        } finally {
            runCatching { input.close() }
        }
        return out.toByteArray()
    }

    companion object {
        fun md5(text: String): String {
            val md = MessageDigest.getInstance("MD5")
            val bytes = md.digest(text.toByteArray(Charsets.UTF_8))
            val sb = StringBuilder(bytes.size * 2)
            for (b in bytes) sb.append(String.format("%02x", b))
            return sb.toString()
        }

        fun randomToken(): String =
            java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16)
    }
}
