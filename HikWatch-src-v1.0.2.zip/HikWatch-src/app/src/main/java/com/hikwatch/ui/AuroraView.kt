package com.hikwatch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/**
 * 液态玻璃背景：主题色三团柔光 + 顶部斜向流光 + 边缘暗角。
 * 颜色随主题切换（Ui.theme），静态绘制不持续重绘。
 */
class AuroraView(context: Context) : View(context) {

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobTop = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobRight = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blobBottom = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vignette = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        val theme = Ui.theme
        basePaint.color = theme.base

        blobTop.shader = RadialGradient(
            w * 0.18f, h * 0.08f, w * 0.78f,
            intArrayOf(Ui.withAlpha(theme.glowTop, 72), Ui.withAlpha(theme.glowTop, 0)),
            null, Shader.TileMode.CLAMP
        )
        blobRight.shader = RadialGradient(
            w * 0.94f, h * 0.34f, w * 0.84f,
            intArrayOf(Ui.withAlpha(theme.glowRight, 58), Ui.withAlpha(theme.glowRight, 0)),
            null, Shader.TileMode.CLAMP
        )
        blobBottom.shader = RadialGradient(
            w * 0.48f, h * 1.02f, w * 0.86f,
            intArrayOf(Ui.withAlpha(theme.glowBottom, 60), Ui.withAlpha(theme.glowBottom, 0)),
            null, Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            w * 0.1f, 0f, w * 0.85f, h * 0.55f,
            intArrayOf(
                Ui.withAlpha(Color.WHITE, 16),
                Ui.withAlpha(Color.WHITE, 0),
                Ui.withAlpha(theme.glowTop, 12)
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        vignette.shader = RadialGradient(
            w / 2f, h / 2f, w * 0.8f,
            intArrayOf(Color.TRANSPARENT, Color.argb(168, 0, 0, 0)),
            floatArrayOf(0.58f, 1f), Shader.TileMode.CLAMP
        )
    }

    /** 主题切换后重建 shader（尺寸不变时也需要） */
    fun refresh() {
        if (width > 0 && height > 0) onSizeChanged(width, height, 0, 0)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, basePaint)
        canvas.drawRect(0f, 0f, w, h, blobTop)
        canvas.drawRect(0f, 0f, w, h, blobRight)
        canvas.drawRect(0f, 0f, w, h, blobBottom)
        canvas.drawRect(0f, 0f, w, h, sheen)
        canvas.drawRect(0f, 0f, w, h, vignette)
    }
}
