package com.hikwatch.model

import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

/**
 * 一台海康设备（IPC 或 NVR 的一个通道）。
 */
data class Camera(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val host: String = "",
    val httpPort: Int = 80,
    val rtspPort: Int = 554,
    val user: String = "1",
    val pass: String = "abc123456",
    val channel: Int = 1,
    val subStream: Boolean = true,
    val rtspTcp: Boolean = true,
    val mode: String = MODE_AUTO,
    val recordAudio: Boolean = true,
    /** 星标：重点监控，列表中置顶显示 */
    val starred: Boolean = false
) {
    /** 海康通道号：主码流 101 / 子码流 102，第 n 通道 n01 / n02 */
    val channelPath: String get() = "$channel" + "0" + (if (subStream) 2 else 1)

    val streamLabel: String get() = if (subStream) "子码流" else "主码流"

    val displayName: String get() = if (name.isNotBlank()) name else host

    val modeLabel: String
        get() = when (mode) {
            MODE_RTSP -> "仅实时"
            MODE_SNAPSHOT -> "仅抓拍"
            else -> "自动"
        }

    fun httpBase(): String = "http://$host" + (if (httpPort == 80) "" else ":$httpPort")

    fun rtspBase(): String = "rtsp://$host:$rtspPort/Streaming/Channels/$channelPath"

    /** 带账号的 RTSP 地址，供播放器使用 */
    fun rtspUrl(): String =
        "rtsp://${enc(user)}:${enc(pass)}@$host:$rtspPort/Streaming/Channels/$channelPath"

    fun isapi(path: String): String = httpBase() + (if (path.startsWith("/")) path else "/$path")

    fun snapshotUrl(): String = isapi("/ISAPI/Streaming/channels/$channelPath/picture")

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("host", host)
        put("httpPort", httpPort)
        put("rtspPort", rtspPort)
        put("user", user)
        put("pass", pass)
        put("channel", channel)
        put("subStream", subStream)
        put("rtspTcp", rtspTcp)
        put("mode", mode)
        put("recordAudio", recordAudio)
        put("starred", starred)
    }

    companion object {
        const val MODE_AUTO = "auto"
        const val MODE_RTSP = "rtsp"
        const val MODE_SNAPSHOT = "snapshot"

        fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

        fun fromJson(o: JSONObject): Camera = Camera(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name", ""),
            host = o.optString("host", ""),
            httpPort = o.optInt("httpPort", 80),
            rtspPort = o.optInt("rtspPort", 554),
            user = o.optString("user", "admin"),
            pass = o.optString("pass", ""),
            channel = o.optInt("channel", 1),
            subStream = o.optBoolean("subStream", true),
            rtspTcp = o.optBoolean("rtspTcp", true),
            mode = o.optString("mode", MODE_AUTO),
            recordAudio = o.optBoolean("recordAudio", true),
            starred = o.optBoolean("starred", false)
        )
    }
}
