package com.hikwatch.data

import android.content.Context
import com.hikwatch.model.Camera

/**
 * 首次启动时写入内置设备（如果 SeedCameras.IPS 非空则自带账号密码）。
 * 幂等：已有同 IP 的设备不会重复添加；种子版本升级时会给缺密码的内置设备补上账号。
 */
object CameraSeeder {

    const val DEFAULT_USER = "1"
    const val DEFAULT_PASS = "abc123456"

    private const val PREFS = "hikwatch_v1"
    private const val KEY_SEED_VERSION = "seed_version"

    fun ensureSeeded(context: Context): Int {
        val prefs = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previous = prefs.getInt(KEY_SEED_VERSION, 0)
        if (previous >= SeedCameras.SEED_VERSION) return 0

        val store = CameraStore(context)
        val list = store.cameras()
        val seedHosts = SeedCameras.IPS.toHashSet()
        val existing = list.map { it.host }.toHashSet()
        var changed = 0

        // 1) 补齐缺失的内置设备
        SeedCameras.IPS.forEachIndexed { index, ip ->
            if (existing.contains(ip)) return@forEachIndexed
            list.add(
                Camera(
                    name = "IPC-" + (index + 1).toString().padStart(2, '0'),
                    host = ip,
                    httpPort = 80,
                    rtspPort = 554,
                    user = DEFAULT_USER,
                    pass = DEFAULT_PASS,
                    channel = 1,
                    subStream = true,
                    rtspTcp = true,
                    mode = Camera.MODE_AUTO
                )
            )
            changed++
        }

        // 2) 旧版本写入的内置设备如果还没有密码，补上默认账号
        for (index in list.indices) {
            val camera = list[index]
            if (!seedHosts.contains(camera.host)) continue
            if (camera.pass.isBlank()) {
                list[index] = camera.copy(user = DEFAULT_USER, pass = DEFAULT_PASS)
                changed++
            }
        }

        if (changed > 0) store.save(list)
        prefs.edit().putInt(KEY_SEED_VERSION, SeedCameras.SEED_VERSION).apply()
        return changed
    }

    /** 设置页批量改账号密码用 */
    fun applyToAll(context: Context, user: String?, pass: String?): Int {
        val store = CameraStore(context)
        val list = store.cameras().map { camera ->
            camera.copy(
                user = user ?: camera.user,
                pass = pass ?: camera.pass
            )
        }
        store.save(list)
        return list.size
    }
}
