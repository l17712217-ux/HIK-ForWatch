package com.hikwatch.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hikwatch.BuildConfig
import com.hikwatch.R
import com.hikwatch.data.CameraSeeder
import com.hikwatch.data.CameraStore
import com.hikwatch.theme.ThemeManager
import com.hikwatch.util.CrashLog

/** 设置：画面设置 / 界面设置 / 主题设置 + 批量账号密码 */
class SettingsActivity : Activity() {

    companion object {
        private const val REQ_BULK_USER = 4301
        private const val REQ_BULK_PASS = 4302
    }

    private lateinit var store: CameraStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        setContentView(buildRoot())
    }

    override fun onResume() {
        super.onResume()
        setContentView(buildRoot())
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = Ui.label(this, "设置", 18f, Ui.TEXT, bold = false)
        title.typeface = android.graphics.Typeface.create(
            "sans-serif-light", android.graphics.Typeface.NORMAL
        )
        title.letterSpacing = 0.22f
        title.gravity = Gravity.CENTER
        header.addView(title)
        val sub = Ui.label(this, ThemeManager.current.tagline, 8.5f, Ui.TEXT3)
        sub.gravity = Gravity.CENTER
        sub.letterSpacing = 0.05f
        header.addView(sub)
        root.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@SettingsActivity, 16f) }
        )

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        box.addView(
            Ui.menuRow(
                this,
                R.drawable.ic_picture,
                "画面设置",
                store.qualityLabel() + " · " + store.aspectLabel(store.aspectMode)
            ) {
                startActivity(Intent(this@SettingsActivity, PictureSettingsActivity::class.java))
            }
        )
        box.addView(
            Ui.menuRow(
                this,
                R.drawable.ic_grid,
                "界面设置",
                "隐藏 " + store.hiddenControlCount() + " 项"
            ) {
                startActivity(Intent(this@SettingsActivity, InterfaceSettingsActivity::class.java))
            }
        )
        box.addView(
            Ui.menuRow(this, R.drawable.ic_theme, "主题设置", ThemeManager.current.name) {
                startActivity(Intent(this@SettingsActivity, ThemeSettingsActivity::class.java))
            }
        )
        box.addView(
            Ui.menuRow(this, R.drawable.ic_settings, "批量用户名", store.cameras().size.toString() + " 台") {
                startActivityForResult(
                    TextInputActivity.intent(this, "全部设备用户名", "例如 admin", "admin", false),
                    REQ_BULK_USER
                )
            }
        )
        box.addView(
            Ui.menuRow(this, R.drawable.ic_settings, "批量密码", "应用到全部设备") {
                startActivityForResult(
                    TextInputActivity.intent(this, "全部设备密码", "输入密码", "", false),
                    REQ_BULK_PASS
                )
            }
        )
        box.addView(
            Ui.menuRow(this, R.drawable.ic_snapshot, "关于", "v" + BuildConfig.VERSION_NAME) {
                showAbout()
            }
        )

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        scroll.addView(box, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@SettingsActivity, 54f)
                bottomMargin = Ui.dp(this@SettingsActivity, 44f)
                leftMargin = Ui.dp(this@SettingsActivity, 30f)
                rightMargin = Ui.dp(this@SettingsActivity, 30f)
            }
        )

        val back = Ui.iconButton(this, R.drawable.ic_back, 32f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 32f),
                Ui.dp(this, 32f),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@SettingsActivity, 5f) }
        )
        return root
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val value = data?.getStringExtra(TextInputActivity.EXTRA_RESULT).orEmpty()
        when (requestCode) {
            REQ_BULK_USER -> {
                val count = CameraSeeder.applyToAll(this, user = value, pass = null)
                Ui.toast(this, "已更新 " + count + " 台设备的用户名")
            }
            REQ_BULK_PASS -> {
                val count = CameraSeeder.applyToAll(this, user = null, pass = value)
                Ui.toast(this, "已更新 " + count + " 台设备的密码")
            }
        }
    }

    private fun showAbout() {
        val crash = CrashLog.read(this)
        val body = buildString {
            appendLine("专为 OPPO Watch X2（466×466 圆屏）适配。")
            appendLine()
            appendLine("· 实时画面：RTSP（Media3）")
            appendLine("· 声音监听：自研 RTSP + G.711 / AAC")
            appendLine("· 截图：ISAPI 高清抓图")
            appendLine("· 录像：屏幕镜像 + 应用声音")
            if (crash.isNotBlank()) {
                appendLine()
                appendLine("最近一次崩溃记录：")
                appendLine(crash.takeLast(420))
            }
        }
        Ui.showMessage(this, "海康监控 v" + BuildConfig.VERSION_NAME, body)
    }
}
