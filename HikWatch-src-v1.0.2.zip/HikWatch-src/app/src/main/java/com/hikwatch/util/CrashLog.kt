package com.hikwatch.util

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 记录未捕获异常到应用私有目录，方便用户把问题反馈回来。
 * 只记录，不吞异常——系统仍会正常结束进程。
 */
object CrashLog {

    private const val FILE_NAME = "crash.log"
    private const val MAX_BYTES = 96 * 1024L

    fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    fun read(context: Context): String = runCatching {
        val log = file(context)
        if (log.exists()) log.readText() else ""
    }.getOrDefault("")

    fun clear(context: Context) {
        runCatching { file(context).delete() }
    }

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val log = file(app)
                if (log.exists() && log.length() > MAX_BYTES) log.delete()
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                log.appendText(
                    buildString {
                        appendLine("=== $stamp  thread=${thread.name} ===")
                        appendLine(throwable.javaClass.name + ": " + throwable.message)
                        throwable.stackTrace.take(28).forEach { appendLine("    at $it") }
                        appendLine()
                    }
                )
            }
            previous?.uncaughtException(thread, throwable)
                ?: android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
