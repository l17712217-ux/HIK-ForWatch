package com.hikwatch.ui

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.hikwatch.R
import com.hikwatch.theme.AppTheme
import com.hikwatch.theme.ThemeManager
import com.hikwatch.theme.Themes
import kotlin.math.abs

/** 主题设置：左右滑动切换 6 套渐变主题 */
class ThemeSettingsActivity : Activity() {

    private lateinit var swatch: ThemeSwatchView
    private lateinit var nameLabel: TextView
    private lateinit var taglineLabel: TextView
    private lateinit var dots: LinearLayout
    private var index = 0
    private lateinit var swipeDetector: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        index = Themes.ALL.indexOfFirst { it.id == ThemeManager.current.id }.coerceAtLeast(0)
        swipeDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > abs(dy) * 1.2f && abs(dx) > Ui.dp(this@ThemeSettingsActivity, 28f) && abs(velocityX) > 120f) {
                    step(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        setContentView(buildRoot())
        apply(false)
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val header = Ui.label(this, "主题设置", 13.5f, Ui.TEXT, bold = true)
        header.letterSpacing = 0.06f
        root.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 16f) }
        )

        swatch = ThemeSwatchView(this)
        root.addView(
            swatch,
            FrameLayout.LayoutParams(
                Ui.dp(this, 158f),
                Ui.dp(this, 100f),
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 48f) }
        )

        nameLabel = Ui.label(this, "", 14f, Ui.TEXT, bold = true)
        nameLabel.gravity = Gravity.CENTER
        nameLabel.letterSpacing = 0.1f
        root.addView(
            nameLabel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 152f) }
        )

        taglineLabel = Ui.label(this, "", 8.5f, Ui.TEXT3)
        taglineLabel.gravity = Gravity.CENTER
        root.addView(
            taglineLabel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 170f) }
        )

        dots = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (i in Themes.ALL.indices) {
            val dot = View(this)
            dot.background = Ui.solid(Ui.TEXT3, Ui.dp(this, 2.5f).toFloat())
            dots.addView(
                dot,
                LinearLayout.LayoutParams(Ui.dp(this, 5f), Ui.dp(this, 5f)).apply {
                    leftMargin = Ui.dp(this@ThemeSettingsActivity, 3f)
                    rightMargin = Ui.dp(this@ThemeSettingsActivity, 3f)
                }
            )
        }
        root.addView(
            dots,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 184f) }
        )

        val hint = Ui.label(this, "← 左右滑动切换主题 →", 8f, Ui.TEXT3)
        hint.gravity = Gravity.CENTER
        root.addView(
            hint,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@ThemeSettingsActivity, 196f) }
        )

        val back = Ui.iconButton(this, R.drawable.ic_back, 30f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 30f),
                Ui.dp(this, 30f),
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = Ui.dp(this@ThemeSettingsActivity, 4f) }
        )

        // Activity.dispatchTouchEvent 统一接收所有子 View 的触摸事件，避免色卡/文字拦截滑动。
        root.isClickable = true
        return root
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipeDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun step(delta: Int) {
        index = (index + delta).mod(Themes.ALL.size)
        apply(true)
    }

    private fun apply(persist: Boolean) {
        val theme = Themes.ALL[index]
        if (persist) ThemeManager.select(theme)
        swatch.setTheme(theme)
        nameLabel.text = theme.name
        taglineLabel.text = theme.tagline
        for (i in 0 until dots.childCount) {
            val dot = dots.getChildAt(i)
            val active = i == index
            dot.background = Ui.solid(
                if (active) theme.accent else Ui.TEXT3,
                Ui.dp(this, if (active) 3.5f else 2.5f).toFloat()
            )
            val params = dot.layoutParams as LinearLayout.LayoutParams
            val size = Ui.dp(this, if (active) 7f else 5f)
            params.width = size
            params.height = size
            dot.layoutParams = params
        }
    }
}

/** 主题预览色卡：底色 + 三团主题光 + 主色胶囊 */
class ThemeSwatchView(context: Context) : View(context) {

    private var theme: AppTheme? = null
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val rect = RectF()

    init {
        setWillNotDraw(false)
    }

    fun setTheme(theme: AppTheme) {
        this.theme = theme
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val current = theme ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val radius = h * 0.28f
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(path)
        basePaint.color = current.base
        canvas.drawRect(rect, basePaint)

        glowPaint.shader = RadialGradient(
            w * 0.2f, h * 0.12f, w * 0.72f,
            intArrayOf(Ui.withAlpha(current.glowTop, 128), Ui.withAlpha(current.glowTop, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(rect, glowPaint)
        glowPaint.shader = RadialGradient(
            w * 0.9f, h * 0.4f, w * 0.7f,
            intArrayOf(Ui.withAlpha(current.glowRight, 112), Ui.withAlpha(current.glowRight, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(rect, glowPaint)
        glowPaint.shader = RadialGradient(
            w * 0.5f, h * 1.05f, w * 0.78f,
            intArrayOf(Ui.withAlpha(current.glowBottom, 120), Ui.withAlpha(current.glowBottom, 0)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(rect, glowPaint)
        canvas.restore()

        pillPaint.color = current.accent
        canvas.drawRoundRect(
            w * 0.1f, h * 0.72f, w * 0.42f, h * 0.84f,
            h * 0.06f, h * 0.06f, pillPaint
        )
        borderPaint.strokeWidth = resources.displayMetrics.density * 1.2f
        borderPaint.color = Color.argb(90, 255, 255, 255)
        canvas.drawPath(path, borderPaint)
    }
}
