package com.hikwatch.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import android.os.SystemClock
import android.util.Base64
import android.util.Log
import java.io.BufferedInputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/**
 * 海康 RTSP 音频监听通道。
 *
 * 为什么不用播放器自带的音频：Media3 的 RTP 只支持 AAC / AMR / AC3 / Opus / PCM，
 * 而海康默认是 G.711（PCMA / PCMU），所以这里自己完成
 * DESCRIBE -> SETUP(interleaved TCP) -> PLAY -> RTP -> G.711/AAC -> AudioTrack。
 */
class RtspAudioClient(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
    private val streamPath: String,
    private val listener: Listener
) {

    interface Listener {
        fun onStatus(text: String)
        fun onError(text: String)
        fun onCodec(text: String)
    }

    /** 诊断用：每收到一个有效音频包回调一次（参数为 RTP payload type） */
    @Volatile
    var packetListener: ((Int) -> Unit)? = null

    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var socket: Socket? = null
    private var out: OutputStream? = null
    private var sink: AudioSink? = null

    private var cseq = 0
    private var sessionId = ""
    private var currentUrl = ""

    private var realm = ""
    private var nonce = ""
    private var qop = ""
    private var opaque = ""
    private var basicMode = false
    private var authReady = false
    private var nc = 0

    @Volatile
    private var volume = 1.0f

    fun start() {
        if (!running.compareAndSet(false, true)) return
        listener.onStatus("连接音频…")
        val thread = Thread({ work() }, "hik-rtsp-audio")
        thread.isDaemon = true
        worker = thread
        thread.start()
    }

    fun stop() {
        if (!running.getAndSet(false)) {
            runCatching { socket?.close() }
            return
        }
        teardownQuietly()
        runCatching { socket?.close() }
        val thread = worker
        worker = null
        runCatching { thread?.join(800) }
        runCatching { sink?.release() }
        sink = null
    }

    fun setVolume(value: Float) {
        volume = value.coerceIn(0f, 1f)
        runCatching { sink?.setVolume(volume) }
    }

    // ---------------------------------------------------------------- thread

    private fun work() {
        var attempt = 0
        try {
            while (running.get() && attempt <= 2) {
                try {
                    session()
                } catch (e: Throwable) {
                    if (!running.get()) break
                    attempt++
                    Log.w(TAG, "audio session error", e)
                    listener.onStatus("音频重连 $attempt/2")
                    sleepQuietly(900)
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "audio worker crashed", e)
        } finally {
            runCatching { sink?.release() }
            sink = null
            runCatching { socket?.close() }
            socket = null
            out = null
            if (running.get()) {
                running.set(false)
                listener.onStatus("音频已停止")
            }
        }
    }

    private fun session() {
        val url = "rtsp://$host:$port$streamPath"
        currentUrl = url
        val client = Socket()
        client.tcpNoDelay = true
        client.connect(InetSocketAddress(host, port), 5000)
        client.soTimeout = 5000
        socket = client
        val input = BufferedInputStream(client.getInputStream(), 32 * 1024)
        val output = client.getOutputStream()
        out = output

        listener.onStatus("音频握手…")
        val describe = request(input, "DESCRIBE", url, listOf("Accept: application/sdp"))
        if (describe == null) {
            fail("设备无响应（RTSP DESCRIBE 超时）")
            return
        }
        if (describe.code == 401) {
            fail("账号或密码错误（RTSP 认证失败）")
            return
        }
        if (describe.code != 200) {
            fail("DESCRIBE 失败：${describe.statusLine}")
            return
        }
        if (describe.body.isBlank()) {
            fail("设备返回的 SDP 为空")
            return
        }
        val audio = SdpParser.parse(describe.body).firstOrNull { it.isAudio }
        if (audio == null) {
            fail("该通道没有音频轨道，请在摄像头或录像机里开启音频")
            return
        }
        val codec = CodecSpec.of(audio)
        if (codec == null) {
            fail("音频编码 ${audio.encoding} 暂不支持，请把摄像头音频编码改成 G.711 或 AAC")
            return
        }
        listener.onCodec(codec.description)

        val base = describe.header("Content-Base")?.takeIf { it.isNotBlank() } ?: url
        val control = resolveControl(base, audio.control)
        val setup = request(
            input,
            "SETUP",
            control,
            listOf("Transport: RTP/AVP/TCP;unicast;interleaved=0-1")
        )
        if (setup == null) {
            fail("SETUP 无响应")
            return
        }
        if (setup.code != 200) {
            fail("SETUP 失败：${setup.statusLine}")
            return
        }
        val channel = parseInterleavedChannel(setup.header("Transport").orEmpty())
        sessionId = setup.header("Session")?.substringBefore(";")?.trim().orEmpty()

        val play = request(input, "PLAY", base, listOf("Range: npt=0.000-"))
        if (play == null) {
            fail("PLAY 无响应")
            return
        }
        if (play.code != 200) {
            fail("PLAY 失败：${play.statusLine}")
            return
        }
        if (!running.get()) return

        client.soTimeout = 1500
        val created = try {
            if (codec.kind == CodecSpec.KIND_AAC) AacSink(codec) else G711Sink(codec.rate, codec.alaw)
        } catch (e: Throwable) {
            fail("音频解码器初始化失败：${e.message}")
            return
        }
        sink = created
        runCatching {
            created.start()
            created.setVolume(volume)
        }
        listener.onStatus("监听中")
        readLoop(input, output, base, channel)
    }

    private fun readLoop(input: InputStream, output: OutputStream, base: String, channel: Int) {
        var lastSeq = -1
        var lastKeepAlive = SystemClock.elapsedRealtime()
        while (running.get()) {
            val first: Int = try {
                input.read()
            } catch (e: SocketTimeoutException) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastKeepAlive > 20000) {
                    runCatching { sendKeepAlive(output, base) }
                    lastKeepAlive = now
                }
                continue
            } catch (e: IOException) {
                break
            }
            if (first < 0) break
            if (first != INTERLEAVED_MARK) {
                runCatching { consumeMessage(input, first) }
                continue
            }
            val header = try {
                readFully(input, 3)
            } catch (e: IOException) {
                break
            }
            val packetChannel = header[0].toInt() and 0xFF
            val length = ((header[1].toInt() and 0xFF) shl 8) or (header[2].toInt() and 0xFF)
            if (length <= 0 || length > 65000) continue
            val packet = try {
                readFully(input, length)
            } catch (e: IOException) {
                break
            }
            if (packetChannel != channel || length < 13) continue
            val sequence = ((packet[2].toInt() and 0xFF) shl 8) or (packet[3].toInt() and 0xFF)
            if (sequence == lastSeq) continue
            lastSeq = sequence
            val payloadType = packet[1].toInt() and 0x7F
            val offset = rtpPayloadOffset(packet, length)
            if (offset <= 0 || offset >= length) continue
            val timestamp = rtpTimestamp(packet)
            runCatching { sink?.onPayload(packet, offset, length - offset, timestamp) }
            packetListener?.invoke(payloadType)
        }
    }

    // ---------------------------------------------------------------- rtsp

    private fun request(
        input: InputStream,
        method: String,
        target: String,
        headers: List<String>
    ): RtspResponse? {
        var response = send(input, method, target, headers)
        var guard = 0
        while (response != null && response.code == 401 && guard < 2) {
            val challenge = response.header("WWW-Authenticate")
                ?: response.header("Www-Authenticate")
            if (challenge == null || !parseChallenge(challenge)) return response
            response = send(input, method, target, headers)
            guard++
        }
        return response
    }

    private fun send(
        input: InputStream,
        method: String,
        target: String,
        headers: List<String>
    ): RtspResponse? {
        val output = out ?: return null
        cseq++
        val builder = StringBuilder()
        builder.append(method).append(' ').append(target).append(" RTSP/1.0\r\n")
        builder.append("CSeq: ").append(cseq).append("\r\n")
        builder.append("User-Agent: HikWatch/1.0\r\n")
        if (sessionId.isNotEmpty()) builder.append("Session: ").append(sessionId).append("\r\n")
        for (header in headers) builder.append(header).append("\r\n")
        if (authReady) {
            builder.append("Authorization: ").append(authorization(method, target)).append("\r\n")
        }
        builder.append("\r\n")
        output.write(builder.toString().toByteArray(Charsets.UTF_8))
        output.flush()
        return readResponse(input, cseq)
    }

    private fun readResponse(input: InputStream, expectCseq: Int): RtspResponse? {
        var guard = 0
        while (guard++ < 64) {
            val first: Int = try {
                input.read()
            } catch (e: SocketTimeoutException) {
                return null
            } catch (e: IOException) {
                return null
            }
            if (first < 0) return null
            if (first == INTERLEAVED_MARK) {
                runCatching { skipInterleaved(input) }
                continue
            }
            val statusLine = readLine(input, first) ?: return null
            val headers = ArrayList<Pair<String, String>>()
            var contentLength = 0
            while (true) {
                val line = readLine(input, -1) ?: break
                if (line.isEmpty()) break
                val index = line.indexOf(':')
                if (index > 0) {
                    val key = line.substring(0, index).trim()
                    val value = line.substring(index + 1).trim()
                    headers.add(key to value)
                    if (key.equals("Content-Length", true)) {
                        contentLength = value.toIntOrNull() ?: 0
                    }
                }
            }
            val body = if (contentLength > 0) {
                String(readFully(input, contentLength), Charsets.UTF_8)
            } else {
                ""
            }
            val parts = statusLine.split(' ')
            val code = parts.getOrNull(1)?.toIntOrNull() ?: 0
            val responseCseq = headers.firstOrNull { it.first.equals("CSeq", true) }
                ?.second?.toIntOrNull() ?: -1
            val response = RtspResponse(code, statusLine, headers, body)
            if (expectCseq > 0 && responseCseq >= 0 && responseCseq != expectCseq) continue
            return response
        }
        return null
    }

    private fun consumeMessage(input: InputStream, first: Int) {
        readLine(input, first) ?: return
        var contentLength = 0
        while (true) {
            val line = readLine(input, -1) ?: return
            if (line.isEmpty()) break
            val index = line.indexOf(':')
            if (index > 0 && line.substring(0, index).trim().equals("Content-Length", true)) {
                contentLength = line.substring(index + 1).trim().toIntOrNull() ?: 0
            }
        }
        if (contentLength > 0) readFully(input, contentLength)
    }

    private fun readLine(input: InputStream, firstByte: Int): String? {
        val builder = StringBuilder()
        var byte = if (firstByte >= 0) {
            firstByte
        } else {
            try {
                input.read()
            } catch (e: IOException) {
                return null
            }
        }
        if (byte < 0) return null
        while (byte >= 0 && byte != '\n'.code) {
            if (byte != '\r'.code) builder.append(byte.toChar())
            byte = try {
                input.read()
            } catch (e: IOException) {
                -1
            }
        }
        if (byte < 0 && builder.isEmpty()) return null
        return builder.toString()
    }

    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val read = input.read(buffer, offset, length - offset)
            if (read < 0) throw EOFException("连接已关闭")
            offset += read
        }
        return buffer
    }

    private fun skipInterleaved(input: InputStream) {
        val header = readFully(input, 3)
        var left = ((header[1].toInt() and 0xFF) shl 8) or (header[2].toInt() and 0xFF)
        val buffer = ByteArray(4096)
        while (left > 0) {
            val read = input.read(buffer, 0, min(buffer.size, left))
            if (read < 0) throw EOFException("连接已关闭")
            left -= read
        }
    }

    private fun sendKeepAlive(output: OutputStream, target: String) {
        cseq++
        val builder = StringBuilder()
        builder.append("OPTIONS ").append(target).append(" RTSP/1.0\r\n")
        builder.append("CSeq: ").append(cseq).append("\r\n")
        if (sessionId.isNotEmpty()) builder.append("Session: ").append(sessionId).append("\r\n")
        builder.append("\r\n")
        output.write(builder.toString().toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun teardownQuietly() {
        val output = out ?: return
        runCatching {
            cseq++
            val builder = StringBuilder()
            builder.append("TEARDOWN ").append(currentUrl).append(" RTSP/1.0\r\n")
            builder.append("CSeq: ").append(cseq).append("\r\n")
            if (sessionId.isNotEmpty()) {
                builder.append("Session: ").append(sessionId).append("\r\n")
            }
            builder.append("\r\n")
            output.write(builder.toString().toByteArray(Charsets.UTF_8))
            output.flush()
        }
    }

    // ---------------------------------------------------------------- digest

    private fun authorization(method: String, uri: String): String {
        if (basicMode) {
            val raw = "$user:$pass".toByteArray(Charsets.UTF_8)
            return "Basic " + Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val ha1 = md5("$user:$realm:$pass")
        val ha2 = md5("$method:$uri")
        val useQop = qop.contains("auth", ignoreCase = true)
        val cnonce = randomToken()
        nc++
        val ncValue = String.format("%08x", nc)
        val response = if (useQop) {
            md5("$ha1:$nonce:$ncValue:$cnonce:auth:$ha2")
        } else {
            md5("$ha1:$nonce:$ha2")
        }
        val builder = StringBuilder()
        builder.append("Digest username=\"").append(user).append("\"")
        builder.append(", realm=\"").append(realm).append("\"")
        builder.append(", nonce=\"").append(nonce).append("\"")
        builder.append(", uri=\"").append(uri).append("\"")
        builder.append(", response=\"").append(response).append("\"")
        builder.append(", algorithm=MD5")
        if (useQop) {
            builder.append(", qop=auth, nc=").append(ncValue)
            builder.append(", cnonce=\"").append(cnonce).append("\"")
        }
        if (opaque.isNotEmpty()) builder.append(", opaque=\"").append(opaque).append("\"")
        return builder.toString()
    }

    private fun parseChallenge(header: String): Boolean {
        val digestIndex = header.indexOf("Digest", ignoreCase = true)
        if (digestIndex < 0) {
            if (header.contains("Basic", ignoreCase = true)) {
                basicMode = true
                authReady = true
                return true
            }
            return false
        }
        basicMode = false
        val text = header.substring(digestIndex + 6)
        val items = ArrayList<String>()
        val builder = StringBuilder()
        var inQuote = false
        for (character in text) {
            if (character == '"') {
                inQuote = !inQuote
                builder.append(character)
            } else if (character == ',' && !inQuote) {
                items.add(builder.toString())
                builder.setLength(0)
            } else {
                builder.append(character)
            }
        }
        if (builder.isNotBlank()) items.add(builder.toString())
        for (item in items) {
            val equals = item.indexOf('=')
            if (equals <= 0) continue
            val key = item.substring(0, equals).trim().lowercase()
            var value = item.substring(equals + 1).trim()
            if (value.startsWith("\"")) value = value.trim('"')
            when (key) {
                "realm" -> realm = value
                "nonce" -> nonce = value
                "qop" -> qop = value
                "opaque" -> opaque = value
            }
        }
        authReady = nonce.isNotEmpty()
        return authReady
    }

    // ---------------------------------------------------------------- helpers

    private fun fail(message: String) {
        Log.w(TAG, message)
        running.set(false)
        listener.onError(message)
        runCatching { socket?.close() }
    }

    private fun resolveControl(base: String, control: String): String {
        val trimmed = control.trim()
        if (trimmed.startsWith("rtsp://", ignoreCase = true)) return trimmed
        if (trimmed.startsWith("/")) {
            val origin = Regex("^rtsp://[^/]+", RegexOption.IGNORE_CASE).find(base)?.value
            return if (origin != null) origin + trimmed else base
        }
        if (trimmed.isEmpty()) return base
        val normalized = if (base.endsWith("/")) base else "$base/"
        return normalized + trimmed
    }

    private fun parseInterleavedChannel(transport: String): Int {
        val match = Regex("interleaved=(\\d+)(?:-(\\d+))?").find(transport)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    }

    private fun rtpPayloadOffset(packet: ByteArray, length: Int): Int {
        if (length < 12) return -1
        val csrcCount = packet[0].toInt() and 0x0F
        val hasExtension = (packet[0].toInt() and 0x10) != 0
        var offset = 12 + csrcCount * 4
        if (hasExtension) {
            if (offset + 4 > length) return -1
            val extensionLength = ((packet[offset + 2].toInt() and 0xFF) shl 8) or
                (packet[offset + 3].toInt() and 0xFF)
            offset += 4 + extensionLength * 4
        }
        return if (offset < length) offset else -1
    }

    private fun rtpTimestamp(packet: ByteArray): Long {
        return ((packet[4].toLong() and 0xFF) shl 24) or
            ((packet[5].toLong() and 0xFF) shl 16) or
            ((packet[6].toLong() and 0xFF) shl 8) or
            (packet[7].toLong() and 0xFF)
    }

    private fun sleepQuietly(millis: Long) {
        try {
            Thread.sleep(millis)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    // ---------------------------------------------------------------- models

    private class RtspResponse(
        val code: Int,
        val statusLine: String,
        val headers: List<Pair<String, String>>,
        val body: String
    ) {
        fun header(name: String): String? =
            headers.firstOrNull { it.first.equals(name, ignoreCase = true) }?.second
    }

    private class CodecSpec(
        val kind: Int,
        val encoding: String,
        val rate: Int,
        val channels: Int,
        val alaw: Boolean,
        val csd: ByteArray?,
        val sizeLength: Int,
        val indexLength: Int,
        val indexDeltaLength: Int
    ) {
        val description: String
            get() {
                if (kind == KIND_G711) {
                    return "G.711 " + (if (alaw) "A-law" else "u-law") + " " + rate + "Hz"
                }
                if (kind == KIND_AAC) {
                    return "AAC " + rate + "Hz " + channels + "ch"
                }
                return encoding + " " + rate + "Hz"
            }

        companion object {
            const val KIND_G711 = 1
            const val KIND_AAC = 2

            fun of(track: SdpParser.Track): CodecSpec? {
                val name = track.encoding.uppercase()
                if (name == "PCMA") {
                    return CodecSpec(
                        KIND_G711,
                        name,
                        if (track.clockRate > 0) track.clockRate else 8000,
                        1,
                        true,
                        null,
                        13,
                        3,
                        3
                    )
                }
                if (name == "PCMU") {
                    return CodecSpec(
                        KIND_G711,
                        name,
                        if (track.clockRate > 0) track.clockRate else 8000,
                        1,
                        false,
                        null,
                        13,
                        3,
                        3
                    )
                }
                val isAac = name.contains("MPEG4-GENERIC") ||
                    name == "AAC" ||
                    name.contains("MPEG4")
                if (isAac) {
                    val config = track.fmtp["config"]?.let { hexToBytes(it) } ?: return null
                    return CodecSpec(
                        KIND_AAC,
                        name,
                        if (track.clockRate > 0) track.clockRate else 16000,
                        if (track.channels > 0) track.channels else 1,
                        false,
                        config,
                        track.fmtp["sizelength"]?.toIntOrNull() ?: 13,
                        track.fmtp["indexlength"]?.toIntOrNull() ?: 3,
                        track.fmtp["indexdeltalength"]?.toIntOrNull() ?: 3
                    )
                }
                return null
            }

            fun hexToBytes(text: String): ByteArray? {
                var value = text.trim()
                if (value.startsWith("0x", ignoreCase = true)) value = value.substring(2)
                if (value.isEmpty() || value.length % 2 != 0) return null
                return try {
                    ByteArray(value.length / 2) { index ->
                        value.substring(index * 2, index * 2 + 2).toInt(16).toByte()
                    }
                } catch (e: NumberFormatException) {
                    null
                }
            }
        }
    }

    private object SdpParser {

        class Track(
            val media: String,
            val payloadType: Int,
            val encoding: String,
            val clockRate: Int,
            val channels: Int,
            val control: String,
            val fmtp: Map<String, String>
        ) {
            val isAudio: Boolean get() = media == "audio"
        }

        fun parse(sdp: String): List<Track> {
            val tracks = ArrayList<Track>()
            var media = ""
            var firstPayload = -1
            var encoding = ""
            var clock = 0
            var channels = 1
            var control = ""
            var fmtp = HashMap<String, String>()

            for (rawLine in sdp.split("\n")) {
                val line = rawLine.trim()
                if (line.startsWith("m=")) {
                    if (media.isNotEmpty() && firstPayload >= 0 && encoding.isNotEmpty()) {
                        tracks.add(
                            Track(media, firstPayload, encoding, clock, channels, control, HashMap(fmtp))
                        )
                    }
                    media = ""
                    firstPayload = -1
                    encoding = ""
                    clock = 0
                    channels = 1
                    control = ""
                    fmtp = HashMap()
                    val parts = line.substring(2).split(' ')
                    media = parts.getOrNull(0) ?: ""
                    firstPayload = parts.getOrNull(3)?.toIntOrNull() ?: -1
                    continue
                }
                if (line.startsWith("a=rtpmap:")) {
                    val body = line.substring(9)
                    val payloadType = body.substringBefore(' ').toIntOrNull() ?: -1
                    if (firstPayload >= 0 && payloadType == firstPayload) {
                        val spec = body.substringAfter(' ', "")
                        val segments = spec.split('/')
                        encoding = segments.getOrNull(0) ?: ""
                        clock = segments.getOrNull(1)?.toIntOrNull() ?: 0
                        channels = segments.getOrNull(2)?.toIntOrNull() ?: 1
                    }
                    continue
                }
                if (line.startsWith("a=control:")) {
                    control = line.substring(10).trim()
                    continue
                }
                if (line.startsWith("a=fmtp:")) {
                    val body = line.substring(7)
                    val payloadType = body.substringBefore(' ').toIntOrNull() ?: -1
                    if (firstPayload >= 0 && payloadType == firstPayload) {
                        val params = body.substringAfter(' ', "")
                        for (pair in params.split(';')) {
                            val key = pair.substringBefore('=').trim()
                            if (key.isEmpty()) continue
                            fmtp[key] = pair.substringAfter('=', "").trim()
                        }
                    }
                }
            }
            if (media.isNotEmpty() && firstPayload >= 0 && encoding.isNotEmpty()) {
                tracks.add(Track(media, firstPayload, encoding, clock, channels, control, HashMap(fmtp)))
            }
            return tracks
        }
    }

    // ---------------------------------------------------------------- sinks

    private interface AudioSink {
        fun start()
        fun setVolume(value: Float)
        fun onPayload(data: ByteArray, offset: Int, length: Int, timestamp: Long)
        fun release()
    }

    private class G711Sink(private val rate: Int, private val alaw: Boolean) : AudioSink {
        private var track: AudioTrack? = null
        private val pcm = ShortArray(8192)

        override fun start() {
            val minBuffer = AudioTrack.getMinBufferSize(
                rate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = max(minBuffer, rate)
            val created = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            created.play()
            track = created
        }

        override fun setVolume(value: Float) {
            runCatching { track?.setVolume(value) }
        }

        override fun onPayload(data: ByteArray, offset: Int, length: Int, timestamp: Long) {
            val target = track ?: return
            val count = G711.decodeToPcm16(data, offset, length, alaw, pcm)
            if (count > 0) runCatching { target.write(pcm, 0, count) }
        }

        override fun release() {
            val target = track
            track = null
            runCatching {
                target?.stop()
                target?.release()
            }
        }
    }

    private class AacSink(private val spec: CodecSpec) : AudioSink {
        private var codec: MediaCodec? = null
        private var track: AudioTrack? = null
        private var sampleRate = spec.rate
        private var channelCount = spec.channels
        private val info = MediaCodec.BufferInfo()

        override fun start() {
            val csd = spec.csd ?: throw IOException("缺少 AAC config")
            val format = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                sampleRate,
                channelCount
            )
            format.setByteBuffer("csd-0", ByteBuffer.wrap(csd))
            val created = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            created.configure(format, null, null, 0)
            created.start()
            codec = created
        }

        override fun setVolume(value: Float) {
            runCatching { track?.setVolume(value) }
        }

        override fun onPayload(data: ByteArray, offset: Int, length: Int, timestamp: Long) {
            val decoder = codec ?: return
            val accessUnit = extractAccessUnit(data, offset, length, spec) ?: return
            val inputIndex = decoder.dequeueInputBuffer(3000)
            if (inputIndex >= 0) {
                val buffer = decoder.getInputBuffer(inputIndex)
                if (buffer != null) {
                    buffer.clear()
                    buffer.put(accessUnit)
                    val presentationTime = if (sampleRate > 0) {
                        timestamp * 1_000_000L / sampleRate
                    } else {
                        0L
                    }
                    decoder.queueInputBuffer(inputIndex, 0, accessUnit.size, presentationTime, 0)
                }
            }
            drain(decoder)
        }

        private fun drain(decoder: MediaCodec) {
            while (true) {
                val index = decoder.dequeueOutputBuffer(info, 0)
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val format = decoder.outputFormat
                    sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    runCatching {
                        track?.stop()
                        track?.release()
                    }
                    track = null
                    ensureTrack()
                } else if (index >= 0) {
                    val buffer = decoder.getOutputBuffer(index)
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        val chunk = ByteArray(info.size)
                        buffer.get(chunk)
                        runCatching { ensureTrack()?.write(chunk, 0, chunk.size) }
                    }
                    decoder.releaseOutputBuffer(index, false)
                } else {
                    break
                }
            }
        }

        private fun ensureTrack(): AudioTrack? {
            track?.let { return it }
            if (sampleRate <= 0) return null
            val channelMask = if (channelCount >= 2) {
                AudioFormat.CHANNEL_OUT_STEREO
            } else {
                AudioFormat.CHANNEL_OUT_MONO
            }
            val minBuffer = AudioTrack.getMinBufferSize(
                sampleRate,
                channelMask,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) return null
            val created = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setBufferSizeInBytes(max(minBuffer, sampleRate))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            created.play()
            track = created
            return created
        }

        override fun release() {
            val decoder = codec
            codec = null
            runCatching {
                decoder?.stop()
                decoder?.release()
            }
            val target = track
            track = null
            runCatching {
                target?.stop()
                target?.release()
            }
        }
    }

    private class BitReader(
        private val data: ByteArray,
        private val byteStart: Int,
        private val bitCount: Int
    ) {
        private var position = 0

        fun read(count: Int): Int {
            var value = 0
            var read = 0
            while (read < count && position < bitCount) {
                val byteIndex = byteStart + position / 8
                if (byteIndex >= data.size) break
                val bit = (data[byteIndex].toInt() shr (7 - (position % 8))) and 1
                value = (value shl 1) or bit
                position++
                read++
            }
            if (read < count) value = value shl (count - read)
            return value
        }
    }

    private companion object {
        private const val TAG = "HikAudio"
        private const val INTERLEAVED_MARK = 0x24

        private fun audioAttributes(): AudioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_ALL)
            .build()

        private fun md5(text: String): String {
            val digest = MessageDigest.getInstance("MD5")
            val bytes = digest.digest(text.toByteArray(Charsets.UTF_8))
            val builder = StringBuilder(bytes.size * 2)
            for (byte in bytes) builder.append(String.format("%02x", byte))
            return builder.toString()
        }

        private fun randomToken(): String =
            java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16)

        private fun extractAccessUnit(
            data: ByteArray,
            offset: Int,
            length: Int,
            spec: CodecSpec
        ): ByteArray? {
            if (length < 4) return null
            val bits = ((data[offset].toInt() and 0xFF) shl 8) or
                (data[offset + 1].toInt() and 0xFF)
            val headerBytes = (bits + 7) / 8
            if (headerBytes + 2 > length) return null
            val reader = BitReader(data, offset + 2, bits)
            var size = 0
            if (bits >= spec.sizeLength) {
                size = reader.read(spec.sizeLength)
                if (bits >= spec.sizeLength + spec.indexLength) {
                    reader.read(spec.indexLength)
                }
            }
            val dataStart = offset + 2 + headerBytes
            val available = offset + length - dataStart
            if (available <= 0) return null
            if (size <= 0 || size > available) {
                return data.copyOfRange(dataStart, offset + length)
            }
            return data.copyOfRange(dataStart, dataStart + size)
        }
    }
}
