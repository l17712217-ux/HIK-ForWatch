package com.hikwatch.util

import com.hikwatch.model.Camera
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * 设备在线检测：RTSP 或 ISAPI/HTTP 任一服务可连接即视为设备在线。
 * 对多设备场景使用有上限的并发，降低瞬时网络拥塞造成的误判。
 */
object OnlineChecker {
    private const val TIMEOUT_MS = 2200
    private const val MAX_PARALLEL = 24

    suspend fun check(cameras: List<Camera>): Map<String, Boolean> = coroutineScope {
        val limit = Semaphore(MAX_PARALLEL)
        withContext(Dispatchers.IO) {
            cameras.map { camera ->
                async { limit.withPermit { camera.id to probe(camera) } }
            }.awaitAll().toMap()
        }
    }

    private fun probe(camera: Camera): Boolean {
        if (camera.host.isBlank()) return false
        // 有些设备关闭 RTSP 或使用不同服务配置，但 HTTP/ISAPI 仍正常。
        return canConnect(camera.host, camera.rtspPort) || canConnect(camera.host, camera.httpPort)
    }

    private fun canConnect(host: String, port: Int): Boolean {
        if (port !in 1..65535) return false
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), TIMEOUT_MS)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
