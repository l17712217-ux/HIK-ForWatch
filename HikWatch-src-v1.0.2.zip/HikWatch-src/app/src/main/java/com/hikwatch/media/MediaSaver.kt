package com.hikwatch.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 截图 / 录像写入相册：Pictures/HikWatch、Movies/HikWatch。
 */
object MediaSaver {

    class VideoTarget(val uri: Uri, val pfd: ParcelFileDescriptor)

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun safe(name: String): String {
        val trimmed = name.trim().ifEmpty { "camera" }
        return trimmed.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_").take(24)
    }

    fun saveJpeg(context: Context, bytes: ByteArray, baseName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "HikWatch_${safe(baseName)}_${stamp()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HikWatch")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = runCatching {
            resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        }.getOrNull() ?: return null
        val ok = runCatching {
            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } != null
        }.getOrDefault(false)
        if (!ok) {
            runCatching { resolver.delete(uri, null, null) }
            return null
        }
        runCatching {
            resolver.update(
                uri,
                ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                null,
                null
            )
        }
        return uri
    }

    fun createVideoTarget(context: Context, baseName: String): VideoTarget? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "HikWatch_${safe(baseName)}_${stamp()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HikWatch")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = runCatching {
            resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        }.getOrNull() ?: return null
        val pfd = runCatching { resolver.openFileDescriptor(uri, "rw") }.getOrNull()
        if (pfd == null) {
            runCatching { resolver.delete(uri, null, null) }
            return null
        }
        return VideoTarget(uri, pfd)
    }

    fun publishVideo(context: Context, handle: VideoTarget) {
        runCatching {
            context.contentResolver.update(
                handle.uri,
                ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) },
                null,
                null
            )
        }
    }

    fun abandonVideo(context: Context, handle: VideoTarget) {
        runCatching { context.contentResolver.delete(handle.uri, null, null) }
    }
}
