package com.hikwatch.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hikwatch.R
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.net.HikApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 添加 / 编辑监控：所有输入都走 [TextInputActivity]（系统输入法）。
 */
class CameraEditActivity : Activity() {

    companion object {
        const val EXTRA_ID = "camera_id"
        private const val REQ_NAME = 4101
        private const val REQ_HOST = 4102
        private const val REQ_HTTP_PORT = 4103
        private const val REQ_RTSP_PORT = 4104
        private const val REQ_USER = 4105
        private const val REQ_PASS = 4106
        private const val REQ_CHANNEL = 4107
    }

    private lateinit var store: CameraStore
    private lateinit var listBox: LinearLayout
    private var draft = Camera()
    private var isNew = true
    private var testRunning = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        val id = intent.getStringExtra(EXTRA_ID)
        if (id != null) {
            store.find(id)?.let {
                draft = it
                isNew = false
            }
        }
        setContentView(buildRoot())
        rebuildRows()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val titleView = Ui.label(this, if (isNew) "添加监控" else "编辑监控", 14f, Ui.TEXT, bold = true)
        titleView.letterSpacing = 0.04f
        header.addView(titleView)
        header.addView(Ui.label(this, "海康 IPC / NVR 通道", 8.5f, Ui.TEXT3))
        root.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@CameraEditActivity, 16f) }
        )

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@CameraEditActivity, 48f)
                bottomMargin = Ui.dp(this@CameraEditActivity, 56f)
                leftMargin = Ui.dp(this@CameraEditActivity, 26f)
                rightMargin = Ui.dp(this@CameraEditActivity, 26f)
            }
        )

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = Ui.iconButton(this, R.drawable.ic_back, 30f, Ui.PANEL, Ui.TEXT) { finish() }
        bottom.addView(
            back,
            LinearLayout.LayoutParams(Ui.dp(this, 30f), Ui.dp(this, 30f)).apply {
                rightMargin = Ui.dp(this@CameraEditActivity, 7f)
            }
        )
        val test = Ui.pillButton(this, "测试连接", Ui.PANEL, Ui.TEXT, 30f, 11f) { testConnection() }
        val save = Ui.pillButton(this, "保存", Ui.ACCENT, Ui.ACCENT_DARK, 30f, 11f) { save() }
        bottom.addView(
            test,
            LinearLayout.LayoutParams(0, Ui.dp(this, 30f), 1f).apply {
                rightMargin = Ui.dp(this@CameraEditActivity, 7f)
            }
        )
        bottom.addView(save, LinearLayout.LayoutParams(0, Ui.dp(this, 30f), 1f))
        root.addView(
            bottom,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                bottomMargin = Ui.dp(this@CameraEditActivity, 22f)
                leftMargin = Ui.dp(this@CameraEditActivity, 26f)
                rightMargin = Ui.dp(this@CameraEditActivity, 26f)
            }
        )
        return root
    }

    private fun rebuildRows() {
        listBox.removeAllViews()

        listBox.addView(Ui.sectionLabel(this, "基础"))
        listBox.addView(row("名称", if (draft.name.isBlank()) "未命名" else draft.name) {
            input(REQ_NAME, "名称", "给这个监控起个名字", draft.name, false)
        })
        listBox.addView(row("设备地址", if (draft.host.isBlank()) "未填写" else draft.host) {
            input(REQ_HOST, "设备地址", "IP 或域名", draft.host, false)
        })

        listBox.addView(Ui.sectionLabel(this, "网络与认证"))
        listBox.addView(row("HTTP 端口", draft.httpPort.toString()) {
            input(REQ_HTTP_PORT, "HTTP 端口", "抓图与自检用", draft.httpPort.toString(), true)
        })
        listBox.addView(row("RTSP 端口", draft.rtspPort.toString()) {
            input(REQ_RTSP_PORT, "RTSP 端口", "实时画面用", draft.rtspPort.toString(), true)
        })
        listBox.addView(row("用户名", draft.user) {
            input(REQ_USER, "用户名", "海康默认 admin", draft.user, false)
        })
        listBox.addView(row("密码", if (draft.pass.isEmpty()) "未设置" else "••••••") {
            input(REQ_PASS, "密码", "摄像头密码", draft.pass, false)
        })

        listBox.addView(Ui.sectionLabel(this, "画面与连接"))
        listBox.addView(row("通道号", draft.channel.toString()) {
            input(REQ_CHANNEL, "通道号", "NVR 通道（从 1 开始）", draft.channel.toString(), true)
        })
        listBox.addView(row("码流", draft.streamLabel) {
            draft = draft.copy(subStream = !draft.subStream)
            rebuildRows()
        })
        listBox.addView(row("传输协议", if (draft.rtspTcp) "TCP" else "UDP") {
            draft = draft.copy(rtspTcp = !draft.rtspTcp)
            rebuildRows()
        })
        listBox.addView(row("连接模式", draft.modeLabel) {
            draft = draft.copy(
                mode = when (draft.mode) {
                    Camera.MODE_AUTO -> Camera.MODE_RTSP
                    Camera.MODE_RTSP -> Camera.MODE_SNAPSHOT
                    else -> Camera.MODE_AUTO
                }
            )
            rebuildRows()
        })
        if (!isNew) {
            listBox.addView(row("删除这个监控", "长按确认", danger = true) { confirmDelete() })
        }
    }

    private fun row(label: String, value: String, danger: Boolean = false, onClick: () -> Unit): View {
        val row = FrameLayout(this)
        row.background = Ui.ripple(Ui.solid(Ui.PANEL, Ui.dp(this, 18f).toFloat()))

        val name = Ui.label(this, label, 10.5f, if (danger) Ui.DANGER else Ui.TEXT2)
        row.addView(
            name,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = Ui.dp(this@CameraEditActivity, 12f) }
        )

        val valueView = Ui.label(this, value, 11f, if (danger) Ui.DANGER else Ui.TEXT, bold = true)
        valueView.maxLines = 1
        valueView.ellipsize = android.text.TextUtils.TruncateAt.END
        valueView.gravity = Gravity.END
        row.addView(
            valueView,
            FrameLayout.LayoutParams(
                Ui.dp(this, 110f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply {
                rightMargin = Ui.dp(this@CameraEditActivity, 12f)
                leftMargin = Ui.dp(this@CameraEditActivity, 4f)
            }
        )

        row.setOnClickListener { onClick() }
        row.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            Ui.dp(this, 40f)
        ).apply { bottomMargin = Ui.dp(this@CameraEditActivity, 6f) }
        return row
    }

    private fun input(requestCode: Int, title: String, hint: String, initial: String, numeric: Boolean) {
        startActivityForResult(
            TextInputActivity.intent(this, title, hint, initial, numeric),
            requestCode
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val value = data?.getStringExtra(TextInputActivity.EXTRA_RESULT).orEmpty()
        when (requestCode) {
            REQ_NAME -> draft = draft.copy(name = value)
            REQ_HOST -> draft = draft.copy(host = value)
            REQ_USER -> draft = draft.copy(user = value)
            REQ_PASS -> draft = draft.copy(pass = value)
            REQ_HTTP_PORT -> value.toIntOrNull()?.let {
                draft = draft.copy(httpPort = it.coerceIn(1, 65535))
            }
            REQ_RTSP_PORT -> value.toIntOrNull()?.let {
                draft = draft.copy(rtspPort = it.coerceIn(1, 65535))
            }
            REQ_CHANNEL -> value.toIntOrNull()?.let {
                draft = draft.copy(channel = it.coerceIn(1, 64))
            }
        }
        rebuildRows()
    }

    private fun save() {
        if (draft.host.isBlank()) {
            Ui.toast(this, "请先填写设备地址")
            return
        }
        if (draft.name.isBlank()) draft = draft.copy(name = draft.host)
        store.upsert(draft)
        Ui.toast(this, "已保存")
        finish()
    }

    private fun testConnection() {
        if (testRunning) return
        if (draft.host.isBlank()) {
            Ui.toast(this, "请先填写设备地址")
            return
        }
        testRunning = true
        Ui.toast(this, "正在连接…")
        val target = draft
        scope.launch {
            val result = withContext(Dispatchers.IO) { HikApi.test(target) }
            testRunning = false
            Ui.showMessage(
                this@CameraEditActivity,
                if (result.ok) "连接正常" else "连接失败",
                result.message
            )
        }
    }

    private fun confirmDelete() {
        val sheet = SheetDialog(this, "删除这个监控？")
        sheet.addItem("确认删除", danger = true) {
            store.delete(draft.id)
            Ui.toast(this, "已删除")
            finish()
        }
        sheet.addItem("取消") {}
        sheet.showSheet()
    }
}
