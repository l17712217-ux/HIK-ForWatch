package com.hikwatch.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * 全屏输入页：真正拉起系统输入法（带 adjustResize，表盘上不会被键盘顶飞）。
 * 结果通过 EXTRA_RESULT 返回。
 */
class TextInputActivity : Activity() {

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_HINT = "hint"
        const val EXTRA_INITIAL = "initial"
        const val EXTRA_NUMERIC = "numeric"
        const val EXTRA_RESULT = "result"

        fun intent(
            context: Context,
            title: String,
            hint: String,
            initial: String,
            numeric: Boolean
        ): Intent = Intent(context, TextInputActivity::class.java)
            .putExtra(EXTRA_TITLE, title)
            .putExtra(EXTRA_HINT, hint)
            .putExtra(EXTRA_INITIAL, initial)
            .putExtra(EXTRA_NUMERIC, numeric)
    }

    private lateinit var field: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(buildRoot())
        field.post {
            field.requestFocus()
            val imm = getSystemService(InputMethodManager::class.java)
            imm?.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun buildRoot(): View {
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val hint = intent.getStringExtra(EXTRA_HINT).orEmpty()
        val initial = intent.getStringExtra(EXTRA_INITIAL).orEmpty()
        val numeric = intent.getBooleanExtra(EXTRA_NUMERIC, false)

        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        head.addView(Ui.label(this, title, 13f, Ui.TEXT, bold = true))
        head.addView(Ui.label(this, hint, 8.5f, Ui.TEXT3))
        root.addView(
            head,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@TextInputActivity, 18f) }
        )

        val holder = FrameLayout(this)
        holder.background = Ui.solid(Ui.PANEL_SOLID, Ui.dp(this, 16f).toFloat())
        field = EditText(this).apply {
            setSingleLine(true)
            textSize = 15f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.TEXT3)
            background = null
            setPadding(Ui.dp(context, 12f), 0, Ui.dp(context, 12f), 0)
            setText(initial)
            setSelection(initial.length)
            inputType = if (numeric) {
                android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            } else {
                android.text.InputType.TYPE_CLASS_TEXT
            }
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    commit()
                    true
                } else {
                    false
                }
            }
        }
        holder.addView(
            field,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 42f)
            )
        )
        root.addView(
            holder,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 42f)
            ).apply {
                topMargin = Ui.dp(this@TextInputActivity, 52f)
                leftMargin = Ui.dp(this@TextInputActivity, 30f)
                rightMargin = Ui.dp(this@TextInputActivity, 30f)
            }
        )

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val cancel = Ui.pillButton(this, "取消", Ui.PANEL, Ui.TEXT2, 30f, 11f) { finish() }
        val ok = Ui.pillButton(this, "确定", Ui.ACCENT, Ui.ACCENT_DARK, 30f, 11f) { commit() }
        actions.addView(
            cancel,
            LinearLayout.LayoutParams(0, Ui.dp(this, 30f), 1f).apply {
                rightMargin = Ui.dp(this@TextInputActivity, 8f)
            }
        )
        actions.addView(ok, LinearLayout.LayoutParams(0, Ui.dp(this, 30f), 1f))
        root.addView(
            actions,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                bottomMargin = Ui.dp(this@TextInputActivity, 30f)
                leftMargin = Ui.dp(this@TextInputActivity, 46f)
                rightMargin = Ui.dp(this@TextInputActivity, 46f)
            }
        )
        return root
    }

    private fun commit() {
        val value = field.text?.toString()?.trim().orEmpty()
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(field.windowToken, 0)
        setResult(RESULT_OK, Intent().putExtra(EXTRA_RESULT, value))
        finish()
    }
}
