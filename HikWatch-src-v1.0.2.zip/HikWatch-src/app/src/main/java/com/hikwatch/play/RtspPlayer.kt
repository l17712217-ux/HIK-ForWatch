package com.hikwatch.play

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.TextureView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import com.hikwatch.model.Camera

/**
 * 基于 Media3 ExoPlayer 的海康 RTSP 实时画面。
 * 音频轨道在此关闭（海康默认 G.711，Media3 不支持），声音由 RtspAudioClient 单独负责。
 *
 * 用到的 RtspMediaSource / setVideoTextureView 等属于 Media3 的 unstable API，
 * 版本固定在 1.4.1，这里显式忽略 opt-in 提示。
 */
@SuppressLint("UnsafeOptInUsageError")
class RtspPlayer(
    private val context: Context,
    private val camera: Camera,
    private val texture: TextureView,
    private val callback: Callback
) {

    interface Callback {
        fun onState(text: String)
        fun onAspect(aspect: Float)
        fun onFirstFrame()
        fun onFatal(message: String)
    }

    private var player: ExoPlayer? = null
    private var retries = 0
    private var stopped = false

    fun start() {
        if (stopped) return
        releaseInternal()
        val exo = ExoPlayer.Builder(context)
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(600, 2500, 300, 600)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .build()
            )
            .build()
        player = exo
        runCatching { exo.setVideoTextureView(texture) }
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        val factory = RtspMediaSource.Factory().setForceUseRtpTcp(camera.rtspTcp)
        exo.setMediaSource(factory.createMediaSource(MediaItem.fromUri(Uri.parse(camera.rtspUrl()))))
        exo.addListener(object : Player.Listener {
            private var firstFrameSeen = false

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> callback.onState("连接中…")
                    Player.STATE_READY -> {
                        callback.onState("")
                        if (!firstFrameSeen) {
                            firstFrameSeen = true
                            callback.onFirstFrame()
                        }
                    }
                    Player.STATE_ENDED -> callback.onState("信号中断")
                    else -> Unit
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                val w = videoSize.width
                val h = videoSize.height
                if (w > 0 && h > 0) {
                    val ratio = videoSize.pixelWidthHeightRatio
                    val aspect = if (ratio > 0) w * ratio / h else w.toFloat() / h
                    if (aspect > 0.2f && aspect < 8f) callback.onAspect(aspect)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })
        callback.onState("连接中…")
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun handleError(error: PlaybackException) {
        if (stopped) return
        val detail = buildString {
            append(error.errorCodeName)
            val cause = error.cause?.message
            if (!cause.isNullOrBlank()) append("：").append(cause.take(90))
        }
        if (retries < 2) {
            retries++
            callback.onState("重连 $retries/2…")
            texture.postDelayed({
                if (!stopped) start()
            }, 1200L * retries)
        } else {
            callback.onState("")
            callback.onFatal(detail)
        }
    }

    fun retryNow() {
        stopped = false
        retries = 0
        start()
    }

    fun stop() {
        stopped = true
        releaseInternal()
    }

    private fun releaseInternal() {
        val exo = player
        player = null
        if (exo != null) {
            runCatching {
                exo.setVideoTextureView(null)
                exo.release()
            }
        }
    }
}
