package com.hikwatch.data

import android.content.Context
import com.hikwatch.model.Camera
import org.json.JSONArray

class CameraStore(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("hikwatch_v1", Context.MODE_PRIVATE)

    fun cameras(): MutableList<Camera> {
        val raw = sp.getString(KEY_CAMERAS, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<Camera>()
            for (i in 0 until arr.length()) out.add(Camera.fromJson(arr.getJSONObject(i)))
            out
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    /** 星标优先，其余保持原顺序 */
    fun sortedCameras(): MutableList<Camera> =
        cameras().sortedByDescending { it.starred }.toMutableList()

    fun save(list: List<Camera>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_CAMERAS, arr.toString()).apply()
    }

    fun upsert(camera: Camera) {
        val list = cameras()
        val index = list.indexOfFirst { it.id == camera.id }
        if (index >= 0) list[index] = camera else list.add(camera)
        save(list)
    }

    fun delete(id: String) {
        val list = cameras()
        list.removeAll { it.id == id }
        save(list)
    }

    fun find(id: String): Camera? = cameras().firstOrNull { it.id == id }

    fun toggleStar(id: String): Boolean {
        val list = cameras()
        val index = list.indexOfFirst { it.id == id }
        if (index < 0) return false
        val updated = list[index].copy(starred = !list[index].starred)
        list[index] = updated
        save(list)
        return updated.starred
    }

    // ---------------------------------------------------------------- 清晰度

    /** 流畅 / 标准 / 高清：决定用子码流还是主码流 */
    var quality: String
        get() = sp.getString(KEY_QUALITY, QUALITY_STANDARD) ?: QUALITY_STANDARD
        set(value) = sp.edit().putString(KEY_QUALITY, value).apply()

    fun subStreamFor(camera: Camera): Boolean = when (quality) {
        QUALITY_HD -> false
        QUALITY_SMOOTH -> true
        else -> camera.subStream
    }

    fun qualityLabel(): String = when (quality) {
        QUALITY_SMOOTH -> "流畅"
        QUALITY_HD -> "高清"
        else -> "标准"
    }

    // ------------------------------------------------------------ 画面比例

    var aspectMode: String
        get() = sp.getString(KEY_ASPECT_MODE, ASPECT_FILL) ?: ASPECT_FILL
        set(value) = sp.edit().putString(KEY_ASPECT_MODE, value).apply()

    var customAspect: Float
        get() = sp.getFloat(KEY_CUSTOM_ASPECT, 1.6f)
        set(value) = sp.edit().putFloat(KEY_CUSTOM_ASPECT, value.coerceIn(0.3f, 4f)).apply()

    fun aspectLabel(mode: String, custom: Float = customAspect): String = when (mode) {
        ASPECT_FIT -> "完整画面"
        ASPECT_16_9 -> "16 : 9"
        ASPECT_4_3 -> "4 : 3"
        ASPECT_CUSTOM -> String.format("%.2f : 1", custom)
        else -> "撑满全屏"
    }

    // -------------------------------------------------------------- 宫格数量

    var simultaneous: Int
        get() = sp.getInt(KEY_SIMULTANEOUS, 1)
        set(value) = sp.edit().putInt(KEY_SIMULTANEOUS, value.coerceIn(1, 9)).apply()

    // ------------------------------------------------------------ 其它设置

    var gridAllLive: Boolean
        get() = sp.getBoolean(KEY_ALL_LIVE, true)
        set(value) = sp.edit().putBoolean(KEY_ALL_LIVE, value).apply()

    var keepScreenOn: Boolean
        get() = sp.getBoolean(KEY_KEEP_ON, true)
        set(value) = sp.edit().putBoolean(KEY_KEEP_ON, value).apply()

    var recordWithAudio: Boolean
        get() = sp.getBoolean(KEY_REC_AUDIO, true)
        set(value) = sp.edit().putBoolean(KEY_REC_AUDIO, value).apply()

    var fillScreen: Boolean
        get() = sp.getBoolean(KEY_FILL_SCREEN, true)
        set(value) = sp.edit().putBoolean(KEY_FILL_SCREEN, value).apply()

    // 观看页控件开关
    var showPhoto: Boolean
        get() = sp.getBoolean(KEY_SHOW_PHOTO, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_PHOTO, value).apply()

    var showRecord: Boolean
        get() = sp.getBoolean(KEY_SHOW_RECORD, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_RECORD, value).apply()

    var showAspect: Boolean
        get() = sp.getBoolean(KEY_SHOW_ASPECT, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_ASPECT, value).apply()

    var showSound: Boolean
        get() = sp.getBoolean(KEY_SHOW_SOUND, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_SOUND, value).apply()

    var showMulti: Boolean
        get() = sp.getBoolean(KEY_SHOW_MULTI, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_MULTI, value).apply()

    var showSwitch: Boolean
        get() = sp.getBoolean(KEY_SHOW_SWITCH, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_SWITCH, value).apply()

    var showBack: Boolean
        get() = sp.getBoolean(KEY_SHOW_BACK, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_BACK, value).apply()

    var showTopBar: Boolean
        get() = sp.getBoolean(KEY_SHOW_TOP_BAR, true)
        set(value) = sp.edit().putBoolean(KEY_SHOW_TOP_BAR, value).apply()

    fun hiddenControlCount(): Int {
        var hidden = 0
        if (!showPhoto) hidden++
        if (!showRecord) hidden++
        if (!showAspect) hidden++
        if (!showSound) hidden++
        if (!showMulti) hidden++
        if (!showSwitch) hidden++
        if (!showBack) hidden++
        if (!showTopBar) hidden++
        return hidden
    }

    companion object {
        const val QUALITY_SMOOTH = "smooth"
        const val QUALITY_STANDARD = "standard"
        const val QUALITY_HD = "hd"

        const val ASPECT_FILL = "fill"
        const val ASPECT_FIT = "fit"
        const val ASPECT_16_9 = "16:9"
        const val ASPECT_4_3 = "4:3"
        const val ASPECT_CUSTOM = "custom"

        private const val KEY_CAMERAS = "cameras"
        private const val KEY_QUALITY = "quality"
        private const val KEY_ASPECT_MODE = "aspect_mode"
        private const val KEY_CUSTOM_ASPECT = "custom_aspect"
        private const val KEY_SIMULTANEOUS = "simultaneous"
        private const val KEY_ALL_LIVE = "grid_all_live"
        private const val KEY_KEEP_ON = "keep_screen_on"
        private const val KEY_REC_AUDIO = "record_audio"
        private const val KEY_FILL_SCREEN = "fill_screen"
        private const val KEY_SHOW_PHOTO = "show_photo_btn"
        private const val KEY_SHOW_RECORD = "show_record_btn"
        private const val KEY_SHOW_ASPECT = "show_aspect_btn"
        private const val KEY_SHOW_SOUND = "show_sound_btn"
        private const val KEY_SHOW_MULTI = "show_multi_btn"
        private const val KEY_SHOW_SWITCH = "show_switch_btn"
        private const val KEY_SHOW_BACK = "show_back_btn"
        private const val KEY_SHOW_TOP_BAR = "show_top_bar"
    }
}
