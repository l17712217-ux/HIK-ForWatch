package com.hikwatch.data

/**
 * 内置设备（可选）。
 *
 * 发布用源码包里这个列表是空的，避免把具体项目的设备地址带出去。
 * 需要内置摄像头时，把 IP 填进下面列表即可：首次启动会自动写入
 * IPC-01…IPC-nn（HTTP 80 / RTSP 554 / 账号取 CameraSeeder 的默认值）。
 */
object SeedCameras {

    const val SEED_VERSION = 1

    val IPS: List<String> = emptyList()
}
