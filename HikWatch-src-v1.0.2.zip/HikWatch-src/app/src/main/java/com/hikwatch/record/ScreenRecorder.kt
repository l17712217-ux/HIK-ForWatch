package com.hikwatch.record

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/**
 * 屏幕录制（H.264 + AAC 回放采集）。
 *
 * 针对"点录制就闪退"做过重构：
 * 1) [stop] 只投递停止信号，**绝不阻塞主线程**（旧实现会在主线程 join 编码线程，容易 ANR 被杀）；
 * 2) 结束信号（EOS）与收尾都在工作线程完成，带 3 秒兜底超时；
 * 3) 每个阶段都套 try/catch，失败只回调错误并释放资源，不抛到主线程；
 * 4) [onFinished] 在主线程回调一次，调用方据此关闭文件描述符、发布相册条目。
 */
class ScreenRecorder(
    private val context: Context,
    private val projection: MediaProjection,
    private val target: ParcelFileDescriptor,
    private val width: Int,
    private val height: Int,
    private val withAudio: Boolean,
    private val onError: (String) -> Unit,
    private val onFinished: () -> Unit
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val stopRequested = AtomicBoolean(false)
    private val finished = AtomicBoolean(false)

    private var muxer: MediaMuxer? = null
    private var videoEncoder: MediaCodec? = null
    private var audioEncoder: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var worker: Thread? = null
    private var muxerStarted = false

    val isRunning: Boolean get() = running.get()

    fun start(): Boolean {
        if (!running.compareAndSet(false, true)) return true
        return try {
            prepare()
            startWorker()
            true
        } catch (t: Throwable) {
            Log.w(TAG, "start failed", t)
            fail("录像启动失败：" + (t.message ?: t.javaClass.simpleName))
            false
        }
    }

    /** 只投递停止信号，立即返回 */
    fun stop() {
        stopRequested.set(true)
    }

    // ------------------------------------------------------------- prepare

    private fun prepare() {
        val w = max(2, (width / 2) * 2)
        val h = max(2, (height / 2) * 2)
        val density = context.resources.displayMetrics.densityDpi

        muxer = MediaMuxer(target.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            )
            setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 20)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val video = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        video.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = video.createInputSurface()
        video.start()
        videoEncoder = video

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                stopRequested.set(true)
            }
        }
        projection.registerCallback(callback, mainHandler)
        projectionCallback = callback

        virtualDisplay = projection.createVirtualDisplay(
            "HikWatchRec",
            w, h, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            inputSurface,
            null,
            null
        )

        if (withAudio) startAudioQuietly()
    }

    /** 回放采集需要 RECORD_AUDIO，调用方已申请；失败就静音录制 */
    @SuppressLint("MissingPermission")
    private fun startAudioQuietly() {
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(
                44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val record = AudioRecord.Builder()
                .setAudioFormat(format)
                .setAudioPlaybackCaptureConfig(config)
                .setBufferSizeInBytes(max(minBuffer * 2, 16384))
                .build()
            record.startRecording()
            audioRecord = record

            val audioFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 1
            ).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, 96000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            }
            val audio = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            audio.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            audio.start()
            audioEncoder = audio
        } catch (t: Throwable) {
            Log.w(TAG, "audio capture unavailable, fallback to silent video", t)
            runCatching { audioRecord?.release() }
            audioRecord = null
            runCatching { audioEncoder?.release() }
            audioEncoder = null
        }
    }

    private fun startWorker() {
        val thread = Thread({ loop() }, "hik-recorder")
        thread.isDaemon = true
        worker = thread
        thread.start()
    }

    // ---------------------------------------------------------------- loop

    private fun loop() {
        val videoInfo = MediaCodec.BufferInfo()
        val audioInfo = MediaCodec.BufferInfo()
        var videoFormat: MediaFormat? = null
        var audioFormat: MediaFormat? = null
        var videoTrack = -1
        var audioTrack = -1
        var videoDone = false
        var audioDone = audioEncoder == null
        var videoBase = -1L
        var audioBase = -1L
        var eosSent = false
        var eosDeadline = 0L
        val pcm = ByteArray(8192)
        val mux = muxer

        try {
            if (mux == null) return
            while (true) {
                if (stopRequested.get() && !eosSent) {
                    eosSent = true
                    eosDeadline = SystemClock.elapsedRealtime() + 3000
                    runCatching { videoEncoder?.signalEndOfInputStream() }
                    runCatching {
                        val index = audioEncoder?.dequeueInputBuffer(20_000) ?: -1
                        if (index >= 0) {
                            audioEncoder?.queueInputBuffer(
                                index, 0, 0, System.nanoTime() / 1000,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                        }
                    }
                }

                // ---- 音频采集 → 编码
                val audioEnc = audioEncoder
                val record = audioRecord
                if (!audioDone && audioEnc != null && record != null) {
                    val index = audioEnc.dequeueInputBuffer(0)
                    if (index >= 0) {
                        val buffer = audioEnc.getInputBuffer(index)
                        if (buffer != null) {
                            val size = min(pcm.size, buffer.capacity())
                            val read = if (size > 0) record.read(pcm, 0, size) else 0
                            buffer.clear()
                            if (read > 0) {
                                buffer.put(pcm, 0, read)
                                audioEnc.queueInputBuffer(index, 0, read, System.nanoTime() / 1000, 0)
                            } else {
                                audioEnc.queueInputBuffer(index, 0, 0, System.nanoTime() / 1000, 0)
                            }
                        } else {
                            audioEnc.queueInputBuffer(index, 0, 0, System.nanoTime() / 1000, 0)
                        }
                    }
                }

                // ---- 视频编码输出
                val videoEnc = videoEncoder
                if (!videoDone && videoEnc != null) {
                    val index = videoEnc.dequeueOutputBuffer(videoInfo, 0)
                    if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        videoFormat = videoEnc.outputFormat
                    } else if (index >= 0) {
                        val buffer = videoEnc.getOutputBuffer(index)
                        var size = videoInfo.size
                        if (videoInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) size = 0
                        if (size > 0 && buffer != null) {
                            if (videoBase < 0) videoBase = videoInfo.presentationTimeUs
                            if (!muxerStarted && videoFormat != null &&
                                (audioEncoder == null || audioFormat != null)
                            ) {
                                videoTrack = mux.addTrack(videoFormat)
                                if (audioEncoder != null && audioFormat != null) {
                                    audioTrack = mux.addTrack(audioFormat)
                                }
                                mux.start()
                                muxerStarted = true
                            }
                            if (muxerStarted && videoTrack >= 0) {
                                buffer.position(videoInfo.offset)
                                buffer.limit(videoInfo.offset + size)
                                val info = MediaCodec.BufferInfo().apply {
                                    set(
                                        videoInfo.offset,
                                        size,
                                        (videoInfo.presentationTimeUs - videoBase).coerceAtLeast(0L),
                                        videoInfo.flags
                                    )
                                }
                                runCatching { mux.writeSampleData(videoTrack, buffer, info) }
                            }
                        }
                        if (videoInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            videoDone = true
                        }
                        videoEnc.releaseOutputBuffer(index, false)
                    }
                }

                // ---- 音频编码输出
                val audioEncOut = audioEncoder
                if (!audioDone && audioEncOut != null) {
                    val index = audioEncOut.dequeueOutputBuffer(audioInfo, 0)
                    if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        audioFormat = audioEncOut.outputFormat
                    } else if (index >= 0) {
                        val buffer = audioEncOut.getOutputBuffer(index)
                        var size = audioInfo.size
                        if (audioInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) size = 0
                        if (size > 0 && buffer != null) {
                            if (audioBase < 0) audioBase = audioInfo.presentationTimeUs
                            if (muxerStarted && audioTrack >= 0) {
                                buffer.position(audioInfo.offset)
                                buffer.limit(audioInfo.offset + size)
                                val info = MediaCodec.BufferInfo().apply {
                                    set(
                                        audioInfo.offset,
                                        size,
                                        (audioInfo.presentationTimeUs - audioBase).coerceAtLeast(0L),
                                        audioInfo.flags
                                    )
                                }
                                runCatching { mux.writeSampleData(audioTrack, buffer, info) }
                            }
                        }
                        if (audioInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            audioDone = true
                        }
                        audioEncOut.releaseOutputBuffer(index, false)
                    }
                }

                if (videoDone && audioDone) break
                if (eosSent && SystemClock.elapsedRealtime() > eosDeadline) {
                    Log.w(TAG, "recorder EOS timeout, finish anyway")
                    break
                }
                Thread.sleep(2)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "record loop error", t)
            postError("录像异常：" + (t.message ?: t.javaClass.simpleName))
        } finally {
            releaseAll()
            notifyFinished()
        }
    }

    // -------------------------------------------------------------- release

    private fun releaseAll() {
        running.set(false)
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        audioRecord = null
        runCatching { videoEncoder?.stop() }
        runCatching { videoEncoder?.release() }
        videoEncoder = null
        runCatching { audioEncoder?.stop() }
        runCatching { audioEncoder?.release() }
        audioEncoder = null
        projectionCallback?.let { callback ->
            runCatching { projection.unregisterCallback(callback) }
        }
        projectionCallback = null
        if (muxerStarted) runCatching { muxer?.stop() }
        runCatching { muxer?.release() }
        muxer = null
        muxerStarted = false
    }

    private fun fail(message: String) {
        postError(message)
        releaseAll()
        running.set(false)
        notifyFinished()
    }

    private fun postError(message: String) {
        mainHandler.post { runCatching { onError(message) } }
    }

    private fun notifyFinished() {
        if (!finished.compareAndSet(false, true)) return
        mainHandler.post { runCatching { onFinished() } }
    }

    private companion object {
        const val TAG = "HikRecorder"
    }
}
