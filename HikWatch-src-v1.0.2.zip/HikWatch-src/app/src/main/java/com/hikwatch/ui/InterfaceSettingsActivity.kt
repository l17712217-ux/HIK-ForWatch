package com.hikwatch.ui

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hikwatch.R
import com.hikwatch.data.CameraStore

/** 界面设置：功能键显隐 + 同时观看数量 + 一键精简 */
class InterfaceSettingsActivity : Activity() {

    private lateinit var store: CameraStore
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        setContentView(buildRoot())
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val header = Ui.label(this, "界面设置", 13.5f, Ui.TEXT, bold = true)
        header.letterSpacing = 0.06f
        root.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@InterfaceSettingsActivity, 18f) }
        )

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@InterfaceSettingsActivity, 50f)
                bottomMargin = Ui.dp(this@InterfaceSettingsActivity, 50f)
                leftMargin = Ui.dp(this@InterfaceSettingsActivity, 26f)
                rightMargin = Ui.dp(this@InterfaceSettingsActivity, 26f)
            }
        )

        val back = Ui.iconButton(this, R.drawable.ic_back, 32f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 32f),
                Ui.dp(this, 32f),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@InterfaceSettingsActivity, 7f) }
        )
        return root
    }

    override fun onResume() {
        super.onResume()
        rebuildRows()
    }

    private fun rebuildRows() {
        listBox.removeAllViews()

        listBox.addView(Ui.sectionLabel(this, "功能键"))
        toggle("拍照", store.showPhoto) { store.showPhoto = it }
        toggle("录像", store.showRecord) { store.showRecord = it }
        toggle("画面比例", store.showAspect) { store.showAspect = it }
        toggle("声音", store.showSound) { store.showSound = it }
        toggle("同时观看", store.showMulti) { store.showMulti = it }
        toggle("切换摄像头", store.showSwitch) { store.showSwitch = it }
        toggle("返回键", store.showBack) { store.showBack = it }
        toggle("顶部信息条", store.showTopBar) { store.showTopBar = it }

        listBox.addView(Ui.sectionLabel(this, "同时观看数量"))
        for (count in listOf(1, 2, 4, 6, 9)) {
            listBox.addView(
                Ui.settingRow(
                    this,
                    count.toString() + " 路",
                    if (store.simultaneous == count) "✓" else ""
                ) {
                    store.simultaneous = count
                    rebuildRows()
                }
            )
        }

        listBox.addView(Ui.sectionLabel(this, "快捷方式"))
        listBox.addView(
            Ui.settingRow(this, "一键精简：只留画面", "执行") {
                store.showPhoto = false
                store.showRecord = false
                store.showAspect = false
                store.showSound = false
                store.showMulti = false
                store.showSwitch = false
                store.showTopBar = false
                store.showBack = true
                rebuildRows()
                Ui.toast(this, "已精简")
            }
        )
        listBox.addView(
            Ui.settingRow(this, "恢复全部控件", "恢复") {
                store.showPhoto = true
                store.showRecord = true
                store.showAspect = true
                store.showSound = true
                store.showMulti = true
                store.showSwitch = true
                store.showBack = true
                store.showTopBar = true
                rebuildRows()
                Ui.toast(this, "已恢复")
            }
        )
    }

    private fun toggle(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        listBox.addView(
            Ui.settingRow(this, title, if (value) "开" else "关") {
                onChange(!value)
                rebuildRows()
            }
        )
    }
}
