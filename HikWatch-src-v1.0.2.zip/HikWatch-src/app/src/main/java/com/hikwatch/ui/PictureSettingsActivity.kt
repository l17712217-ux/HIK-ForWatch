package com.hikwatch.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.hikwatch.R
import com.hikwatch.data.CameraStore

/** 画面设置：清晰度 / 画面比例 / 多路策略 / 常亮 / 录像声音 */
class PictureSettingsActivity : Activity() {

    private lateinit var store: CameraStore
    private lateinit var listBox: LinearLayout

    private val requestCustomAspect = 4201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        setContentView(buildRoot())
    }

    override fun onResume() {
        super.onResume()
        rebuildRows()
    }

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val header = Ui.label(this, "画面设置", 13.5f, Ui.TEXT, bold = true)
        header.letterSpacing = 0.06f
        root.addView(
            header,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@PictureSettingsActivity, 18f) }
        )

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@PictureSettingsActivity, 50f)
                bottomMargin = Ui.dp(this@PictureSettingsActivity, 50f)
                leftMargin = Ui.dp(this@PictureSettingsActivity, 26f)
                rightMargin = Ui.dp(this@PictureSettingsActivity, 26f)
            }
        )

        val back = Ui.iconButton(this, R.drawable.ic_back, 32f, Ui.PANEL, Ui.TEXT) { finish() }
        root.addView(
            back,
            FrameLayout.LayoutParams(
                Ui.dp(this, 32f),
                Ui.dp(this, 32f),
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@PictureSettingsActivity, 7f) }
        )
        return root
    }

    private fun rebuildRows() {
        listBox.removeAllViews()

        listBox.addView(Ui.sectionLabel(this, "清晰度"))
        listBox.addView(
            Ui.settingRow(this, "流畅（子码流）", if (store.quality == CameraStore.QUALITY_SMOOTH) "✓" else "", accent = true) {
                store.quality = CameraStore.QUALITY_SMOOTH
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "标准（跟随设备）", if (store.quality == CameraStore.QUALITY_STANDARD) "✓" else "", accent = true) {
                store.quality = CameraStore.QUALITY_STANDARD
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "高清（主码流）", if (store.quality == CameraStore.QUALITY_HD) "✓" else "", accent = true) {
                store.quality = CameraStore.QUALITY_HD
                rebuildRows()
            }
        )

        listBox.addView(Ui.sectionLabel(this, "画面比例"))
        listBox.addView(
            Ui.settingRow(this, "撑满全屏", if (store.aspectMode == CameraStore.ASPECT_FILL) "✓" else "") {
                store.aspectMode = CameraStore.ASPECT_FILL
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "完整画面", if (store.aspectMode == CameraStore.ASPECT_FIT) "✓" else "") {
                store.aspectMode = CameraStore.ASPECT_FIT
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "16 : 9", if (store.aspectMode == CameraStore.ASPECT_16_9) "✓" else "") {
                store.aspectMode = CameraStore.ASPECT_16_9
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "4 : 3", if (store.aspectMode == CameraStore.ASPECT_4_3) "✓" else "") {
                store.aspectMode = CameraStore.ASPECT_4_3
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "自定义比例", store.aspectLabel(CameraStore.ASPECT_CUSTOM)) {
                startActivityForResult(
                    TextInputActivity.intent(
                        this,
                        "自定义比例",
                        "宽 / 高，例如 1.85",
                        String.format("%.2f", store.customAspect),
                        true
                    ),
                    requestCustomAspect
                )
            }
        )

        listBox.addView(Ui.sectionLabel(this, "播放与录制"))
        listBox.addView(
            Ui.settingRow(this, "多路同屏全部实时", if (store.gridAllLive) "开" else "关") {
                store.gridAllLive = !store.gridAllLive
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "保持屏幕常亮", if (store.keepScreenOn) "开" else "关") {
                store.keepScreenOn = !store.keepScreenOn
                rebuildRows()
            }
        )
        listBox.addView(
            Ui.settingRow(this, "录像包含声音", if (store.recordWithAudio) "开" else "关") {
                store.recordWithAudio = !store.recordWithAudio
                rebuildRows()
            }
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCustomAspect || resultCode != RESULT_OK) return
        val value = data?.getStringExtra(TextInputActivity.EXTRA_RESULT).orEmpty()
        val ratio = value.replace(',', '.').toFloatOrNull()
        if (ratio == null || ratio < 0.3f || ratio > 4f) {
            Ui.toast(this, "请输入 0.3 ~ 4.0 之间的比例")
            return
        }
        store.customAspect = ratio
        store.aspectMode = CameraStore.ASPECT_CUSTOM
        rebuildRows()
    }
}
