package com.hikwatch.net

import com.hikwatch.model.Camera

/**
 * 海康 ISAPI 相关能力：设备检测、高清抓图。
 */
object HikApi {

    data class TestResult(val ok: Boolean, val message: String)

    /** 连接自检：先读设备信息（验证认证），再试抓一张图。 */
    fun test(cam: Camera): TestResult {
        if (cam.host.isBlank()) return TestResult(false, "请先填写设备地址")
        val http = DigestHttp(cam.user, cam.pass)
        val info = http.get(cam.isapi("/ISAPI/System/deviceInfo"), 6000)
        when {
            info.code == 401 -> return TestResult(false, "用户名或密码错误")
            info.code == 0 -> return TestResult(false, "无法连接：${info.error}")
            info.code != 200 -> return TestResult(
                false,
                "ISAPI 不可用（HTTP ${info.code}）\n可把连接模式改为「仅实时」，只用 RTSP"
            )
        }
        val xml = String(info.body, Charsets.UTF_8)
        val model = Regex("<model>(.*?)</model>").find(xml)?.groupValues?.getOrNull(1).orEmpty()
        val firmware = Regex("<firmwareVersion>(.*?)</firmwareVersion>")
            .find(xml)?.groupValues?.getOrNull(1).orEmpty()

        val snap = http.get(cam.snapshotUrl(), 8000)
        val snapText = when {
            snap.code == 200 && snap.body.size > 1000 -> "抓图正常（${snap.body.size / 1024} KB）"
            snap.code == 200 -> "抓图返回内容异常"
            snap.code == 401 -> "抓图认证失败"
            snap.code == 0 -> "抓图失败：${snap.error}"
            else -> "抓图失败（HTTP ${snap.code}）"
        }
        val title = if (model.isNotBlank()) model else "海康设备"
        val fw = if (firmware.isNotBlank()) "\n固件 ${firmware.take(20)}" else ""
        return TestResult(true, "$title$fw\n$snapText")
    }

    /** 抓一张原始 JPEG（高清）。失败返回 null。 */
    fun snapshotBytes(cam: Camera, timeoutMs: Int = 9000): ByteArray? {
        val http = DigestHttp(cam.user, cam.pass)
        val r = http.get(cam.snapshotUrl(), timeoutMs)
        return if (r.code == 200 && r.body.size > 512) r.body else null
    }

    fun snapshotError(cam: Camera): String {
        val http = DigestHttp(cam.user, cam.pass)
        val r = http.get(cam.snapshotUrl(), 7000)
        return if (r.code == 200) "内容为空" else if (r.error.isNotEmpty()) r.error else "HTTP ${r.code}"
    }
}
