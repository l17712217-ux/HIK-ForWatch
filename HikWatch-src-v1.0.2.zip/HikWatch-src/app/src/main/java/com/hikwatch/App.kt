package com.hikwatch

import android.app.Application
import com.hikwatch.data.CameraSeeder
import com.hikwatch.theme.ThemeManager
import com.hikwatch.util.CrashLog

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        ThemeManager.init(this)
        // 内置的 59 台设备在首次启动时写入（幂等，已存在不会重复）
        runCatching { CameraSeeder.ensureSeeded(this) }
    }
}
