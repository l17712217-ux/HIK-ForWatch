package com.hikwatch

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import androidx.test.core.app.ApplicationProvider
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.theme.ThemeManager
import com.hikwatch.theme.Themes
import com.hikwatch.ui.AlbumActivity
import com.hikwatch.ui.CameraEditActivity
import com.hikwatch.ui.InterfaceSettingsActivity
import com.hikwatch.ui.LiveActivity
import com.hikwatch.ui.MainActivity
import com.hikwatch.ui.PictureSettingsActivity
import com.hikwatch.ui.SettingsActivity
import com.hikwatch.ui.TextInputActivity
import com.hikwatch.ui.ThemeSettingsActivity
import com.hikwatch.ui.Ui
import com.hikwatch.ui.VideoTile
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.io.FileOutputStream

/**
 * 用 Robolectric 原生图形模式（真实 Skia）把 App 真实界面渲染成 PNG，
 * 供电脑上的"虚拟手表"预览使用。视频区域是占位帧（预览环境没有解码器）。
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [33], qualifiers = "w240dp-h240dp-xhdpi")
class ScreenshotTest {

    private val size = 480
    private val outDir = File("preview/raw").apply { mkdirs() }
    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    private fun seedCameras(): List<Camera> {
        val store = CameraStore(context)
        store.cameras().forEach { store.delete(it.id) }
        val cameras = listOf(
            Camera(name = "门口枪机", host = "192.168.1.64", channel = 1, subStream = false, starred = true),
            Camera(name = "仓库通道2", host = "192.168.1.65", channel = 2, subStream = true),
            Camera(name = "车库入口", host = "192.168.1.66", channel = 1, subStream = true, starred = true),
            Camera(name = "后院球机", host = "192.168.1.67", channel = 3, subStream = true),
            Camera(name = "走廊尽头", host = "192.168.1.68", channel = 1, subStream = true),
            Camera(name = "大厅全景", host = "192.168.1.69", channel = 2, subStream = true)
        )
        cameras.forEach { store.upsert(it) }
        store.quality = CameraStore.QUALITY_STANDARD
        store.aspectMode = CameraStore.ASPECT_FILL
        store.simultaneous = 1
        store.showPhoto = true
        store.showRecord = true
        store.showAspect = true
        store.showSound = true
        store.showMulti = true
        store.showSwitch = true
        store.showBack = true
        store.showTopBar = true
        return store.sortedCameras()
    }

    @Test
    fun captureAll() {
        ThemeManager.select(Themes.byId("aurora"))
        val cameras = seedCameras()
        val ids = cameras.joinToString(",") { it.id }

        // 首页（空）
        CameraStore(context).cameras().forEach { CameraStore(context).delete(it.id) }
        render("01_home_empty", Robolectric.buildActivity(MainActivity::class.java).setup().get())

        // 首页（有设备）
        seedCameras()
        render("02_home_list", Robolectric.buildActivity(MainActivity::class.java).setup().get())

        // 首页（热带主题）
        ThemeManager.select(Themes.byId("tropic"))
        render("03_home_tropic", Robolectric.buildActivity(MainActivity::class.java).setup().get())
        ThemeManager.select(Themes.byId("aurora"))

        // 添加监控
        render("04_camera_edit", Robolectric.buildActivity(CameraEditActivity::class.java).create().get())

        // 输入页（系统输入法）
        val inputIntent = TextInputActivity.intent(context, "设备地址", "IP 或域名", "192.168.1.64", false)
        render("05_text_input", Robolectric.buildActivity(TextInputActivity::class.java, inputIntent).create().get())

        // 设置三层
        render("06_settings", Robolectric.buildActivity(SettingsActivity::class.java).setup().get())
        render("07_picture_settings", Robolectric.buildActivity(PictureSettingsActivity::class.java).setup().get())
        render("08_interface_settings", Robolectric.buildActivity(InterfaceSettingsActivity::class.java).setup().get())
        render("09_theme_settings", Robolectric.buildActivity(ThemeSettingsActivity::class.java).setup().get())

        // 相册
        render("10_album", Robolectric.buildActivity(AlbumActivity::class.java).setup().get())

        // 监控页
        render("11_live_single", liveActivity(1, ids))
        render("12_live_six", liveActivity(6, ids))

        // 精简模式
        val store = CameraStore(context)
        store.showPhoto = false
        store.showRecord = false
        store.showAspect = false
        store.showSound = false
        store.showMulti = false
        store.showSwitch = false
        store.showTopBar = false
        store.showBack = true
        render("13_live_minimal", liveActivity(1, ids))
        seedCameras()

        // 弹层
        drawSheetMenu(cameras)
        drawMessage()
    }

    // ------------------------------------------------------------- rendering

    private fun liveActivity(layout: Int, ids: String): Activity {
        val intent = Intent(context, LiveActivity::class.java)
            .putExtra(LiveActivity.EXTRA_LAYOUT, layout)
            .putExtra(LiveActivity.EXTRA_IDS, ids)
        return Robolectric.buildActivity(LiveActivity::class.java, intent).create().get()
    }

    private fun render(name: String, activity: Activity, dialog: Dialog? = null) {
        val root = activity.window.decorView
        forceLayout(root)
        arrangeLiveTiles(activity)
        forceLayout(root)
        fillVideoPlaceholders(root)
        forceLayout(root)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        root.draw(canvas)
        if (dialog != null) drawDialog(canvas, dialog)
        save(name, bitmap)
    }

    /** 预览环境没有真实 ViewRootImpl，直接调用一次内部 arrangeTiles 保证磁贴尺寸正确 */
    private fun arrangeLiveTiles(activity: Activity) {
        if (activity !is LiveActivity) return
        runCatching {
            val method = LiveActivity::class.java.getDeclaredMethod("arrangeTiles")
            method.isAccessible = true
            method.invoke(activity)
        }
    }

    private fun forceLayout(root: View) {
        repeat(4) {
            root.requestLayout()
            root.measure(
                View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY)
            )
            root.layout(0, 0, size, size)
        }
    }

    private fun save(name: String, bitmap: Bitmap) {
        FileOutputStream(File(outDir, "$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        println("SHOT $name")
    }

    private fun drawDialog(canvas: Canvas, dialog: Dialog) {
        val decor = dialog.window?.decorView ?: return
        decor.measure(
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.AT_MOST)
        )
        val width = decor.measuredWidth
        val height = decor.measuredHeight
        decor.layout(0, 0, width, height)
        canvas.drawColor(Color.argb(110, 0, 0, 0))
        canvas.save()
        canvas.translate((size - width) / 2f, (size - height) / 2f)
        decor.draw(canvas)
        canvas.restore()
    }

    private fun drawSheetMenu(cameras: List<Camera>) {
        val ids = cameras.joinToString(",") { it.id }
        val activity = liveActivity(1, ids)
        val root = activity.window.decorView
        forceLayout(root)
        arrangeLiveTiles(activity)
        forceLayout(root)
        fillVideoPlaceholders(root)
        forceLayout(root)
        val method = LiveActivity::class.java
            .getDeclaredMethod("showTileMenu", Int::class.javaPrimitiveType)
        method.isAccessible = true
        method.invoke(activity, 0)
        val dialog = ShadowDialog.getLatestDialog()
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        root.draw(canvas)
        drawDialog(canvas, dialog)
        save("14_sheet_menu", bitmap)
    }

    private fun drawMessage() {
        seedCameras()
        val activity = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        Ui.showMessage(
            activity,
            "连接正常",
            "DS-2CD3T46WDV3-I3\n固件 V5.7.19 build 240123\n抓图正常（1280 KB）"
        )
        val dialog = ShadowDialog.getLatestDialog()
        val root = activity.window.decorView
        forceLayout(root)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        root.draw(canvas)
        drawDialog(canvas, dialog)
        save("15_message", bitmap)
    }

    // ---------------------------------------------------------- placeholders

    private fun fillVideoPlaceholders(view: View) {
        if (view is VideoTile && view.width > 0 && view.height > 0) {
            runCatching { view.showSnapshot(previewFrame(view.width, view.height)) }
        }
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) fillVideoPlaceholders(view.getChildAt(index))
        }
    }

    private fun previewFrame(width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            Color.parseColor("#1F2A38"), Color.parseColor("#0B1118"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.shader = RadialGradient(
            width * 0.5f, height * 0.62f, width * 0.5f,
            intArrayOf(Color.argb(70, 90, 130, 175), Color.argb(0, 90, 130, 175)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), glow)

        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(46, 255, 255, 255)
            strokeWidth = 1f
        }
        canvas.drawLine(0f, height * 0.72f, width.toFloat(), height * 0.72f, line)
        for (i in 1..4) {
            val y = height * (0.72f + i * 0.06f)
            canvas.drawLine(0f, y, width.toFloat(), y, line)
        }

        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 255, 255, 255)
            textSize = height * 0.075f
            typeface = Typeface.DEFAULT
        }
        canvas.drawText("PREVIEW FRAME", width * 0.04f, height * 0.12f, text)
        return bitmap
    }
}
