package com.hikwatch

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.theme.ThemeManager
import com.hikwatch.theme.Themes
import com.hikwatch.ui.AlbumActivity
import com.hikwatch.ui.CameraEditActivity
import com.hikwatch.ui.InterfaceSettingsActivity
import com.hikwatch.ui.LiveActivity
import com.hikwatch.ui.MainActivity
import com.hikwatch.ui.PictureSettingsActivity
import com.hikwatch.ui.SettingsActivity
import com.hikwatch.ui.ThemeSettingsActivity
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** 所有页面的启动自检 + 关键设置逻辑 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class ActivitySmokeTest {

    private fun starts(activityClass: Class<out android.app.Activity>) {
        val controller = Robolectric.buildActivity(activityClass).setup()
        assertNotNull(controller.get())
    }

    @Test
    fun mainActivityStarts() = starts(MainActivity::class.java)

    @Test
    fun settingsActivitiesStart() {
        starts(SettingsActivity::class.java)
        starts(PictureSettingsActivity::class.java)
        starts(InterfaceSettingsActivity::class.java)
        starts(ThemeSettingsActivity::class.java)
    }

    @Test
    fun albumActivityStarts() = starts(AlbumActivity::class.java)

    @Test
    fun cameraEditActivityStarts() = starts(CameraEditActivity::class.java)

    @Test
    fun liveActivityStartsWithCamera() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        val camera = Camera(name = "测试通道", host = "192.168.1.10")
        store.upsert(camera)
        val intent = Intent(context, LiveActivity::class.java)
            .putExtra(LiveActivity.EXTRA_LAYOUT, 1)
            .putExtra(LiveActivity.EXTRA_IDS, camera.id)
        val controller = Robolectric.buildActivity(LiveActivity::class.java, intent).create()
        assertNotNull(controller.get())
        store.delete(camera.id)
    }

    @Test
    fun liveActivitySupportsSixWayLayout() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        val cameras = (1..6).map { Camera(name = "通道$it", host = "192.168.1.1$it") }
        cameras.forEach { store.upsert(it) }
        val intent = Intent(context, LiveActivity::class.java)
            .putExtra(LiveActivity.EXTRA_LAYOUT, 6)
            .putExtra(LiveActivity.EXTRA_IDS, cameras.joinToString(",") { it.id })
        val controller = Robolectric.buildActivity(LiveActivity::class.java, intent).create()
        assertNotNull(controller.get())
        cameras.forEach { store.delete(it.id) }
    }

    @Test
    fun starredCameraSortsFirst() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        val first = Camera(name = "A 普通", host = "10.0.0.11")
        val second = Camera(name = "B 重点", host = "10.0.0.12")
        store.upsert(first)
        store.upsert(second)
        store.toggleStar(second.id)
        assert(store.sortedCameras().first().id == second.id)
        assert(store.find(second.id)!!.starred)
        store.toggleStar(second.id)
        assert(!store.find(second.id)!!.starred)
        store.delete(first.id)
        store.delete(second.id)
    }

    @Test
    fun qualityAndAspectPersist() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        store.quality = CameraStore.QUALITY_HD
        store.aspectMode = CameraStore.ASPECT_16_9
        store.customAspect = 1.85f
        store.simultaneous = 6
        val reloaded = CameraStore(context)
        assert(reloaded.quality == CameraStore.QUALITY_HD)
        assert(reloaded.aspectMode == CameraStore.ASPECT_16_9)
        assert(reloaded.customAspect == 1.85f)
        assert(reloaded.simultaneous == 6)
        assert(!reloaded.subStreamFor(Camera(host = "1.1.1.1", subStream = true)))
        store.quality = CameraStore.QUALITY_STANDARD
        store.aspectMode = CameraStore.ASPECT_FILL
        store.simultaneous = 1
    }

    @Test
    fun themeSwitchingUpdatesAccent() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        ThemeManager.init(context)
        val glacier = Themes.byId("glacier")
        ThemeManager.select(glacier)
        assert(ThemeManager.current.id == "glacier")
        assert(com.hikwatch.ui.Ui.ACCENT == glacier.accent)
        ThemeManager.select(Themes.ALL.first())
    }
}
