package com.hikwatch

import com.hikwatch.audio.G711
import org.junit.Assert.assertEquals
import org.junit.Test

/** G.711 解码对照标准表校验 */
class G711Test {

    @Test
    fun ulawKnownValues() {
        // 标准 μ-law 表：0x00 = -32124，0x80 = +32124，0xFF/0x7F = 0
        assertEquals(0, G711.ulawToLinear(0xFF))
        assertEquals(0, G711.ulawToLinear(0x7F))
        assertEquals(-32124, G711.ulawToLinear(0x00))
        assertEquals(32124, G711.ulawToLinear(0x80))
    }

    @Test
    fun alawKnownValues() {
        // 标准 A-law 表：0x2A = -32256，0xAA = +32256，0xD5 = +8（静音码）
        assertEquals(-32256, G711.alawToLinear(0x2A))
        assertEquals(32256, G711.alawToLinear(0xAA))
        assertEquals(8, G711.alawToLinear(0xD5))
        assertEquals(-8, G711.alawToLinear(0x55))
    }

    @Test
    fun decodingIsAntisymmetric() {
        // 翻转输入的最高位应得到相反数（符号位规则）
        for (code in 0..0x7F) {
            assertEquals(
                "alaw sign symmetry at $code",
                -G711.alawToLinear(code),
                G711.alawToLinear(code or 0x80)
            )
            assertEquals(
                "ulaw sign symmetry at $code",
                -G711.ulawToLinear(code),
                G711.ulawToLinear(code or 0x80)
            )
        }
    }

    @Test
    fun decodedValuesStayInsideInt16() {
        for (code in 0..255) {
            val a = G711.alawToLinear(code)
            val u = G711.ulawToLinear(code)
            assert(a in Short.MIN_VALUE..Short.MAX_VALUE) { "alaw out of range: $a" }
            assert(u in Short.MIN_VALUE..Short.MAX_VALUE) { "ulaw out of range: $u" }
        }
    }

    @Test
    fun decodeToPcm16WritesSamples() {
        val data = byteArrayOf(0x2A.toByte(), 0xAA.toByte(), 0xFF.toByte(), 0x7F.toByte())
        val out = ShortArray(8)
        val count = G711.decodeToPcm16(data, 0, 4, alaw = true, out = out)
        assertEquals(4, count)
        assertEquals((-32256).toShort(), out[0])
        assertEquals(32256.toShort(), out[1])
        assertEquals(848.toShort(), out[2])
        assertEquals((-848).toShort(), out[3])
    }
}
