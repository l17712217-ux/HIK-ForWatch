package com.hikwatch

import com.hikwatch.net.DigestHttp
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * 用一个独立实现的摘要认证 HTTP 服务器验证 DigestHttp：
 * 客户端必须正确解析 challenge、按 RFC 2617 计算 response，并拿到 200 数据。
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class DigestHttpTest {

    private lateinit var serverSocket: ServerSocket
    private val closed = AtomicBoolean(false)
    private var port = 0

    private val realm = "IP Camera(C12345678)"
    private val nonce = "9f8a7b6c5d4e3f2a1b0c"
    private val userName = "admin"
    private val password = "Hik12345"
    private val path = "/ISAPI/Streaming/channels/102/picture"
    private val bodySize = 4096

    @Before
    fun setUp() {
        serverSocket = ServerSocket(0)
        port = serverSocket.localPort
        thread(isDaemon = true) {
            while (!closed.get()) {
                try {
                    serverSocket.accept().use { socket -> handle(socket) }
                } catch (ignored: Exception) {
                    return@thread
                }
            }
        }
    }

    @After
    fun tearDown() {
        closed.set(true)
        runCatching { serverSocket.close() }
    }

    private fun handle(socket: Socket) {
        val input = BufferedInputStream(socket.getInputStream())
        val output = socket.getOutputStream()
        val headers = readHeaders(input) ?: return
        val authorization = headers.firstOrNull { it.startsWith("Authorization:", true) }
            ?.substringAfter(':')?.trim()
        if (authorization == null || !isValid(authorization)) {
            write(
                output,
                "HTTP/1.1 401 Unauthorized\r\n" +
                    "WWW-Authenticate: Digest qop=\"auth\", realm=\"$realm\", nonce=\"$nonce\"\r\n" +
                    "Content-Length: 0\r\nConnection: close\r\n\r\n"
            )
            return
        }
        write(
            output,
            "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\n" +
                "Content-Length: $bodySize\r\nConnection: close\r\n\r\n"
        )
        output.write(ByteArray(bodySize) { 0x42 })
        output.flush()
    }

    private fun readHeaders(input: InputStream): List<String>? {
        val lines = ArrayList<String>()
        val builder = StringBuilder()
        while (true) {
            val value = input.read()
            if (value < 0) return if (lines.isEmpty()) null else lines
            if (value == '\n'.code) {
                val line = builder.toString().trimEnd('\r')
                builder.setLength(0)
                if (line.isEmpty()) return lines
                lines.add(line)
            } else {
                builder.append(value.toChar())
            }
        }
    }

    private fun write(output: OutputStream, text: String) {
        output.write(text.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun md5(text: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(text.toByteArray())
        val builder = StringBuilder(digest.size * 2)
        for (byte in digest) builder.append(String.format("%02x", byte))
        return builder.toString()
    }

    private fun params(header: String): Map<String, String> {
        val result = HashMap<String, String>()
        val body = header.substringAfter("Digest ")
        val items = ArrayList<String>()
        val builder = StringBuilder()
        var inQuote = false
        for (character in body) {
            if (character == '"') {
                inQuote = !inQuote
                builder.append(character)
            } else if (character == ',' && !inQuote) {
                items.add(builder.toString())
                builder.setLength(0)
            } else {
                builder.append(character)
            }
        }
        if (builder.isNotBlank()) items.add(builder.toString())
        for (item in items) {
            val index = item.indexOf('=')
            if (index <= 0) continue
            result[item.substring(0, index).trim().lowercase()] =
                item.substring(index + 1).trim().trim('"')
        }
        return result
    }

    private fun isValid(header: String): Boolean {
        val values = params(header)
        val uri = values["uri"] ?: return false
        val ha1 = md5("$userName:$realm:$password")
        val ha2 = md5("GET:$uri")
        val qop = values["qop"]
        val expected = if (qop != null) {
            md5("$ha1:${values["nonce"]}:${values["nc"]}:${values["cnonce"]}:$qop:$ha2")
        } else {
            md5("$ha1:${values["nonce"]}:$ha2")
        }
        return expected == values["response"] &&
            values["username"] == userName &&
            values["realm"] == realm &&
            uri == path
    }

    @Test
    fun digestHandshakeReturnsBody() {
        val client = DigestHttp(userName, password)
        val result = client.get("http://127.0.0.1:$port$path", 8000)
        assertEquals(200, result.code)
        assertEquals(bodySize, result.body.size)
    }

    @Test
    fun wrongPasswordIsRejected() {
        val client = DigestHttp(userName, "wrong-password")
        val result = client.get("http://127.0.0.1:$port$path", 8000)
        assertEquals(401, result.code)
        assertTrue(result.error.isNotEmpty())
    }
}
