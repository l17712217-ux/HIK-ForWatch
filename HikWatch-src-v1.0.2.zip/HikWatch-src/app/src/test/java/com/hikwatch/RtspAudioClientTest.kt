package com.hikwatch

import com.hikwatch.audio.RtspAudioClient
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * 用一个模拟的海康 RTSP 服务器（Digest 认证 + interleaved TCP + PCMA RTP）
 * 跑通自研音频通道：DESCRIBE → SETUP → PLAY → 收包解码。
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class RtspAudioClientTest {

    private val realm = "IP Camera"
    private val nonce = "abcdef0123456789"

    @Test
    fun fullAudioFlowReceivesRtpPackets() {
        val serverSocket = ServerSocket(0)
        val port = serverSocket.localPort
        val statuses = CopyOnWriteArrayList<String>()
        val errors = CopyOnWriteArrayList<String>()
        val packets = AtomicInteger()

        thread(isDaemon = true) {
            try {
                serverSocket.accept().use { socket ->
                    val input = BufferedInputStream(socket.getInputStream())
                    val output = socket.getOutputStream()
                    while (true) {
                        val request = readRequest(input) ?: break
                        val method = request.firstOrNull()?.substringBefore(' ') ?: continue
                        val cseq = request.firstOrNull { it.startsWith("CSeq:", true) }
                            ?.substringAfter(':')?.trim() ?: "1"
                        val hasAuth = request.any { it.startsWith("Authorization:", true) }
                        if (!hasAuth) {
                            write(
                                output,
                                "RTSP/1.0 401 Unauthorized\r\nCSeq: $cseq\r\n" +
                                    "WWW-Authenticate: Digest realm=\"$realm\", " +
                                    "nonce=\"$nonce\", qop=\"auth\"\r\n\r\n"
                            )
                            continue
                        }
                        when (method) {
                            "DESCRIBE" -> {
                                val sdp = buildString {
                                    append("v=0\r\n")
                                    append("o=- 1 1 IN IP4 127.0.0.1\r\n")
                                    append("s=Hikvision Media Server\r\n")
                                    append("c=IN IP4 127.0.0.1\r\n")
                                    append("t=0 0\r\n")
                                    append("a=control:*\r\n")
                                    append("m=video 0 RTP/AVP 96\r\n")
                                    append("a=rtpmap:96 H264/90000\r\n")
                                    append("a=control:trackID=1\r\n")
                                    append("m=audio 0 RTP/AVP 8\r\n")
                                    append("a=rtpmap:8 PCMA/8000/1\r\n")
                                    append("a=control:trackID=2\r\n")
                                }
                                write(
                                    output,
                                    "RTSP/1.0 200 OK\r\nCSeq: $cseq\r\n" +
                                        "Content-Base: rtsp://127.0.0.1:$port/Streaming/Channels/102/\r\n" +
                                        "Content-Type: application/sdp\r\n" +
                                        "Content-Length: ${sdp.toByteArray().size}\r\n\r\n$sdp"
                                )
                            }
                            "SETUP" -> write(
                                output,
                                "RTSP/1.0 200 OK\r\nCSeq: $cseq\r\n" +
                                    "Transport: RTP/AVP/TCP;unicast;interleaved=0-1;ssrc=1234\r\n" +
                                    "Session: 88888888\r\n\r\n"
                            )
                            "PLAY" -> {
                                write(
                                    output,
                                    "RTSP/1.0 200 OK\r\nCSeq: $cseq\r\n" +
                                        "Session: 88888888\r\nRange: npt=0.000-\r\n\r\n"
                                )
                                for (index in 0 until 40) {
                                    output.write(audioFrame(index))
                                    output.flush()
                                    Thread.sleep(15)
                                }
                            }
                            else -> write(
                                output,
                                "RTSP/1.0 200 OK\r\nCSeq: $cseq\r\nSession: 88888888\r\n\r\n"
                            )
                        }
                    }
                }
            } catch (ignored: Exception) {
                // 连接关闭属正常
            }
        }

        val client = RtspAudioClient(
            "127.0.0.1",
            port,
            "admin",
            "pass",
            "/Streaming/Channels/102",
            object : RtspAudioClient.Listener {
                override fun onStatus(text: String) {
                    statuses.add(text)
                }

                override fun onError(text: String) {
                    errors.add(text)
                }

                override fun onCodec(text: String) {
                    statuses.add("codec:$text")
                }
            }
        )
        client.packetListener = { packets.incrementAndGet() }
        client.start()

        val deadline = System.currentTimeMillis() + 10_000
        while (System.currentTimeMillis() < deadline && packets.get() < 5) {
            Thread.sleep(100)
        }
        client.stop()
        serverSocket.close()

        assertTrue("不应报错，errors=$errors statuses=$statuses", errors.isEmpty())
        assertTrue("应进入监听状态，statuses=$statuses", statuses.contains("监听中"))
        assertTrue("应识别 G.711 A-law，statuses=$statuses", statuses.any { it.contains("G.711") })
        assertTrue("应收到 RTP 音频包，packets=${packets.get()}", packets.get() >= 5)
    }

    private fun audioFrame(index: Int): ByteArray {
        val payload = ByteArray(160) { 0xD5.toByte() }
        val rtp = ByteArray(12 + payload.size)
        rtp[0] = 0x80.toByte()
        rtp[1] = 8
        rtp[2] = ((index shr 8) and 0xFF).toByte()
        rtp[3] = (index and 0xFF).toByte()
        rtp[4] = 0
        rtp[5] = 0
        rtp[6] = (((index * 160) shr 8) and 0xFF).toByte()
        rtp[7] = ((index * 160) and 0xFF).toByte()
        System.arraycopy(payload, 0, rtp, 12, payload.size)
        System.arraycopy(rtp, 0, payload, 0, 0)
        val frame = ByteArray(4 + rtp.size)
        frame[0] = 0x24
        frame[1] = 0
        frame[2] = ((rtp.size shr 8) and 0xFF).toByte()
        frame[3] = (rtp.size and 0xFF).toByte()
        System.arraycopy(rtp, 0, frame, 4, rtp.size)
        return frame
    }

    private fun readRequest(input: InputStream): List<String>? {
        val lines = ArrayList<String>()
        val builder = StringBuilder()
        while (true) {
            val value = input.read()
            if (value < 0) return if (lines.isEmpty()) null else lines
            if (value == '\n'.code) {
                val line = builder.toString().trimEnd('\r')
                builder.setLength(0)
                if (line.isEmpty()) {
                    if (lines.isNotEmpty()) return lines
                } else {
                    lines.add(line)
                }
            } else {
                builder.append(value.toChar())
            }
        }
    }

    private fun write(output: OutputStream, text: String) {
        output.write(text.toByteArray(Charsets.UTF_8))
        output.flush()
    }
}
