package com.hikwatch

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.hikwatch.data.CameraSeeder
import com.hikwatch.data.CameraStore
import com.hikwatch.data.SeedCameras
import com.hikwatch.model.Camera
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** 内置设备机制：默认模板为空，填入 IP 后可用 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class CameraSeederTest {

    @Test
    fun templateHasNoBuiltInCameras() {
        assertTrue(SeedCameras.IPS.isEmpty())
    }

    @Test
    fun seedingIsNoOpWhenListEmpty() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        store.cameras().forEach { store.delete(it.id) }
        context.getSharedPreferences("hikwatch_v1", Context.MODE_PRIVATE)
            .edit().remove("seed_version").apply()

        assertEquals(0, CameraSeeder.ensureSeeded(context))
        assertEquals(0, CameraStore(context).cameras().size)
    }

    @Test
    fun bulkCredentialsApplyToAll() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = CameraStore(context)
        store.cameras().forEach { store.delete(it.id) }
        store.upsert(Camera(name = "A", host = "10.0.0.1"))
        store.upsert(Camera(name = "B", host = "10.0.0.2"))

        val count = CameraSeeder.applyToAll(context, user = "1", pass = "abc123456")
        assertEquals(2, count)
        assertTrue(CameraStore(context).cameras().all { it.user == "1" && it.pass == "abc123456" })
        store.cameras().forEach { store.delete(it.id) }
    }
}
