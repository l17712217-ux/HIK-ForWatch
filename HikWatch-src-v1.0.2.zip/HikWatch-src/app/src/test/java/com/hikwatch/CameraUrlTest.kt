package com.hikwatch

import com.hikwatch.model.Camera
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** 海康 URL 规则：通道号拼接、RTSP 地址、ISAPI 抓图地址、JSON 持久化 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class CameraUrlTest {

    @Test
    fun channelPathFollowsHikvisionRule() {
        assertEquals("101", Camera(host = "10.0.0.2", subStream = false).channelPath)
        assertEquals("102", Camera(host = "10.0.0.2", subStream = true).channelPath)
        assertEquals("301", Camera(host = "10.0.0.2", channel = 3, subStream = false).channelPath)
        assertEquals("1001", Camera(host = "10.0.0.2", channel = 10, subStream = false).channelPath)
    }

    @Test
    fun rtspUrlEncodesCredentials() {
        val camera = Camera(
            host = "192.168.1.64",
            rtspPort = 554,
            user = "admin",
            pass = "pa ss&1",
            channel = 1,
            subStream = true
        )
        assertEquals(
            "rtsp://admin:pa%20ss%261@192.168.1.64:554/Streaming/Channels/102",
            camera.rtspUrl()
        )
        assertEquals(
            "rtsp://192.168.1.64:554/Streaming/Channels/102",
            camera.rtspBase()
        )
    }

    @Test
    fun isapiUrlsRespectHttpPort() {
        val camera = Camera(host = "192.168.1.64", httpPort = 80, subStream = false)
        assertEquals(
            "http://192.168.1.64/ISAPI/Streaming/channels/101/picture",
            camera.snapshotUrl()
        )
        val customPort = camera.copy(httpPort = 8080)
        assertEquals(
            "http://192.168.1.64:8080/ISAPI/Streaming/channels/101/picture",
            customPort.snapshotUrl()
        )
        assertEquals(
            "http://192.168.1.64:8080/ISAPI/System/deviceInfo",
            customPort.isapi("/ISAPI/System/deviceInfo")
        )
    }

    @Test
    fun jsonRoundTripKeepsAllFields() {
        val camera = Camera(
            name = "门口",
            host = "10.1.1.9",
            httpPort = 8000,
            rtspPort = 5540,
            user = "user1",
            pass = "p@ss",
            channel = 2,
            subStream = false,
            rtspTcp = false,
            mode = Camera.MODE_SNAPSHOT,
            recordAudio = false
        )
        val restored = Camera.fromJson(camera.toJson())
        assertEquals(camera, restored)
    }
}
