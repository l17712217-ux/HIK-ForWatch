# 海康监控 · OPPO Watch X2 手表端

一个专门为 **OPPO Watch X2（1.50 英寸 / 466×466 / 圆形表盘）** 适配的海康威视（Hikvision）监控观看 App。

APK 说明：Android APK（`com.hikwatch.viewer`），最低 Android 10（API 29），无 Google 服务依赖，可 ADB 侧载。

---

## v2.0 更新亮点

- **主页重构**：顶部**北京时间**（秒级刷新，固定 Asia/Shanghai）+ **双列设备网格** + 底部**在线数量**；底部一行是 `[设置]【＋ 添加】[相册]`
- **在线检测**：并发 TCP 探测每台设备的 RTSP 端口，状态点与在线计数自动点亮（不占用摄像头会话）
- **观看页**：单路**左右滑动切换**摄像头；底部常规三键 **拍照 / 录像 / 画面比例**（含自定义 0.3–4.0）+ 声音；新增 **同时观看** 可切 1/2/4/6/9 宫格
- **录像闪退已修**：录像器重写为「主线程零阻塞 + 工作线程收尾 + 全程兜底」（旧实现在主线程 join 编码线程，容易被系统判为 ANR 杀掉）；另外新增 crash.log 便于定位
- **输入界面重做**：独立全屏输入页，**真实拉起系统输入法**（`adjustResize`），不再自绘键盘
- **设置三层**：画面设置（清晰度 / 画面比例 / 多路策略 / 常亮 / 录像声音）、界面设置（功能键逐项开关 + 宫格数量 + 一键精简）、主题设置（左右滑动切换 6 套渐变主题）
- **液态玻璃**：面板升级为「渐变 + 左上镜面高光 + 底部内阴影 + 渐隐描边」，背景加入主题流光；6 套主题：极光 / 热带 / 冰原 / 熔岩 / 森林 / 午夜

---

## 关于源码包

这个包是**去掉了具体项目设备**的通用源码：

- `SeedCameras.IPS` 已清空（原 59 个 IP 不在源码里），首次启动不会预置任何设备
- 需要内置摄像头时，把 IP 填进 `app/src/main/java/com/hikwatch/data/SeedCameras.kt` 的 `IPS` 列表，
  首次启动会自动生成 `IPC-01…IPC-nn`（HTTP 80 / RTSP 554，账号取 `CameraSeeder.DEFAULT_USER/PASS`）
- 默认账号密码在 `CameraSeeder` 里（`1` / `abc123456`），也可在「设置 → 批量用户名 / 批量密码」整体修改
- 签名用的 keystore 在 `keystore/hikwatch.jks`（alias `hikwatch`，口令 `hikwatch2025`），
  换掉它就意味着无法覆盖安装旧版本

---

## 一、功能

| 功能 | 说明 |
| --- | --- |
| 添加监控 | 支持海康 IPC / NVR 通道，可填 IP、HTTP 端口、RTSP 端口、账号、密码、通道号、主/子码流、TCP/UDP、连接模式 |
| 星标重点 | 列表右侧点星 → 该监控置顶并显示琥珀色标记，长按菜单也可切换 |
| 撑满全屏 | 画面等比铺满整块表盘（裁掉超出部分），不留黑边；可在「界面控件」里切回完整画面 |
| 单路观看 | RTSP 实时画面 + 硬件解码，点击任意画面放大 |
| 全屏放大 | 双指捏合 1~5 倍缩放、双击 1×/2.5×、放大后可单指拖动 |
| 2 路 / 4 路同屏 | 布局按钮在 1 路 → 2 路 → 4 路之间循环，2 路为上下分屏，4 路为 2×2 |
| 声音监听 | 自研 RTSP 音频通道，支持海康默认的 **G.711（PCMA/PCMU）**，以及 **AAC**；按路单独开关 |
| 截图 | 优先走 ISAPI `/ISAPI/Streaming/channels/101/picture` 抓**原始高清 JPEG**；失败时截取当前显示画面 |
| 录像 | 屏幕镜像 + 应用内声音（AAC），H.264 编码写入相册，录制时顶部显示计时 |
| 界面控件开关 | 设置 →「界面控件」二级菜单，逐一开关布局/声音/截图/录像/切换/返回/顶部信息条，支持一键精简为「只有画面」 |
| 断线兜底 | RTSP 连不上时（自动模式下）自动降级为 **ISAPI 连续抓拍**模式，低帧率但仍能看到画面 |
| 连接自检 | 编辑页「测试连接」会读取海康设备型号 / 固件，并试抓一张图 |

保存位置：
- 截图 → 相册 `Pictures/HikWatch`
- 录像 → 相册 `Movies/HikWatch`

---

## 二、界面与毛玻璃效果

整体是「深色极光 + 毛玻璃」的视觉：

| 元素 | 效果 |
| --- | --- |
| 背景 | `AuroraView` 极光渐变：青 / 蓝 / 紫三团柔光 + 边缘暗角，静态绘制不持续重绘 |
| 面板 | `GlassPanelDrawable`：半透明纵向渐变（上亮下暗）+ 顶部渐变高光横线 + 1dp 白渐变描边 + 圆角轮廓投影 |
| 实时页浮层 | `FrostedView` 做**真实背景模糊**：每 320ms 抓一帧当前监控画面，降采样到 ~70px 后做 4 次盒式模糊，再叠玻璃染色 |
| 弹窗 / 键盘 / 操作表 | 玻璃面板 + Android 12+ 的窗口背景模糊（`setBackgroundBlurRadius`）+ 缩放入场动画 |
| 操作按钮 | 沿圆屏**底部圆弧**排布（半径 0.405×屏幕、间隔 18.5°），按钮数量变化时自动重新排布，不会压在画面正中 |
| 交互反馈 | 按钮按下缩放至 0.93、涟漪高亮、数字键盘按键触感反馈 |

模糊算法是自己实现的（`Glass.blur`：降采样 + 分离式盒式模糊，等效高斯），不依赖 RenderScript 或第三方库，在表盘上单帧耗时不到 1ms。

## 三、圆屏适配（重点）

- 设计基准：240dp × 240dp（466px / 310PPI ≈ 1.94 密度）。
- 单路画面：默认**撑满全屏**（等比放大后裁掉超出部分，圆屏四角本来就会被切），不留黑边；想要完整画面可在「界面控件 → 画面撑满全屏」关闭，改为圆内接（16:9 时约 406×228px）。
- 2 路：上下各半屏；4 路：2×2 全屏铺满，每一路都按撑满方式裁切。
- 操作按钮沿**底部圆弧**排布：中心距 0.405×屏幕高、相邻间隔 18.5°，4 个按钮时最外侧距圆心约 0.49×屏幕，仍在圆内；按钮数量减少时自动收拢到正中下方。
- 返回/切换摄像头贴左右两端中点（圆最宽处）；顶部信息条居中贴顶（宽 148dp）。
- 长按画面 / 点顶栏可唤出操作菜单；操作栏 6 秒自动隐藏，点一下画面重新出现。

---

## 四、安装

### 方式 A：ADB 侧载（推荐）

```bash
# 1) 手表开启开发者模式与 USB 调试
#    OPPO Watch X2：设置 → 关于手表 → 连点版本号进入开发者模式
#    → 开发者选项 → 打开「USB 调试」（部分版本叫「ADB 调试」）
# 2) 数据线连接 / 或同 Wi-Fi 下无线调试
adb devices               # 应能看到手表
adb install -r HikWatch-2.0.0.apk
```

无线调试（首次仍需线连）：

```bash
adb tcpip 5555
adb connect <手表IP>:5555
adb install -r HikWatch-2.0.0.apk
```

### 方式 B：应用列表查看

安装成功后，在手表应用列表里找到「海康监控」图标（青色相机图标）。若系统不显示第三方应用，请用 `adb shell am start -n com.hikwatch.viewer/.ui.MainActivity` 直接拉起。

> 不同 ColorOS Watch / Wear OS 版本对手表第三方应用入口的策略不同，ADB 拉起是最稳的方式。

---

## 五、摄像头侧需要确认的设置

1. **开启 RTSP**：绝大多数海康设备默认开启，路径为
   `rtsp://<IP>:554/Streaming/Channels/101`（1 通道主码流）、`102`（1 通道子码流）。
2. **音频**：海康默认多为 `G.711ulaw`，App 已直接支持。
   若要把声音也录进录像，或使用 AAC 摄像头，请在摄像头
   `配置 → 视音频 → 音频` 里确认编码为 G.711 或 AAC。
3. **子码流更省电**：手表建议用「子码流」（默认即是），分辨率可设 704×576 / 640×480。
4. **认证**：App 同时支持 **Digest（海康默认）** 与 Basic 认证。
5. **账号权限**：需要「远程预览 / 回放」权限的账号；连续抓拍模式下会频繁请求 ISAPI，请勿用会被锁定的弱密码账号反复试错。

---

## 六、使用

1. 首页点 `+` → 填地址（如 `192.168.1.64`）、账号（默认 `admin`）、密码 → 「测试连接」验证 → 「保存」。
2. 点卡片进入观看。默认布局可在「设置 → 默认同屏布局」里改成 2 / 4 路。
3. 观看页手势与按钮：
   - 点画面（单路）：显示/隐藏操作栏
   - 双指捏合：缩放；双击：1×/2.5× 切换；放大后单指拖动
   - 点画面（多路）：把这一路放大成全屏，返回键回到多路
   - **底部圆弧上的按钮**：布局切换（1/2/4）、声音、截图、录像 —— 按圆弧依次排开，贴底不挡画面中心
   - 左右两端：返回、切换摄像头
   - 顶栏：更多（主/子码流切换、隐藏操作栏、返回首页）
   - 长按画面：选择摄像头 / 放大 / 听这一路声音 / 截图 / 切码流
4. 录像：点录像按钮 → 系统弹出录屏授权 → 允许后开始录制，顶部显示 `● 录制中 mm:ss`；再点一次停止并保存。录像录的是**当前屏幕画面**，建议先放大到单路再录。
5. 星标：在监控列表点卡片右侧的 ☆，变成 ★ 后该监控置顶（琥珀色标记）；长按菜单里也能切换。
6. 精简界面：设置 →「界面控件」，可逐个关掉按钮，或点「一键精简：只留画面」，回到观看页就只剩监控画面（返回键仍保留）。

---

## 七、常见问题

| 现象 | 原因 / 处理 |
| --- | --- |
| 一直「连接中」后失败 | IP/端口不通；先用「测试连接」看 ISAPI 是否可达；企业网络可能屏蔽 554 端口 |
| 「用户名或密码错误」 | 密码含特殊字符时注意大小写；海康账号被锁需等 30 分钟 |
| 画面出来但黑屏 | 摄像头主码流是 H.265 且手表硬解不支持 → 改用子码流（默认）或把摄像头编码改 H.264 |
| 有画面没声音 | 摄像头音频未开启 / 编码是 G.726、MP2L2 等 → 改成 G.711 或 AAC；也检查手表媒体音量 |
| 声音比画面慢 | 音频是独立 RTSP 会话，属正常现象（监控听环境音足够） |
| 4 路卡顿发热 | 4 路同时硬解对 W5 芯片压力大，建议「设置 → 多路同屏全部实时」关闭，或改用子码流 |
| 布局按钮点不动 / 只能 1 路 | 2 路需要至少 2 个监控、4 路需要至少 4 个，先在首页添加更多 |
| 观看页按钮不见了 | 被「设置 → 界面控件」关掉了；进去重新打开，或点「恢复全部控件」 |
| 画面两边被切掉 | 默认「画面撑满全屏」会等比裁切；要看完整画面就把这个开关关掉 |
| 截图失败 | ISAPI 端口不是 80 时，把「HTTP 端口」改成实际端口；新版固件可在 `配置 → 网络 → 高级设置 → HTTPS` 关闭强制加密 |
| 录像失败 | 手表存储空间不足；或系统未授予录屏权限（每次录像都要重新授权，Android 14 限制） |
| 找不到 App 图标 | 用 `adb shell am start -n com.hikwatch.viewer/.ui.MainActivity` 拉起 |

---

## 八、技术架构

```
app/src/main/java/com/hikwatch/
├── model/Camera.kt            设备模型 + 海康 URL 规则（101/102、ISAPI 路径）
├── data/CameraStore.kt        SharedPreferences + JSON 持久化、全局设置
├── net/DigestHttp.kt          HTTP Digest/Basic 客户端（nonce 复用，抓拍模式低开销）
├── net/HikApi.kt              ISAPI：deviceInfo 自检、高清抓图
├── play/RtspPlayer.kt         Media3 ExoPlayer + RTSP（TCP 交织、仅视频轨）
├── play/SnapshotPoller.kt     RTSP 不可用时的 ISAPI 连续抓拍降级
├── audio/RtspAudioClient.kt   自研 RTSP/SDP/RTP/交织解析 + G.711 解码 + AAC(MediaCodec) → AudioTrack
├── record/ScreenRecorder.kt   MediaProjection 镜像 → H.264 + 回放采集 → AAC → MediaMuxer
├── media/MediaSaver.kt        截图/录像写入 MediaStore（Pictures|Movies/HikWatch）
└── ui/                        MainActivity / CameraEditActivity / LiveActivity / SettingsActivity
                               VideoTile（等比+捏合缩放）、SheetDialog、NumberPadDialog、Ui 主题件
```

关键取舍：
- **视频用 Media3**：成熟、硬解、RTP 乱序/丢包处理好，且已支持 RTSP Digest 认证。
- **音频自己写**：Media3 的 RTP 音频只支持 AAC/AMR/AC3/Opus/PCM，**不支持海康默认的 G.711**，所以单独做一路 RTSP 音频会话（与视频互不影响，音频失败不影响画面）。
- **录像用屏幕镜像**：监控 App 拿不到播放器的编码前数据，MediaProjection + AAC 回放采集是唯一能做到「画面 + 声音」且不重复解码的方案；因此录到的是你看到的画面（建议单路放大后录）。

---

## 九、构建与测试

环境：JDK 17、Android SDK（platform 34 / build-tools 34.0.0）、Gradle 8.9（工程已带 wrapper）。

```bash
export JAVA_HOME=/path/to/jdk17
export ANDROID_HOME=/path/to/android-sdk

# 单元测试（18 个，纯 JVM + Robolectric，不需要真机）
./gradlew testDebugUnitTest

# Lint 静态检查
./gradlew lintDebug

# 打正式包
./gradlew assembleRelease
# 产物：app/build/outputs/apk/release/app-release.apk
```

签名：`keystore/hikwatch.jks`（alias `hikwatch`，口令 `hikwatch2025`），仅用于自签名安装；如需上架请替换为你自己的密钥。

已通过的自动化验证（`app/src/test`）：

| 测试 | 覆盖内容 |
| --- | --- |
| `RtspAudioClientTest` | 起一个模拟海康的 RTSP 服务器（Digest 401 → SDP → SETUP → PLAY → 交织 RTP/PCMA），验证自研音频通道能握手、识别 G.711、持续收包解码 |
| `DigestHttpTest` | 独立实现的摘要认证服务器，验证 ISAPI 抓图的 Digest 计算与 401 重试、错误密码拒绝 |
| `ActivitySmokeTest` | 首页、设置、编辑、观看页（1 路 / 4 路）在 Robolectric 下真实创建，确认布局代码不会崩 |
| `CameraUrlTest` | 海康通道号 101/102 规则、RTSP 凭据转义、ISAPI 地址、JSON 持久化 |
| `G711Test` | G.711 μ-law / A-law 对照标准表解码值、符号对称性、范围 |

---

## 十、边界与说明

- 未实现的功能：云台控制（PTZ）、录像回放、对讲、报警推送、多设备分组。
- 录像为屏幕录制，分辨率等于表盘屏幕（466×466 内），非原始码流。
- 本项目不含任何摄像头破解/默认口令尝试逻辑，请使用你自己的设备与账号。

---

## 十一、在电脑上预览界面（虚拟手表窗口）

不想先装到手表也能看到真实界面：

1. 双击打开 [`preview/watch-preview.html`](preview/watch-preview.html)（单文件，已内嵌全部截图，断网也能看）。
2. 左侧列表切换画面，或按键盘 `←` `→`、数字键 `1–9`；可勾选「自动轮播」。
3. 去掉「圆形遮罩」可以看到完整的方形渲染结果（方便检查圆边裁切）。

这些截图不是画的示意图，而是 **App 自己的布局与绘制代码在 Android 图形栈上真实渲染**的：
`app/src/test/java/com/hikwatch/ScreenshotTest.kt` 用 Robolectric 的 NATIVE 图形模式（真实 Skia）创建各页面、跑完整 measure/layout，再把 `DecorView` 画到 480×480 位图上导出 PNG。
唯一例外是**视频画面区域**——预览环境没有摄像头也没有解码器，那里填的是占位帧（真实设备上显示监控画面）。

重新生成：

```bash
./gradlew testDebugUnitTest --tests "com.hikwatch.ScreenshotTest"   # 产出 app/preview/raw/*.png
python preview/build_preview.py                                     # 打包成 watch-preview.html
```
