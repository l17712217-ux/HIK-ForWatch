package com.hikwatch.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hikwatch.R
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.net.HikApi
import com.hikwatch.util.OnlineChecker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 首页：北京时间 + 双列设备网格 + 在线数量 + 底部 [设置][＋ 添加][相册]
 */
class MainActivity : Activity() {

    private lateinit var store: CameraStore
    private lateinit var gridBox: LinearLayout
    private lateinit var onlineLabel: TextView
    private lateinit var clockLabel: TextView
    private lateinit var dateLabel: TextView
    private lateinit var emptyHint: LinearLayout
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    private val onlineMap = HashMap<String, Boolean>()
    private var checking = false
    private var lastCheckAt = 0L

    private val clockFormat = SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
        timeZone = TimeZone.getTimeZone("Asia/Shanghai")
    }
    private val dateFormat = SimpleDateFormat("M月d日 EEE", Locale.CHINA).apply {
        timeZone = TimeZone.getTimeZone("Asia/Shanghai")
    }

    private val clockTick = object : Runnable {
        override fun run() {
            val now = Date()
            clockLabel.text = clockFormat.format(now)
            dateLabel.text = dateFormat.format(now)
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        setContentView(buildRoot())
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(clockTick)
        handler.post(clockTick)
        refresh()
    }

    override fun onPause() {
        handler.removeCallbacks(clockTick)
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------- ui

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // 北京时间
        val clock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        clockLabel = Ui.label(this, "--:--:--", 20f, Ui.TEXT, bold = true)
        clockLabel.letterSpacing = 0.06f
        clockLabel.gravity = Gravity.CENTER
        clock.addView(clockLabel)
        dateLabel = Ui.label(this, "", 8.5f, Ui.TEXT3)
        dateLabel.letterSpacing = 0.04f
        dateLabel.gravity = Gravity.CENTER
        clock.addView(dateLabel)
        root.addView(
            clock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@MainActivity, 8f) }
        )

        // 双列设备网格
        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(gridBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@MainActivity, 48f)
                bottomMargin = Ui.dp(this@MainActivity, 92f)
                leftMargin = Ui.dp(this@MainActivity, 22f)
                rightMargin = Ui.dp(this@MainActivity, 22f)
            }
        )

        val fade = Ui.bottomFade(this, 16f)
        root.addView(
            fade,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 16f),
                Gravity.BOTTOM
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 92f) }
        )

        // 在线数量
        onlineLabel = Ui.label(this, "", 9f, Ui.TEXT2)
        onlineLabel.letterSpacing = 0.05f
        onlineLabel.gravity = Gravity.CENTER
        root.addView(
            onlineLabel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 84f) }
        )

        // 底部：设置 | 添加 | 相册
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val settings = Ui.iconButton(this, R.drawable.ic_settings, 34f, Ui.PANEL, Ui.TEXT) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        val album = Ui.iconButton(this, R.drawable.ic_album, 34f, Ui.PANEL, Ui.TEXT) {
            startActivity(Intent(this, AlbumActivity::class.java))
        }
        val add = Ui.primaryIconButton(this, R.drawable.ic_plus, 46f) { onAdd() }
        bar.addView(
            settings,
            LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)).apply {
                rightMargin = Ui.dp(this@MainActivity, 10f)
            }
        )
        bar.addView(add, LinearLayout.LayoutParams(Ui.dp(this, 46f), Ui.dp(this, 46f)))
        bar.addView(
            album,
            LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)).apply {
                leftMargin = Ui.dp(this@MainActivity, 10f)
            }
        )
        root.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 20f) }
        )

        emptyHint = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val emptyIcon = Ui.iconButton(this, R.drawable.ic_snapshot, 34f, Ui.GLASS, Ui.TEXT3) {}
        emptyIcon.isClickable = false
        emptyHint.addView(emptyIcon, LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)))
        val emptyText = Ui.label(this, "还没有设备\n点下方 + 添加", 9f, Ui.TEXT3)
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(0, Ui.dp(this, 6f), 0, 0)
        emptyHint.addView(emptyText)

        return root
    }

    // -------------------------------------------------------------- content

    private fun refresh() {
        val cameras = store.sortedCameras()
        gridBox.removeAllViews()
        if (cameras.isEmpty()) {
            gridBox.addView(
                emptyHint,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    Ui.dp(this, 74f)
                )
            )
            onlineLabel.text = "0 台在线"
            return
        }

        var row: LinearLayout? = null
        cameras.forEachIndexed { index, camera ->
            if (index % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                gridBox.addView(
                    row,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        Ui.dp(this, 46f)
                    ).apply { bottomMargin = Ui.dp(this@MainActivity, 8f) }
                )
            }
            val cell = buildCell(camera)
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            if (index % 2 == 0) {
                params.rightMargin = Ui.dp(this@MainActivity, 4f)
            } else {
                params.leftMargin = Ui.dp(this@MainActivity, 4f)
            }
            row?.addView(cell, params)
        }
        if (cameras.size % 2 == 1) {
            val spacer = View(this)
            row?.addView(
                spacer,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    leftMargin = Ui.dp(this@MainActivity, 4f)
                }
            )
        }
        updateOnlineLabel(cameras)
        startOnlineCheck(cameras)
    }

    private fun buildCell(camera: Camera): View {
        val card = FrameLayout(this)
        card.background = Ui.ripple(Ui.solid(Ui.PANEL, Ui.dp(this, 18f).toFloat()))
        card.elevation = Ui.dp(this, 2f).toFloat()
        card.isClickable = true

        val dot = View(this)
        dot.background = Ui.solid(dotColor(camera), Ui.dp(this, 2.5f).toFloat())
        card.addView(
            dot,
            FrameLayout.LayoutParams(Ui.dp(this, 5f), Ui.dp(this, 5f), Gravity.START or Gravity.TOP).apply {
                leftMargin = Ui.dp(this@MainActivity, 8f)
                topMargin = Ui.dp(this@MainActivity, 11f)
            }
        )

        val name = Ui.label(this, camera.displayName, 9.5f, Ui.TEXT, bold = true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        card.addView(
            name,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = Ui.dp(this@MainActivity, 17f)
                rightMargin = Ui.dp(this@MainActivity, 14f)
                topMargin = Ui.dp(this@MainActivity, 7f)
            }
        )

        val sub = Ui.label(
            this,
            camera.host + (if (camera.starred) "  ★" else ""),
            7.5f,
            if (camera.starred) Ui.WARN else Ui.TEXT3
        )
        sub.maxLines = 1
        sub.letterSpacing = 0.02f
        card.addView(
            sub,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = Ui.dp(this@MainActivity, 17f)
                rightMargin = Ui.dp(this@MainActivity, 8f)
                topMargin = Ui.dp(this@MainActivity, 25f)
            }
        )

        card.setOnClickListener {
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 1)
                    .putExtra(LiveActivity.EXTRA_IDS, camera.id)
            )
        }
        card.setOnLongClickListener {
            showCameraMenu(camera)
            true
        }
        return card
    }

    private fun dotColor(camera: Camera): Int = when (onlineMap[camera.id]) {
        true -> Ui.ACCENT
        false -> Ui.withAlpha(Ui.TEXT3, 160)
        null -> Ui.withAlpha(Ui.TEXT2, 120)
    }

    private fun updateOnlineLabel(cameras: List<Camera>) {
        val online = cameras.count { onlineMap[it.id] == true }
        onlineLabel.text = if (checking) {
            "检测中… · 共 " + cameras.size + " 台"
        } else {
            online.toString() + " 台在线 · 共 " + cameras.size + " 台"
        }
        onlineLabel.setTextColor(if (online > 0) Ui.ACCENT else Ui.TEXT2)
    }

    private fun startOnlineCheck(cameras: List<Camera>) {
        if (checking) return
        // 设备多时（59 台）避免频繁探测：15 秒内复用上次结果
        if (android.os.SystemClock.elapsedRealtime() - lastCheckAt < 15000L) {
            updateOnlineLabel(cameras)
            return
        }
        lastCheckAt = android.os.SystemClock.elapsedRealtime()
        checking = true
        scope.launch {
            val result = OnlineChecker.check(cameras)
            onlineMap.clear()
            onlineMap.putAll(result)
            checking = false
            updateOnlineLabel(cameras)
            for (index in 0 until gridBox.childCount) {
                val row = gridBox.getChildAt(index) as? ViewGroup ?: continue
                for (cellIndex in 0 until row.childCount) {
                    val cell = row.getChildAt(cellIndex) as? ViewGroup ?: continue
                    val dot = cell.getChildAt(0) ?: continue
                    val camera = cameras.getOrNull(index * 2 + cellIndex) ?: continue
                    dot.background = Ui.solid(dotColor(camera), Ui.dp(this@MainActivity, 2.5f).toFloat())
                }
            }
        }
    }

    // --------------------------------------------------------------- menu

    private fun showCameraMenu(camera: Camera) {
        val sheet = SheetDialog(this, camera.displayName)
        sheet.addItem("观看") {
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 1)
                    .putExtra(LiveActivity.EXTRA_IDS, camera.id)
            )
        }
        sheet.addItem("多路同屏") {
            val ids = store.sortedCameras().take(4).joinToString(",") { it.id }
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 4)
                    .putExtra(LiveActivity.EXTRA_IDS, ids)
            )
        }
        sheet.addItem("编辑") {
            startActivity(
                Intent(this, CameraEditActivity::class.java)
                    .putExtra(CameraEditActivity.EXTRA_ID, camera.id)
            )
        }
        sheet.addItem("测试连接") { testConnection(camera) }
        sheet.addItem(if (camera.starred) "取消星标" else "设为重点（星标）") {
            store.toggleStar(camera.id)
            refresh()
        }
        sheet.addItem("删除", danger = true) { confirmDelete(camera) }
        sheet.showSheet()
    }

    private fun testConnection(camera: Camera) {
        Ui.toast(this, "正在连接 " + camera.host + " …")
        scope.launch {
            val result = withContext(Dispatchers.IO) { HikApi.test(camera) }
            Ui.showMessage(
                this@MainActivity,
                if (result.ok) "连接正常" else "连接失败",
                result.message
            )
        }
    }

    private fun confirmDelete(camera: Camera) {
        val sheet = SheetDialog(this, "删除「" + camera.displayName + "」？")
        sheet.addItem("确认删除", danger = true) {
            store.delete(camera.id)
            refresh()
            Ui.toast(this, "已删除")
        }
        sheet.addItem("取消") {}
        sheet.showSheet()
    }

    private fun onAdd() {
        startActivity(Intent(this, CameraEditActivity::class.java))
    }
}
