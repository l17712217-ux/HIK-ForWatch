package com.hikwatch.ui

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.hikwatch.R

/**
 * 圆表盘 UI 设计系统（毛玻璃风格）：配色、尺寸、玻璃面板、按钮、弹层。
 *
 * 所有面板都是"半透明渐变 + 顶部高光 + 细描边"的玻璃件；
 * 叠在极光背景或实时画面上时，就是毛玻璃效果。
 */
object Ui {

    // ---------------------------------------------------------------- 配色
    /** 当前主题（由 ThemeManager 在启动/切换时写入） */
    var theme: com.hikwatch.theme.AppTheme = com.hikwatch.theme.Themes.ALL.first()
        private set

    var BG = Color.parseColor("#05070A")
        private set
    /** 玻璃面板基色（带透明度，叠在背景上才透光） */
    var PANEL = Color.argb(168, 20, 29, 45)
        private set
    var PANEL_HI = Color.argb(196, 17, 25, 38)
        private set
    /** 弹窗/键盘用：更实的底色，避免底下文字透上来影响阅读 */
    var PANEL_SOLID = Color.argb(247, 16, 23, 35)
        private set
    var GLASS = Color.argb(140, 16, 24, 38)
        private set
    val STROKE = Color.argb(58, 255, 255, 255)

    val TEXT = Color.WHITE
    val TEXT2 = Color.argb(226, 154, 170, 194)
    val TEXT3 = Color.argb(150, 122, 138, 162)

    var ACCENT = Color.parseColor("#2FE3B0")
        private set
    var ACCENT_SOFT = Color.argb(46, 47, 227, 176)
        private set
    var ACCENT_DARK = Color.parseColor("#04140F")
        private set
    val DANGER = Color.parseColor("#FF5A6B")
    val DANGER_SOFT = Color.argb(40, 255, 90, 107)
    val WARN = Color.parseColor("#FFC152")
    val BLUE = Color.parseColor("#5B9DFF")

    /** 主题切换时重新计算所有派生色 */
    fun applyTheme(theme: com.hikwatch.theme.AppTheme) {
        this.theme = theme
        BG = theme.base
        ACCENT = theme.accent
        ACCENT_SOFT = withAlpha(theme.accent, 48)
        ACCENT_DARK = mix(theme.accent, Color.BLACK, 0.82f)
        val slate = Color.parseColor("#141D2D")
        PANEL = withAlpha(mix(slate, theme.accent, 0.07f), 168)
        PANEL_HI = withAlpha(mix(slate, theme.accent, 0.10f), 199)
        PANEL_SOLID = withAlpha(mix(slate, theme.accent, 0.08f), 247)
        GLASS = withAlpha(mix(slate, theme.accent, 0.05f), 140)
    }

    fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    fun mix(from: Int, to: Int, ratio: Float): Int {
        val t = ratio.coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(from),
            (Color.red(from) + (Color.red(to) - Color.red(from)) * t).toInt(),
            (Color.green(from) + (Color.green(to) - Color.green(from)) * t).toInt(),
            (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t).toInt()
        )
    }

    fun dp(context: Context, value: Float): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------ 玻璃件
    /** 玻璃面板：半透明渐变 + 高光 + 细描边 */
    fun solid(
        color: Int,
        radiusPx: Float,
        strokeColor: Int = 0,
        strokePx: Float = 0f
    ): Drawable = GlassPanelDrawable(
        radiusPx = radiusPx,
        baseColor = color,
        strokeColor = strokeColor,
        strokeWidthPx = strokePx
    )

    fun ripple(drawable: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x3DFFFFFF), drawable, null)

    fun accentRipple(drawable: Drawable): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x552FE3B0), drawable, null)

    /** 极光渐变背景，铺满父容器 */
    fun aurora(context: Context): View = AuroraView(context)

    fun glassPanel(context: Context, radiusDp: Float, color: Int = PANEL): Drawable =
        solid(color, dp(context, radiusDp).toFloat())

    // ---------------------------------------------------------------- 文字
    fun label(
        context: Context,
        text: String,
        sizeSp: Float,
        color: Int,
        bold: Boolean = false
    ): TextView {
        val view = TextView(context)
        view.text = text
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        view.setTextColor(color)
        if (bold) view.setTypeface(view.typeface, Typeface.BOLD)
        view.includeFontPadding = false
        return view
    }

    fun sectionLabel(context: Context, text: String): TextView =
        label(context, text, 9.5f, TEXT3).apply {
            letterSpacing = 0.12f
            setPadding(dp(context, 6f), dp(context, 2f), 0, dp(context, 5f))
        }

    // ---------------------------------------------------------------- 按钮
    /** 圆形玻璃按钮（带按下缩放反馈） */
    fun iconButton(
        context: Context,
        iconRes: Int,
        sizeDp: Float,
        background: Int = PANEL,
        tint: Int = TEXT,
        onClick: () -> Unit
    ): FrameLayout {
        val size = dp(context, sizeDp)
        val box = FrameLayout(context)
        box.background = ripple(solid(background, size / 2f))
        box.isClickable = true
        box.elevation = dp(context, 2f).toFloat()
        val icon = ImageView(context)
        icon.setImageResource(iconRes)
        icon.setColorFilter(tint)
        val iconSize = (size * 0.46f).toInt()
        box.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        box.setOnClickListener { onClick() }
        box.setOnTouchListener(pressFeedback)
        box.layoutParams = FrameLayout.LayoutParams(size, size)
        return box
    }

    /** 主操作按钮：青色实心 + 微光 */
    fun primaryIconButton(
        context: Context,
        iconRes: Int,
        sizeDp: Float,
        tint: Int = ACCENT_DARK,
        onClick: () -> Unit
    ): FrameLayout {
        val size = dp(context, sizeDp)
        val box = FrameLayout(context)
        box.background = accentRipple(solid(ACCENT, size / 2f))
        box.isClickable = true
        box.elevation = dp(context, 5f).toFloat()
        val icon = ImageView(context)
        icon.setImageResource(iconRes)
        icon.setColorFilter(tint)
        val iconSize = (size * 0.46f).toInt()
        box.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        box.setOnClickListener { onClick() }
        box.setOnTouchListener(pressFeedback)
        box.layoutParams = FrameLayout.LayoutParams(size, size)
        return box
    }

    /** 胶囊文字按钮 */
    fun pillButton(
        context: Context,
        text: String,
        background: Int = PANEL,
        textColor: Int = TEXT,
        heightDp: Float = 34f,
        textSizeSp: Float = 12f,
        onClick: () -> Unit
    ): TextView {
        val height = dp(context, heightDp)
        val view = label(context, text, textSizeSp, textColor, bold = true)
        view.gravity = Gravity.CENTER
        view.letterSpacing = 0.02f
        view.background = ripple(solid(background, height / 2f))
        view.setPadding(dp(context, 10f), 0, dp(context, 10f), 0)
        view.isClickable = true
        view.elevation = dp(context, 2f).toFloat()
        view.setOnClickListener { onClick() }
        view.setOnTouchListener(pressFeedback)
        view.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            height
        )
        return view
    }

    private val pressFeedback = View.OnTouchListener { view, event ->
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> view.animate()
                .scaleX(0.93f).scaleY(0.93f)
                .setDuration(80L).start()

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate()
                .scaleX(1f).scaleY(1f)
                .setDuration(140L).start()
        }
        false
    }

    /** 小圆点（状态指示 / LIVE 标记） */
    fun dot(context: Context, diameterDp: Float, color: Int): View {
        val size = dp(context, diameterDp)
        val view = View(context)
        view.background = solid(color, size / 2f, Color.argb(90, 255, 255, 255), 1f)
        view.layoutParams = FrameLayout.LayoutParams(size, size)
        return view
    }

    /** 设置类列表行：左标题 + 右取值 */
    fun settingRow(
        context: Context,
        title: String,
        value: String,
        accent: Boolean = true,
        onClick: () -> Unit
    ): View {
        val row = FrameLayout(context)
        row.background = ripple(solid(PANEL, dp(context, 18f).toFloat()))
        row.elevation = dp(context, 1f).toFloat()
        row.isClickable = true

        val titleView = label(context, title, 11.5f, TEXT)
        titleView.maxLines = 1
        row.addView(
            titleView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = dp(context, 13f) }
        )

        val valueView = label(context, value, 11f, if (accent) ACCENT else TEXT3, bold = true)
        valueView.maxLines = 1
        row.addView(
            valueView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply { rightMargin = dp(context, 13f) }
        )

        row.setOnClickListener { onClick() }
        row.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(context, 42f)
        ).apply { bottomMargin = dp(context, 7f) }
        return row
    }

    /** 滚动区底部渐隐，提示"还能往下滑" */
    fun bottomFade(context: Context, heightDp: Float = 26f): View {
        val view = View(context)
        val height = dp(context, heightDp).toFloat()
        view.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.TRANSPARENT, Color.argb(196, 5, 7, 10))
        )
        view.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            height.toInt()
        )
        view.isClickable = false
        return view
    }

    /** 设置首页的大条目：图标 + 标题 + 说明 */
    fun menuRow(
        context: Context,
        iconRes: Int,
        title: String,
        subtitle: String,
        onClick: () -> Unit
    ): View {
        val row = FrameLayout(context)
        row.background = ripple(solid(PANEL, dp(context, 20f).toFloat()))
        row.elevation = dp(context, 2f).toFloat()
        row.isClickable = true

        val icon = ImageView(context)
        icon.setImageResource(iconRes)
        icon.setColorFilter(ACCENT)
        row.addView(
            icon,
            FrameLayout.LayoutParams(dp(context, 18f), dp(context, 18f), Gravity.START or Gravity.CENTER_VERTICAL).apply {
                leftMargin = dp(context, 13f)
            }
        )

        val titleView = label(context, title, 12f, TEXT, bold = true)
        row.addView(
            titleView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = dp(context, 39f) }
        )

        val subView = label(context, subtitle, 8.5f, TEXT3)
        subView.maxLines = 1
        row.addView(
            subView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply { rightMargin = dp(context, 13f) }
        )

        row.setOnClickListener { onClick() }
        row.setOnTouchListener(pressFeedback)
        row.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(context, 46f)
        ).apply { bottomMargin = dp(context, 7f) }
        return row
    }

    // ---------------------------------------------------------------- 弹层
    /** 给 Dialog 加上毛玻璃窗口效果（Android 12+ 为真实的背景模糊） */
    fun applyGlassWindow(dialog: Dialog, blurRadiusDp: Float = 26f) {
        val window = dialog.window ?: return
        window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0.42f)
        window.setWindowAnimations(R.style.GlassDialogAnimation)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                window.setBackgroundBlurRadius(dp(dialog.context, blurRadiusDp))
            }
        }
    }

    fun toast(context: Context, text: String) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
    }

    fun showMessage(
        context: Context,
        title: String,
        body: String,
        onClose: (() -> Unit)? = null
    ) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 14f), dp(context, 14f), dp(context, 14f), dp(context, 11f))
            background = glassPanel(context, 26f, PANEL_SOLID)
            elevation = dp(context, 8f).toFloat()
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            label(context, title, 12.5f, TEXT, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val accentDot = View(context)
        accentDot.background = solid(ACCENT, dp(context, 3f).toFloat())
        header.addView(accentDot, LinearLayout.LayoutParams(dp(context, 6f), dp(context, 6f)))
        box.addView(header)

        val bodyView = label(context, body, 10.5f, TEXT2)
        bodyView.setPadding(0, dp(context, 7f), 0, dp(context, 11f))
        bodyView.setTextIsSelectable(true)
        if (body.length > 110) {
            // 长文本（帮助/说明）放进可滚动区域，避免超出表盘
            val scroll = android.widget.ScrollView(context).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            bodyView.setPadding(0, dp(context, 2f), 0, dp(context, 2f))
            scroll.addView(
                bodyView,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            box.addView(
                scroll,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(context, 132f)
                ).apply {
                    topMargin = dp(context, 6f)
                    bottomMargin = dp(context, 10f)
                }
            )
        } else {
            box.addView(bodyView)
        }

        val close = label(context, "知道了", 11.5f, ACCENT_DARK, bold = true).apply {
            gravity = Gravity.CENTER
            background = accentRipple(solid(ACCENT, dp(context, 18f).toFloat()))
            isClickable = true
            setOnClickListener {
                dialog.dismiss()
                onClose?.invoke()
            }
        }
        box.addView(
            close,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 34f))
        )

        dialog.setContentView(box)
        applyGlassWindow(dialog, 22f)
        dialog.show()
        dialog.window?.setLayout(dp(context, 186f), ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
