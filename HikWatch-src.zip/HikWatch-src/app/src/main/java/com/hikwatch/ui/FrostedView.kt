package com.hikwatch.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import kotlin.math.max

/**
 * 真·毛玻璃面板：周期性从 provider 取一张"身后的画面"，降采样后做快速模糊，
 * 再叠加玻璃染色 + 顶部高光 + 细描边。
 *
 * 用于实时画面上方的信息条 / 操作条 —— 背景就是正在播放的监控画面。
 */
class FrostedView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** 返回"身后的画面"；Bitmap 由调用方持有，这里不会回收它 */
    var provider: (() -> Bitmap?)? = null

    var blurRadius: Int = 9
    var tintColor: Int = Color.argb(150, 8, 13, 21)
    var refreshIntervalMs: Long = 320L
    /** 小于 0 表示自动取高度一半（胶囊形） */
    var radiusPx: Float = -1f

    private var blurred: Bitmap? = null
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val rect = RectF()
    private val dst = RectF()
    private val density = resources.displayMetrics.density

    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            if (isAttachedToWindow) {
                postDelayed(this, refreshIntervalMs)
            }
        }
    }

    init {
        setWillNotDraw(false)
        tintPaint.color = tintColor
    }

    private fun dp(value: Float) = value * density

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        blurred?.recycle()
        blurred = null
        super.onDetachedFromWindow()
    }

    fun refreshNow() {
        if (!isShown || alpha < 0.05f) return
        val source = runCatching { provider?.invoke() }.getOrNull() ?: return
        if (source.isRecycled || source.width < 4 || source.height < 4) return
        val width = this.width
        val height = this.height
        if (width <= 0 || height <= 0) return
        val targetWidth = (width / 7).coerceIn(16, 72)
        val targetHeight = max(10, (targetWidth.toFloat() * height / width).toInt()).coerceAtMost(72)
        val small = runCatching {
            Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
        }.getOrNull() ?: return
        val result = runCatching { Glass.blur(small, blurRadius) }.getOrNull()
        if (result == null) {
            small.recycle()
            return
        }
        if (result !== small) small.recycle()
        val previous = blurred
        blurred = result
        previous?.recycle()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val width = width
        val height = height
        if (width <= 0 || height <= 0) return
        val radius = if (radiusPx >= 0f) radiusPx else height / 2f
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(path)

        val bitmap = blurred
        if (bitmap != null && !bitmap.isRecycled) {
            // 稍微放大绘制，避免模糊后的边缘露出透明
            val overscan = 1.16f
            val drawWidth = width * overscan
            val drawHeight = height * overscan
            dst.set(
                (width - drawWidth) / 2f,
                (height - drawHeight) / 2f,
                (width + drawWidth) / 2f,
                (height + drawHeight) / 2f
            )
            canvas.drawBitmap(bitmap, null, dst, bitmapPaint)
        }

        val alpha = Color.alpha(tintColor)
        tintPaint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            Color.argb(
                alpha,
                (Color.red(tintColor) + 18).coerceAtMost(255),
                (Color.green(tintColor) + 22).coerceAtMost(255),
                (Color.blue(tintColor) + 34).coerceAtMost(255)
            ),
            tintColor,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), tintPaint)
        canvas.restore()

        borderPaint.strokeWidth = dp(1f)
        borderPaint.shader = LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            intArrayOf(
                Color.argb(96, 255, 255, 255),
                Color.argb(26, 255, 255, 255),
                Color.argb(10, 255, 255, 255)
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, borderPaint)

        shinePaint.strokeWidth = dp(1.1f)
        shinePaint.shader = LinearGradient(
            0f, 0f, width.toFloat(), 0f,
            intArrayOf(
                Color.argb(0, 255, 255, 255),
                Color.argb(62, 255, 255, 255),
                Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        val inset = max(radius * 0.8f, dp(8f))
        if (width > inset * 2) {
            canvas.drawLine(
                inset, dp(0.8f),
                width - inset, dp(0.8f),
                shinePaint
            )
        }
        borderPaint.shader = null
        shinePaint.shader = null
        tintPaint.shader = null
    }

    /** 无障碍/命中测试保持默认，仅在绘制时接管背景 */
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == View.VISIBLE) post(tick) else removeCallbacks(tick)
    }
}
