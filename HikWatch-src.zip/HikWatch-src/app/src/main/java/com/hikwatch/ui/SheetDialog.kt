package com.hikwatch.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * 圆屏操作表（毛玻璃）：一行一项，项多时可滚动，按下有缩放反馈。
 */
class SheetDialog(context: Context, private val title: String? = null) : Dialog(context) {

    private val container = LinearLayout(context)
    private val scroller = ScrollView(context)
    private val frame = FrameLayout(context)

    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)

        frame.background = Ui.glassPanel(context, 26f, Ui.PANEL_SOLID)

        scroller.isVerticalScrollBarEnabled = false
        scroller.overScrollMode = ScrollView.OVER_SCROLL_NEVER
        scroller.clipToPadding = false
        scroller.setPadding(
            Ui.dp(context, 8f), Ui.dp(context, 10f),
            Ui.dp(context, 8f), Ui.dp(context, 8f)
        )

        container.orientation = LinearLayout.VERTICAL
        scroller.addView(
            container,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        frame.addView(
            scroller,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        if (!title.isNullOrBlank()) {
            val head = Ui.label(context, title, 11f, Ui.TEXT, bold = true)
            head.gravity = Gravity.CENTER
            head.letterSpacing = 0.02f
            head.maxLines = 1
            head.ellipsize = android.text.TextUtils.TruncateAt.END
            head.setPadding(Ui.dp(context, 6f), 0, Ui.dp(context, 6f), Ui.dp(context, 7f))
            container.addView(
                head,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        setContentView(frame)
        Ui.applyGlassWindow(this)
    }

    fun addItem(text: String, danger: Boolean = false, enabled: Boolean = true, action: () -> Unit) {
        val context = context
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = if (danger) {
                Ui.ripple(Ui.solid(Ui.DANGER_SOFT, Ui.dp(context, 16f).toFloat()))
            } else {
                Ui.ripple(Ui.solid(Ui.GLASS, Ui.dp(context, 16f).toFloat()))
            }
            isClickable = enabled
            isEnabled = enabled
        }
        val label = Ui.label(
            context,
            text,
            12f,
            when {
                !enabled -> Ui.TEXT3
                danger -> Ui.DANGER
                else -> Ui.TEXT
            },
            bold = true
        )
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        row.addView(
            label,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        row.setOnClickListener {
            dismiss()
            action()
        }
        row.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> view.animate()
                    .scaleX(0.95f).scaleY(0.95f).setDuration(70L).start()

                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> view.animate()
                    .scaleX(1f).scaleY(1f).setDuration(120L).start()
            }
            false
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            Ui.dp(context, 32f)
        )
        params.bottomMargin = Ui.dp(context, 4f)
        container.addView(row, params)
    }

    fun addText(text: String) {
        val view = Ui.label(context, text, 10f, Ui.TEXT3)
        view.gravity = Gravity.CENTER
        view.setPadding(0, Ui.dp(context, 2f), 0, Ui.dp(context, 7f))
        container.addView(view)
    }

    fun showSheet() {
        show()
        val window = window ?: return
        val tall = container.childCount > 4
        // 面板四角必须落在圆内：172dp 宽时高度上限约 166dp
        val height = if (tall) Ui.dp(context, 166f) else ViewGroup.LayoutParams.WRAP_CONTENT
        window.setLayout(Ui.dp(context, 172f), height)
        if (tall) {
            scroller.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }
}
