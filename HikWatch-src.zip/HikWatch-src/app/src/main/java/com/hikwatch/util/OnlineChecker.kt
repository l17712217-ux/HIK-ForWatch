package com.hikwatch.util

import com.hikwatch.model.Camera
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * 在线检测：对每台设备的 RTSP 端口做一次短超时 TCP 连接。
 * 只判断"端口通不通"，够用来点亮状态点，不消耗摄像头会话。
 * 设备多时限制并发（12 个），避免一次性打满 socket。
 */
object OnlineChecker {

    private const val TIMEOUT_MS = 1200
    private const val MAX_PARALLEL = 12

    suspend fun check(cameras: List<Camera>): Map<String, Boolean> = coroutineScope {
        val limit = Semaphore(MAX_PARALLEL)
        withContext(Dispatchers.IO) {
            cameras.map { camera ->
                async { limit.withPermit { camera.id to probe(camera) } }
            }.awaitAll().toMap()
        }
    }

    private fun probe(camera: Camera): Boolean {
        if (camera.host.isBlank()) return false
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(camera.host, camera.rtspPort), TIMEOUT_MS)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
