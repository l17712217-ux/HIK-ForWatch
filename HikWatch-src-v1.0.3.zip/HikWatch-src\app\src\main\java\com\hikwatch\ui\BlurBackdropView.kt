package com.hikwatch.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.max

/**
 * 毛玻璃背景层（v1.0.3）。
 *
 * 把一张「降采样 + 多次盒式模糊」后的页面截图按 cover 方式铺满自身，
 * 再叠两层玻璃染色：
 *  1) 整体冷色薄雾 —— 让底层内容只留形状、不留文字
 *  2) 顶部亮 / 底部暗的厚度渐变 —— 模拟玻璃板受光
 *
 * 用于首页下拉的 SYSTEM MONITOR 面板背后，替代原来的纯色半透明底，
 * 面板本身再叠一层高不透明度玻璃，最终读起来是「毛玻璃 + 实底」。
 */
class BlurBackdropView(context: Context) : View(context) {

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val mistPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val vignettePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val matrix = Matrix()
    private val rect = RectF()
    private var frame: Bitmap? = null
    private var shadersBuilt = false

    /** 冷色薄雾浓度（0..1），越大越"磨砂" */
    var mistStrength: Float = 0.62f

    /** 上下厚度渐变浓度（0..1） */
    var lightStrength: Float = 0.40f

    /** 四周压暗浓度（0..1），让中间内容更聚焦 */
    var vignetteStrength: Float = 0.50f

    /** 当前持有的模糊帧（供外部做回收判断） */
    val currentFrame: Bitmap?
        get() = frame

    fun setFrame(source: Bitmap?) {
        if (frame === source) {
            invalidate()
            return
        }
        frame = source
        shadersBuilt = false
        invalidate()
    }

    fun clearFrame() {
        frame = null
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shadersBuilt = false
    }

    override fun onDraw(canvas: Canvas) {
        val bitmap = frame
        if (bitmap == null || bitmap.isRecycled || width <= 0 || height <= 0) return

        rect.set(0f, 0f, width.toFloat(), height.toFloat())

        // ---- 1) 模糊帧 cover 铺满（居中裁切）
        val scale = max(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        matrix.reset()
        matrix.setScale(scale, scale)
        matrix.postTranslate(
            (width - bitmap.width * scale) / 2f,
            (height - bitmap.height * scale) / 2f
        )
        canvas.save()
        canvas.clipRect(rect)
        canvas.drawBitmap(bitmap, matrix, bitmapPaint)
        canvas.restore()

        if (!shadersBuilt) {
            buildShaders()
            shadersBuilt = true
        }

        // ---- 2) 冷色薄雾：压掉文字锐度，只留色块
        canvas.drawRect(rect, mistPaint)

        // ---- 3) 上下厚度渐变
        canvas.drawRect(rect, lightPaint)

        // ---- 4) 四周压暗
        canvas.drawRect(rect, vignettePaint)
    }

    private fun buildShaders() {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = Ui.BG

        mistPaint.shader = null
        mistPaint.color = Color.argb(
            (mistStrength * 255f).toInt().coerceIn(0, 255),
            (Color.red(base) + 8).coerceAtMost(255),
            (Color.green(base) + 12).coerceAtMost(255),
            (Color.blue(base) + 22).coerceAtMost(255)
        )

        lightPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                // 顶部只留一层很薄的高光：面板自身的高光已经够亮，这里再叠会糊成灰白
                Color.argb((lightStrength * 108f).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((lightStrength * 22f).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb(0, 0, 0, 0),
                Color.argb((lightStrength * 170f).toInt().coerceIn(0, 255), 0, 0, 0)
            ),
            floatArrayOf(0f, 0.16f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )

        vignettePaint.shader = RadialGradient(
            w * 0.5f,
            h * 0.42f,
            max(w, h) * 0.72f,
            intArrayOf(
                Color.argb(0, 0, 0, 0),
                Color.argb((vignetteStrength * 190f).toInt().coerceIn(0, 255), 0, 0, 0)
            ),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }
}
