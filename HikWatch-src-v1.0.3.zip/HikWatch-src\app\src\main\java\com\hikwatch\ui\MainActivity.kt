package com.hikwatch.ui

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.SystemClock
import android.net.TrafficStats
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.hikwatch.R
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.net.HikApi
import com.hikwatch.util.OnlineChecker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * 首页：北京时间 + 双列设备网格 + 在线数量 + 底部 [设置][＋ 添加][相册]
 */
class MainActivity : Activity() {

    private lateinit var store: CameraStore
    private lateinit var rootView: FrameLayout
    private lateinit var blurScrim: BlurBackdropView
    private var backdropFrame: Bitmap? = null
    private var backdropAt = 0L
    private var backdropBusy = false
    private lateinit var gridBox: LinearLayout
    private lateinit var onlineLabel: TextView
    private lateinit var clockLabel: TextView
    private lateinit var dateLabel: TextView
    private lateinit var titleLabel: TextView
    private lateinit var emptyHint: LinearLayout
    private lateinit var telemetryPanel: LinearLayout
    private lateinit var telemetryClock: TextView
    private lateinit var telemetryNetwork: TextView
    private lateinit var telemetryChart: TelemetryBarChartView
    private var telemetryVisible = false
    private var lastRxBytes = -1L
    private var lastTxBytes = -1L
    private var lastNetworkAt = 0L
    private var lastCpuTicks = -1L
    private var lastCpuAt = 0L
    private var cpuPercent = 0f
    private var memoryPercent = 0f
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    private val onlineMap = HashMap<String, Boolean>()
    private var checking = false
    private var lastCheckAt = 0L

    private val clockFormat = SimpleDateFormat("HH:mm:ss", Locale.CHINA).apply {
        timeZone = TimeZone.getTimeZone("Asia/Shanghai")
    }
    private val dateFormat = SimpleDateFormat("M月d日 EEE", Locale.CHINA).apply {
        timeZone = TimeZone.getTimeZone("Asia/Shanghai")
    }

    private val telemetryTick = object : Runnable {
        override fun run() {
            if (!::telemetryPanel.isInitialized) return
            val now = System.currentTimeMillis()
            telemetryClock.text = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.CHINA).format(Date(now))
            sampleTelemetry()
            handler.postDelayed(this, 250L)
        }
    }

    private val clockTick = object : Runnable {
        override fun run() {
            val now = Date()
            clockLabel.text = clockFormat.format(now)
            dateLabel.text = dateFormat.format(now)
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        setContentView(buildRoot())
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(clockTick)
        handler.post(clockTick)
        handler.removeCallbacks(telemetryTick)
        handler.post(telemetryTick)
        refresh()
    }

    override fun onPause() {
        handler.removeCallbacks(clockTick)
        handler.removeCallbacks(telemetryTick)
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------- ui

    private fun buildRoot(): View {
        val root = FrameLayout(this)
        rootView = root
        root.setBackgroundColor(Ui.BG)
        root.addView(
            Ui.aurora(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // 时间胶囊：贴住屏幕顶部边缘（圆屏顶端的裁切由胶囊内的上留白吸收）
        val capsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = Ui.solid(
                Ui.PANEL_HI,
                Ui.dp(this@MainActivity, 16f).toFloat(),
                Ui.STROKE,
                Ui.dp(this@MainActivity, 0.8f).toFloat()
            )
            elevation = Ui.dp(this@MainActivity, 6f).toFloat()
            setPadding(
                Ui.dp(this@MainActivity, 13f), Ui.dp(this@MainActivity, 7f),
                Ui.dp(this@MainActivity, 13f), Ui.dp(this@MainActivity, 5f)
            )
        }
        clockLabel = Ui.label(this, "--:--:--", 16.5f, Ui.TEXT, bold = true)
        clockLabel.letterSpacing = 0.04f
        clockLabel.gravity = Gravity.CENTER
        capsule.addView(clockLabel)
        root.addView(
            capsule,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@MainActivity, 3f) }
        )

        // 胶囊下方：应用名 + 日期（同一行，避免多占一行把设备网格挤下去）
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleLabel = Ui.label(this, "海康监控", 13f, Ui.TEXT, bold = true)
        titleLabel.letterSpacing = 0.16f
        titleRow.addView(titleLabel)
        dateLabel = Ui.label(this, "", 8.5f, Ui.TEXT3)
        dateLabel.letterSpacing = 0.04f
        titleRow.addView(
            dateLabel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = Ui.dp(this@MainActivity, 7f) }
        )
        root.addView(
            titleRow,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@MainActivity, 36f) }
        )

        // 双列设备网格
        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        gridBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(gridBox, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                topMargin = Ui.dp(this@MainActivity, 54f)
                bottomMargin = Ui.dp(this@MainActivity, 88f)
                leftMargin = Ui.dp(this@MainActivity, 22f)
                rightMargin = Ui.dp(this@MainActivity, 22f)
            }
        )

        val fade = Ui.bottomFade(this, 16f)
        root.addView(
            fade,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this, 16f),
                Gravity.BOTTOM
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 88f) }
        )

        // 在线数量
        onlineLabel = Ui.label(this, "", 9f, Ui.TEXT2)
        onlineLabel.letterSpacing = 0.05f
        onlineLabel.gravity = Gravity.CENTER
        root.addView(
            onlineLabel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 80f) }
        )

        // 底部：设置 | 添加 | 相册
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val settings = Ui.iconButton(this, R.drawable.ic_settings, 34f, Ui.PANEL, Ui.TEXT) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        val album = Ui.iconButton(this, R.drawable.ic_album, 34f, Ui.PANEL, Ui.TEXT) {
            startActivity(Intent(this, AlbumActivity::class.java))
        }
        val add = Ui.primaryIconButton(this, R.drawable.ic_plus, 46f) { onAdd() }
        bar.addView(
            settings,
            LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)).apply {
                rightMargin = Ui.dp(this@MainActivity, 10f)
            }
        )
        bar.addView(add, LinearLayout.LayoutParams(Ui.dp(this, 46f), Ui.dp(this, 46f)))
        bar.addView(
            album,
            LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)).apply {
                leftMargin = Ui.dp(this@MainActivity, 10f)
            }
        )
        root.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = Ui.dp(this@MainActivity, 20f) }
        )

        // 下拉式设备性能监看面板（从首页顶部向下滑动打开）
        telemetryPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 18f), Ui.dp(this@MainActivity, 14f),
                Ui.dp(this@MainActivity, 18f), Ui.dp(this@MainActivity, 16f))
            // v1.0.3：不透明度从 PANEL(168) 提到 PANEL_OVERLAY(214)，叠在模糊背景上更像毛玻璃
            background = Ui.overlayGlass(this@MainActivity, 20f)
            elevation = Ui.dp(this@MainActivity, 12f).toFloat()
            visibility = View.GONE
        }
        val panelHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panelHeader.addView(Ui.label(this, "SYSTEM MONITOR", 9f, Ui.TEXT2, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val closePanel = Ui.label(this, "收起  ↑", 9f, Ui.ACCENT, bold = true).apply {
            setPadding(Ui.dp(this@MainActivity, 8f), Ui.dp(this@MainActivity, 4f), 0, Ui.dp(this@MainActivity, 4f))
            setOnClickListener { setTelemetryVisible(false) }
        }
        panelHeader.addView(closePanel)
        telemetryPanel.addView(panelHeader)
        telemetryClock = Ui.label(this, "----/--/-- --:--:--.---", 17f, Ui.TEXT, bold = true).apply {
            letterSpacing = 0.015f
            setPadding(0, Ui.dp(this@MainActivity, 10f), 0, Ui.dp(this@MainActivity, 3f))
        }
        telemetryPanel.addView(telemetryClock)
        telemetryNetwork = Ui.label(this, "网络 ↓ -- KB/s   ↑ -- KB/s", 9f, Ui.TEXT2).apply {
            setPadding(0, 0, 0, Ui.dp(this@MainActivity, 8f))
        }
        telemetryPanel.addView(telemetryNetwork)
        telemetryChart = TelemetryBarChartView(this)
        // 88dp：整块面板要能塞进 240dp 表盘，112dp 会把底部说明挤出屏幕
        telemetryPanel.addView(telemetryChart, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 88f)))
        val limitation = Ui.label(this, "CPU：应用进程估算  ·  内存：应用 PSS  ·  GPU：Android 未开放通用占用率接口", 7f, Ui.TEXT3)
        limitation.setPadding(0, Ui.dp(this, 5f), 0, 0)
        telemetryPanel.addView(limitation)
        // 毛玻璃背景层：盖住首页内容、位于面板之下
        blurScrim = BlurBackdropView(this).apply {
            visibility = View.GONE
            alpha = 0f
            // 面板展开期间吃掉点击，避免手指落到被模糊的设备网格上
            isClickable = true
        }
        root.addView(blurScrim, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        root.addView(telemetryPanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ).apply {
            leftMargin = Ui.dp(this@MainActivity, 12f)
            rightMargin = Ui.dp(this@MainActivity, 12f)
            topMargin = Ui.dp(this@MainActivity, 4f)
        })

        emptyHint = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val emptyIcon = Ui.iconButton(this, R.drawable.ic_snapshot, 34f, Ui.GLASS, Ui.TEXT3) {}
        emptyIcon.isClickable = false
        emptyHint.addView(emptyIcon, LinearLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)))
        val emptyText = Ui.label(this, "还没有设备\n点下方 + 添加", 9f, Ui.TEXT3)
        emptyText.gravity = Gravity.CENTER
        emptyText.setPadding(0, Ui.dp(this, 6f), 0, 0)
        emptyHint.addView(emptyText)

        return root
    }

    /** 顶部下拉/上滑手势：仅在首页顶部区域触发，避免干扰设备列表操作。 */
    private var touchStartY = 0f
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        when (ev.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                touchStartY = ev.y
                // 手指在顶部按下时预热背景帧，松手时面板能立刻带毛玻璃弹出
                if (!telemetryVisible && ev.y <= Ui.dp(this, 72f)) captureBackdrop()
            }
            android.view.MotionEvent.ACTION_UP -> {
                val dy = ev.y - touchStartY
                val topLimit = Ui.dp(this, if (telemetryVisible) 340f else 72f)
                if (touchStartY <= topLimit && kotlin.math.abs(dy) > Ui.dp(this, 55f)) {
                    if (dy > 0 && !telemetryVisible) setTelemetryVisible(true)
                    else if (dy < 0 && telemetryVisible) setTelemetryVisible(false)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    /**
     * v1.0.3：抓一张首页当前画面的降采样位图，模糊后交给 [blurScrim]。
     * PixelCopy 失败（例如硬件合成受限）时退回软件绘制 rootView。
     */
    private fun captureBackdrop(onReady: (() -> Unit)? = null) {
        val cached = backdropFrame
        if (cached != null && !cached.isRecycled &&
            SystemClock.elapsedRealtime() - backdropAt < 1500L
        ) {
            blurScrim.setFrame(cached)
            onReady?.invoke()
            return
        }
        val w = rootView.width
        val h = rootView.height
        if (w <= 8 || h <= 8) {
            onReady?.invoke()
            return
        }
        val targetW = (w / 6).coerceIn(24, 240)
        val targetH = (h / 6).coerceIn(24, 240)
        val raw = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        var delivered = false
        val deliver: (Bitmap) -> Unit = { source ->
            if (!delivered) {
                delivered = true
                publishBackdrop(source)
                onReady?.invoke()
            }
        }
        val fallback = Runnable { fallbackDraw(deliver) }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            fallback.run()
            return
        }
        try {
            PixelCopy.request(window, Rect(0, 0, w, h), raw, { result ->
                if (result == PixelCopy.SUCCESS) deliver(raw) else fallback.run()
            }, handler)
        } catch (_: Throwable) {
            fallback.run()
        }
    }

    private fun fallbackDraw(deliver: (Bitmap) -> Unit) {
        val w = rootView.width
        val h = rootView.height
        if (w <= 0 || h <= 0) return
        val bmp = Bitmap.createBitmap(
            (w / 6).coerceAtLeast(24),
            (h / 6).coerceAtLeast(24),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bmp)
        canvas.scale(bmp.width.toFloat() / w, bmp.height.toFloat() / h)
        runCatching { rootView.draw(canvas) }
        deliver(bmp)
    }

    private fun publishBackdrop(source: Bitmap) {
        val blurred = runCatching { Glass.blur(source, 6) }.getOrNull()
        val result = blurred ?: source
        val previous = backdropFrame
        backdropFrame = result
        backdropAt = SystemClock.elapsedRealtime()
        blurScrim.setFrame(result)
        if (previous != null && previous !== result && !previous.isRecycled) previous.recycle()
        if (result !== source && !source.isRecycled) source.recycle()
    }

    private fun setTelemetryVisible(show: Boolean) {
        if (telemetryVisible == show) return
        telemetryVisible = show
        if (show) {
            // 抓帧这一刻面板和遮罩都不可见，避免把它们拍进背景
            telemetryPanel.visibility = View.GONE
            blurScrim.visibility = View.GONE
            captureBackdrop {
                if (!telemetryVisible) return@captureBackdrop
                blurScrim.visibility = View.VISIBLE
                blurScrim.alpha = 0f
                blurScrim.animate().alpha(1f)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.4f))
                    .setDuration(200L).start()
                telemetryPanel.visibility = View.VISIBLE
                telemetryPanel.alpha = 0f
                telemetryPanel.translationY = -Ui.dp(this, 18f).toFloat()
                telemetryPanel.animate().alpha(1f).translationY(0f)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
                    .setDuration(260L).start()
            }
        } else {
            blurScrim.animate().alpha(0f).setDuration(150L).withEndAction {
                if (!telemetryVisible) blurScrim.visibility = View.GONE
            }.start()
            telemetryPanel.animate().alpha(0f)
                .translationY(-Ui.dp(this, 14f).toFloat())
                .setDuration(150L).withEndAction {
                    if (!telemetryVisible) telemetryPanel.visibility = View.GONE
                }.start()
        }
    }

    private fun sampleTelemetry() {
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes().takeIf { it >= 0L } ?: 0L
        val tx = TrafficStats.getTotalTxBytes().takeIf { it >= 0L } ?: 0L
        if (lastNetworkAt > 0L && now > lastNetworkAt && lastRxBytes >= 0L && lastTxBytes >= 0L) {
            val seconds = (now - lastNetworkAt) / 1000f
            val down = ((rx - lastRxBytes).coerceAtLeast(0L) / seconds / 1024f)
            val up = ((tx - lastTxBytes).coerceAtLeast(0L) / seconds / 1024f)
            telemetryNetwork.text = String.format(Locale.CHINA, "网络  ↓ %.1f KB/s    ↑ %.1f KB/s", down, up)
        }
        lastRxBytes = rx; lastTxBytes = tx; lastNetworkAt = now

        val cpuTicks = readProcessCpuTicks()
        if (cpuTicks >= 0L && lastCpuTicks >= 0L && lastCpuAt > 0L && now > lastCpuAt) {
            val deltaTicks = (cpuTicks - lastCpuTicks).coerceAtLeast(0L)
            val deltaMs = now - lastCpuAt
            cpuPercent = (deltaTicks * 1000f / deltaMs).coerceIn(0f, 100f) // /proc/self/stat 常见时钟频率 100Hz
        }
        if (cpuTicks >= 0L) lastCpuTicks = cpuTicks
        lastCpuAt = now

        val memoryInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(memoryInfo)
        val pssMb = memoryInfo.totalPss / 1024f
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val totalMb = (mem.totalMem / (1024f * 1024f)).coerceAtLeast(1f)
        memoryPercent = ((totalMb - mem.availMem / (1024f * 1024f)) / totalMb * 100f).coerceIn(0f, 100f)
        telemetryChart.setValues(cpuPercent, null, memoryPercent, pssMb)
    }

    private fun readProcessCpuTicks(): Long = try {
        val stat = java.io.File("/proc/self/stat").readText()
        val fields = stat.substringAfterLast(") ").trim().split(Regex("\\s+"))
        // 去掉 pid/comm 后，utime/stime 对应索引 11/12（从 state 字段开始计数）
        fields[11].toLong() + fields[12].toLong()
    } catch (_: Exception) { -1L }

    // -------------------------------------------------------------- content

    private fun refresh() {
        val cameras = store.sortedCameras()
        gridBox.removeAllViews()
        if (cameras.isEmpty()) {
            gridBox.addView(
                emptyHint,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    Ui.dp(this, 74f)
                )
            )
            onlineLabel.text = "0 台在线"
            return
        }

        var row: LinearLayout? = null
        cameras.forEachIndexed { index, camera ->
            if (index % 2 == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                gridBox.addView(
                    row,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        Ui.dp(this, 46f)
                    ).apply { bottomMargin = Ui.dp(this@MainActivity, 8f) }
                )
            }
            val cell = buildCell(camera)
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            if (index % 2 == 0) {
                params.rightMargin = Ui.dp(this@MainActivity, 4f)
            } else {
                params.leftMargin = Ui.dp(this@MainActivity, 4f)
            }
            row?.addView(cell, params)
        }
        if (cameras.size % 2 == 1) {
            val spacer = View(this)
            row?.addView(
                spacer,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    leftMargin = Ui.dp(this@MainActivity, 4f)
                }
            )
        }
        updateOnlineLabel(cameras)
        startOnlineCheck(cameras)
    }

    private fun buildCell(camera: Camera): View {
        val card = FrameLayout(this)
        card.background = Ui.ripple(Ui.solid(Ui.PANEL, Ui.dp(this, 18f).toFloat()))
        card.elevation = Ui.dp(this, 2f).toFloat()
        card.isClickable = true

        val dot = View(this)
        dot.background = Ui.solid(dotColor(camera), Ui.dp(this, 2.5f).toFloat())
        card.addView(
            dot,
            FrameLayout.LayoutParams(Ui.dp(this, 5f), Ui.dp(this, 5f), Gravity.START or Gravity.TOP).apply {
                leftMargin = Ui.dp(this@MainActivity, 8f)
                topMargin = Ui.dp(this@MainActivity, 11f)
            }
        )

        val name = Ui.label(this, camera.displayName, 9.5f, Ui.TEXT, bold = true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        card.addView(
            name,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = Ui.dp(this@MainActivity, 17f)
                rightMargin = Ui.dp(this@MainActivity, 14f)
                topMargin = Ui.dp(this@MainActivity, 7f)
            }
        )

        val sub = Ui.label(
            this,
            camera.host + (if (camera.starred) "  ★" else ""),
            7.5f,
            if (camera.starred) Ui.WARN else Ui.TEXT3
        )
        sub.maxLines = 1
        sub.letterSpacing = 0.02f
        card.addView(
            sub,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = Ui.dp(this@MainActivity, 17f)
                rightMargin = Ui.dp(this@MainActivity, 8f)
                topMargin = Ui.dp(this@MainActivity, 25f)
            }
        )

        card.setOnClickListener {
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 1)
                    .putExtra(LiveActivity.EXTRA_IDS, camera.id)
            )
        }
        card.setOnLongClickListener {
            showCameraMenu(camera)
            true
        }
        return card
    }

    private fun dotColor(camera: Camera): Int = when (onlineMap[camera.id]) {
        true -> Ui.ACCENT
        false -> Ui.withAlpha(Ui.TEXT3, 160)
        null -> Ui.withAlpha(Ui.TEXT2, 120)
    }

    private fun updateOnlineLabel(cameras: List<Camera>) {
        val online = cameras.count { onlineMap[it.id] == true }
        onlineLabel.text = if (checking) {
            "检测中… · 共 " + cameras.size + " 台"
        } else {
            online.toString() + " 台在线 · 共 " + cameras.size + " 台"
        }
        onlineLabel.setTextColor(if (online > 0) Ui.ACCENT else Ui.TEXT2)
    }

    private fun startOnlineCheck(cameras: List<Camera>) {
        if (checking) return
        // 设备多时（59 台）避免频繁探测：15 秒内复用上次结果
        if (android.os.SystemClock.elapsedRealtime() - lastCheckAt < 15000L) {
            updateOnlineLabel(cameras)
            return
        }
        lastCheckAt = android.os.SystemClock.elapsedRealtime()
        checking = true
        scope.launch {
            val result = OnlineChecker.check(cameras)
            onlineMap.clear()
            onlineMap.putAll(result)
            checking = false
            updateOnlineLabel(cameras)
            for (index in 0 until gridBox.childCount) {
                val row = gridBox.getChildAt(index) as? ViewGroup ?: continue
                for (cellIndex in 0 until row.childCount) {
                    val cell = row.getChildAt(cellIndex) as? ViewGroup ?: continue
                    val dot = cell.getChildAt(0) ?: continue
                    val camera = cameras.getOrNull(index * 2 + cellIndex) ?: continue
                    dot.background = Ui.solid(dotColor(camera), Ui.dp(this@MainActivity, 2.5f).toFloat())
                }
            }
        }
    }

    // --------------------------------------------------------------- menu

    private fun showCameraMenu(camera: Camera) {
        val sheet = SheetDialog(this, camera.displayName)
        sheet.addItem("观看") {
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 1)
                    .putExtra(LiveActivity.EXTRA_IDS, camera.id)
            )
        }
        sheet.addItem("多路同屏") {
            val ids = store.sortedCameras().take(4).joinToString(",") { it.id }
            startActivity(
                Intent(this, LiveActivity::class.java)
                    .putExtra(LiveActivity.EXTRA_LAYOUT, 4)
                    .putExtra(LiveActivity.EXTRA_IDS, ids)
            )
        }
        sheet.addItem("编辑") {
            startActivity(
                Intent(this, CameraEditActivity::class.java)
                    .putExtra(CameraEditActivity.EXTRA_ID, camera.id)
            )
        }
        sheet.addItem("测试连接") { testConnection(camera) }
        sheet.addItem(if (camera.starred) "取消星标" else "设为重点（星标）") {
            store.toggleStar(camera.id)
            refresh()
        }
        sheet.addItem("删除", danger = true) { confirmDelete(camera) }
        sheet.showSheet()
    }

    private fun testConnection(camera: Camera) {
        Ui.toast(this, "正在连接 " + camera.host + " …")
        scope.launch {
            val result = withContext(Dispatchers.IO) { HikApi.test(camera) }
            Ui.showMessage(
                this@MainActivity,
                if (result.ok) "连接正常" else "连接失败",
                result.message
            )
        }
    }

    private fun confirmDelete(camera: Camera) {
        val sheet = SheetDialog(this, "删除「" + camera.displayName + "」？")
        sheet.addItem("确认删除", danger = true) {
            store.delete(camera.id)
            refresh()
            Ui.toast(this, "已删除")
        }
        sheet.addItem("取消") {}
        sheet.showSheet()
    }

    private fun onAdd() {
        startActivity(Intent(this, CameraEditActivity::class.java))
    }
}
