package com.hikwatch

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import androidx.test.core.app.ApplicationProvider
import com.hikwatch.data.CameraStore
import com.hikwatch.model.Camera
import com.hikwatch.theme.ThemeManager
import com.hikwatch.theme.Themes
import com.hikwatch.ui.LiveActivity
import com.hikwatch.ui.MainActivity
import com.hikwatch.ui.VideoTile
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * v1.0.3 改动专项预览（临时测试，只出图不做断言）：
 * - 16_home_panel_glass：首页下拉面板，检查不透明度与背后毛玻璃
 * - 17_live_16x9_centered：单路 16:9 比例，检查画面是否居中
 * - 18_live_fit_centered：单路「完整画面」（inscribed），同样是居中核对
 */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [33], qualifiers = "w240dp-h240dp-xhdpi")
class PreviewShellTest {

    private val size = 480
    private val outDir = File("preview/raw").apply { mkdirs() }
    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    private fun seedCameras(): List<Camera> {
        val store = CameraStore(context)
        store.cameras().forEach { store.delete(it.id) }
        val cameras = listOf(
            Camera(name = "门口枪机", host = "192.168.1.64", channel = 1, subStream = false, starred = true),
            Camera(name = "仓库通道2", host = "192.168.1.65", channel = 2, subStream = true),
            Camera(name = "车库入口", host = "192.168.1.66", channel = 1, subStream = true, starred = true),
            Camera(name = "后院球机", host = "192.168.1.67", channel = 3, subStream = true),
            Camera(name = "走廊尽头", host = "192.168.1.68", channel = 1, subStream = true),
            Camera(name = "大厅全景", host = "192.168.1.69", channel = 2, subStream = true)
        )
        cameras.forEach { store.upsert(it) }
        store.aspectMode = CameraStore.ASPECT_FILL
        store.simultaneous = 1
        store.showPhoto = true
        store.showRecord = true
        store.showAspect = true
        store.showSound = true
        store.showMulti = true
        store.showSwitch = true
        store.showBack = true
        store.showTopBar = true
        return store.sortedCameras()
    }

    @Test
    fun captureV103() {
        ThemeManager.select(Themes.byId("aurora"))
        seedCameras()

        // ---- 19 首页顶部：时间胶囊 + 应用名
        val home = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        forceLayout(home.window.decorView)
        render("19_home_top_capsule", home)

        // ---- 16 首页下拉面板（毛玻璃）
        val show = MainActivity::class.java
            .getDeclaredMethod("setTelemetryVisible", Boolean::class.javaPrimitiveType)
        show.isAccessible = true
        show.invoke(home, true)
        shadowOf(Looper.getMainLooper()).idleFor(700, TimeUnit.MILLISECONDS)
        forceLayout(home.window.decorView)
        render("16_home_panel_glass", home)

        // ---- 17 单路 16:9（非撑满）
        val store = CameraStore(context)
        store.aspectMode = CameraStore.ASPECT_16_9
        val cameras = store.sortedCameras()
        val ids = cameras.joinToString(",") { it.id }
        render("17_live_16x9_centered", liveActivity(1, ids))

        // ---- 18 单路完整画面（inscribed）
        store.aspectMode = CameraStore.ASPECT_FIT
        render("18_live_fit_centered", liveActivity(1, ids))
    }

    // ------------------------------------------------------------- rendering

    private fun liveActivity(layout: Int, ids: String): Activity {
        val intent = Intent(context, LiveActivity::class.java)
            .putExtra(LiveActivity.EXTRA_LAYOUT, layout)
            .putExtra(LiveActivity.EXTRA_IDS, ids)
        return Robolectric.buildActivity(LiveActivity::class.java, intent).create().get()
    }

    private fun render(name: String, activity: Activity) {
        val root = activity.window.decorView
        forceLayout(root)
        arrangeTiles(activity)
        forceLayout(root)
        fillVideoPlaceholders(root)
        forceLayout(root)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        root.draw(Canvas(bitmap))
        FileOutputStream(File(outDir, "$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        println("SHOT $name")
    }

    private fun arrangeTiles(activity: Activity) {
        if (activity !is LiveActivity) return
        runCatching {
            val method = LiveActivity::class.java.getDeclaredMethod("arrangeTiles")
            method.isAccessible = true
            method.invoke(activity)
        }
    }

    private fun forceLayout(root: View) {
        repeat(4) {
            root.requestLayout()
            root.measure(
                View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(size, View.MeasureSpec.EXACTLY)
            )
            root.layout(0, 0, size, size)
        }
    }

    /** 画一张带清晰边界与中心十字的 16:9 占位帧，方便肉眼核对画面是否居中 */
    private fun fillVideoPlaceholders(view: View) {
        if (view is VideoTile) {
            runCatching { view.showSnapshot(frame(480, 270)) }
        }
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) fillVideoPlaceholders(view.getChildAt(index))
        }
    }

    private fun frame(width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            Color.parseColor("#24313F"), Color.parseColor("#0C1219"),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#2FE3B0")
        }
        canvas.drawRect(1.5f, 1.5f, width - 1.5f, height - 1.5f, border)

        val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 255, 255, 255)
            strokeWidth = 1.5f
        }
        canvas.drawLine(width / 2f, 0f, width / 2f, height.toFloat(), cross)
        canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, cross)

        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("640x360 FRAME", 16f, 36f, text)
        return bitmap
    }
}
