package com.hikwatch.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hikwatch.R
import com.hikwatch.audio.RtspAudioClient
import com.hikwatch.data.CameraStore
import com.hikwatch.media.MediaSaver
import com.hikwatch.model.Camera
import com.hikwatch.net.HikApi
import com.hikwatch.play.RtspPlayer
import com.hikwatch.play.SnapshotPoller
import com.hikwatch.record.ScreenRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 实时观看页：
 * - 1/2/4/6/9 路同屏，点画面进单路，单路左右滑动切换摄像头
 * - 底部：拍照 / 录像 / 画面比例 / 声音，上方「同时观看」切换宫格
 * - 捏合缩放、双击缩放、拖动
 */
class LiveActivity : Activity() {

    companion object {
        const val EXTRA_LAYOUT = "layout"
        const val EXTRA_IDS = "ids"
        private const val REQ_PROJECTION = 3001
        private const val REQ_AUDIO = 3002
        private const val REQ_ASPECT = 3003
    }

    private lateinit var store: CameraStore
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var gridHost: FrameLayout
    private lateinit var topBar: FrostedView
    private lateinit var titleLabel: TextView
    private lateinit var hintLabel: TextView

    private lateinit var btnPhoto: FrameLayout
    private lateinit var btnRecord: FrameLayout
    private lateinit var btnAspect: FrameLayout
    private lateinit var btnSound: FrameLayout
    private lateinit var btnBack: FrameLayout
    private lateinit var btnSwitch: FrameLayout
    private lateinit var btnMulti: TextView

    private val slots = ArrayList<Camera?>(9)
    private val tiles = ArrayList<VideoTile?>(9)
    private val engines = ArrayList<TileEngine?>(9)

    private var visibleCount = 1
    private var previousCount = 1
    private var activeIndex = 0
    private var overlayVisible = true
    private var started = false
    private var ready = false

    private var allCameras: MutableList<Camera> = mutableListOf()
    private var cameraCursor = 0

    private var audioClient: RtspAudioClient? = null
    private var audioCameraId: String? = null

    private var recorder: ScreenRecorder? = null
    private var recordTarget: MediaSaver.VideoTarget? = null
    private var recordStartedAt = 0L
    private var pendingAudio = true

    private var snapshotBusy = false
    private var hintToken = 0

    @Volatile
    private var backdropFrame: Bitmap? = null
    private var backdropOwned: Bitmap? = null
    private var backdropRunning = false
    /** 缩放/拖动进行中：暂停背景采样，优先保证手势帧率 */
    private var gestureHold = false

    private val backdropTick = object : Runnable {
        override fun run() {
            if (!backdropRunning) return
            // 手势期间不抓帧，把 GPU/主线程让给缩放动画
            if (!gestureHold && (overlayVisible || recorder != null)) captureBackdrop()
            handler.postDelayed(this, if (gestureHold) 220L else 320L)
        }
    }

    private val hideRunnable = Runnable {
        if (recorder == null) setOverlayVisible(false)
    }

    private val recordTick = object : Runnable {
        override fun run() {
            if (recorder == null) return
            val elapsed = (SystemClock.elapsedRealtime() - recordStartedAt) / 1000
            hintLabel.text = String.format("● 录制中 %02d:%02d", elapsed / 60, elapsed % 60)
            handler.postDelayed(this, 500)
        }
    }

    // ------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        allCameras = store.sortedCameras()
        readIntent()
        if (slots.all { it == null }) {
            Ui.toast(this, "还没有监控，请先添加")
            finish()
            return
        }
        buildUi()
        rebuildTiles()
        applyWindowFlags()
        // 部分 ROM 只把表冠/滚轮事件投给持焦点的视图树，这里主动拿一下焦点
        root.post { root.requestFocus() }
        ready = true
    }

    override fun onStart() {
        super.onStart()
        if (!ready) return
        started = true
        startEngines()
        applyControlSettings()
        setOverlayVisible(true)
        backdropRunning = true
        handler.removeCallbacks(backdropTick)
        handler.post(backdropTick)
    }

    override fun onStop() {
        if (!ready) {
            super.onStop()
            return
        }
        started = false
        backdropRunning = false
        handler.removeCallbacks(backdropTick)
        backdropFrame = null
        backdropOwned?.let { previous -> if (!previous.isRecycled) previous.recycle() }
        backdropOwned = null
        stopEngines()
        stopAudio()
        if (recorder != null) stopRecording()
        handler.removeCallbacks(hideRunnable)
        handler.removeCallbacks(recordTick)
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (visibleCount != 1) {
            visibleCount = 1
            rebuildTiles()
            if (started) startEngines()
            return
        }
        if (previousCount > 1) {
            visibleCount = previousCount
            rebuildTiles()
            if (started) startEngines()
            return
        }
        super.onBackPressed()
    }

    private fun readIntent() {
        val ids = intent.getStringExtra(EXTRA_IDS).orEmpty()
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        val byId = allCameras.associateBy { it.id }
        for (index in 0 until 9) {
            slots.add(if (index < ids.size) byId[ids[index]] else null)
        }
        val used = slots.filterNotNull().map { it.id }.toMutableSet()
        var cursor = 0
        for (index in 0 until 9) {
            if (slots[index] != null) continue
            while (cursor < allCameras.size && used.contains(allCameras[cursor].id)) cursor++
            if (cursor >= allCameras.size) break
            slots[index] = allCameras[cursor]
            used.add(allCameras[cursor].id)
            cursor++
        }
        visibleCount = store.simultaneous.coerceIn(1, 9)
        if (intent.hasExtra(EXTRA_LAYOUT)) {
            visibleCount = intent.getIntExtra(EXTRA_LAYOUT, visibleCount).coerceIn(1, 9)
        }
        if (slots.take(visibleCount).all { it == null }) visibleCount = 1
        previousCount = visibleCount
        val first = slots.firstOrNull()
        cameraCursor = allCameras.indexOfFirst { it.id == first?.id }.coerceAtLeast(0)
    }

    private fun applyWindowFlags() {
        if (store.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    // ------------------------------------------------------------------- ui

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        // 让窗口把 generic motion（表冠 / 滚轮）投递到视图树，而不是直接丢掉
        root.isFocusable = true
        root.isFocusableInTouchMode = true

        gridHost = FrameLayout(this)
        root.addView(
            gridHost,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        gridHost.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) arrangeTiles()
        }

        topBar = FrostedView(this).apply {
            tintColor = Color.argb(150, 8, 13, 21)
            provider = { backdropFrame }
        }
        val topContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(
                Ui.dp(context, 10f), Ui.dp(context, 5f),
                Ui.dp(context, 10f), Ui.dp(context, 6f)
            )
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val liveDot = View(this)
        liveDot.background = Ui.solid(Ui.ACCENT, Ui.dp(this, 2.5f).toFloat())
        titleRow.addView(
            liveDot,
            LinearLayout.LayoutParams(Ui.dp(this, 5f), Ui.dp(this, 5f)).apply {
                rightMargin = Ui.dp(this@LiveActivity, 4f)
            }
        )
        titleLabel = Ui.label(this, "", 10.5f, Ui.TEXT, bold = true)
        titleLabel.letterSpacing = 0.02f
        titleLabel.maxLines = 1
        titleLabel.ellipsize = android.text.TextUtils.TruncateAt.END
        titleRow.addView(titleLabel)
        topContent.addView(titleRow)

        hintLabel = Ui.label(this, "", 8f, Ui.TEXT2)
        hintLabel.gravity = Gravity.CENTER
        hintLabel.maxLines = 1
        hintLabel.ellipsize = android.text.TextUtils.TruncateAt.END
        topContent.addView(hintLabel)

        topBar.addView(
            topContent,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        topBar.setOnClickListener { showMainMenu() }
        root.addView(
            topBar,
            FrameLayout.LayoutParams(
                Ui.dp(this, 148f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = Ui.dp(this@LiveActivity, 9f) }
        )

        btnPhoto = actionButton(R.drawable.ic_snapshot) { takeSnapshot() }
        btnRecord = actionButton(R.drawable.ic_record) { toggleRecording() }
        btnAspect = actionButton(R.drawable.ic_aspect) { showAspectMenu() }
        btnSound = actionButton(R.drawable.ic_speaker_off) { toggleAudio() }
        for (button in actionButtons()) {
            root.addView(button, FrameLayout.LayoutParams(Ui.dp(this, 34f), Ui.dp(this, 34f)))
        }

        btnMulti = Ui.label(this, "", 9.5f, Ui.TEXT, bold = true).apply {
            gravity = Gravity.CENTER
            background = Ui.ripple(Ui.solid(Ui.PANEL, Ui.dp(this@LiveActivity, 11f).toFloat()))
            isClickable = true
            setPadding(Ui.dp(this@LiveActivity, 8f), 0, Ui.dp(this@LiveActivity, 8f), 0)
            setOnClickListener { showMultiMenu() }
        }
        root.addView(
            btnMulti,
            FrameLayout.LayoutParams(
                Ui.dp(this, 62f),
                Ui.dp(this, 23f),
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            )
        )

        btnBack = Ui.iconButton(
            this, R.drawable.ic_back, 34f, Color.argb(150, 8, 13, 21), Ui.TEXT
        ) { onBackPressed() }
        root.addView(
            btnBack,
            FrameLayout.LayoutParams(
                Ui.dp(this, 34f),
                Ui.dp(this, 34f),
                Gravity.START or Gravity.CENTER_VERTICAL
            ).apply { leftMargin = Ui.dp(this@LiveActivity, 3f) }
        )

        btnSwitch = Ui.iconButton(
            this, R.drawable.ic_switch, 34f, Color.argb(150, 8, 13, 21), Ui.TEXT
        ) { showCameraPicker(activeIndex.coerceIn(0, visibleCount - 1)) }
        root.addView(
            btnSwitch,
            FrameLayout.LayoutParams(
                Ui.dp(this, 34f),
                Ui.dp(this, 34f),
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply { rightMargin = Ui.dp(this@LiveActivity, 3f) }
        )

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol || b - t != ob - ot) layoutControls()
        }

        setContentView(root)
        applyControlSettings()
    }

    private fun actionButtons(): List<FrameLayout> =
        listOf(btnPhoto, btnRecord, btnAspect, btnSound)

    private fun actionButton(iconRes: Int, onClick: () -> Unit): FrameLayout =
        Ui.iconButton(this, iconRes, 34f, Color.argb(150, 8, 13, 21), Ui.TEXT) { onClick() }

    /** 底部按键沿圆弧排布；「同时观看」贴在圆弧正上方 */
    private fun layoutControls() {
        val width = if (root.width > 0) root.width else resources.displayMetrics.widthPixels
        val height = if (root.height > 0) root.height else resources.displayMetrics.heightPixels
        if (width <= 0 || height <= 0) return

        val visible = actionButtons().filter { it.visibility == View.VISIBLE }
        val size = Ui.dp(this, 34f).toFloat()
        val centerX = width / 2f
        val centerY = height / 2f
        val radius = minOf(width, height) * 0.405f
        val spacing = 22.5f
        val spread = if (visible.size <= 1) 0f else (visible.size - 1) * spacing / 2f
        visible.forEachIndexed { index, button ->
            val angle = if (visible.size == 1) 0f else -spread + index * spacing
            val radians = Math.toRadians(angle.toDouble())
            val x = centerX + (radius * kotlin.math.sin(radians)).toFloat()
            val y = centerY + (radius * kotlin.math.cos(radians)).toFloat()
            val params = button.layoutParams as FrameLayout.LayoutParams
            params.gravity = Gravity.TOP or Gravity.START
            params.width = size.toInt()
            params.height = size.toInt()
            params.leftMargin = (x - size / 2f).toInt()
            params.topMargin = (y - size / 2f).toInt()
            button.layoutParams = params
        }

        if (btnMulti.visibility == View.VISIBLE) {
            val multiWidth = Ui.dp(this, 62f)
            val multiHeight = Ui.dp(this, 23f)
            val params = btnMulti.layoutParams as FrameLayout.LayoutParams
            params.width = multiWidth
            params.height = multiHeight
            params.gravity = Gravity.TOP or Gravity.START
            params.leftMargin = ((width - multiWidth) / 2f).toInt()
            params.topMargin = (centerY + radius * 0.56f - multiHeight).toInt()
            btnMulti.layoutParams = params
        }
    }

    private fun applyControlSettings() {
        btnPhoto.visibility = if (store.showPhoto) View.VISIBLE else View.GONE
        btnRecord.visibility = if (store.showRecord) View.VISIBLE else View.GONE
        btnAspect.visibility = if (store.showAspect) View.VISIBLE else View.GONE
        btnSound.visibility = if (store.showSound) View.VISIBLE else View.GONE
        btnBack.visibility = if (store.showBack) View.VISIBLE else View.GONE
        btnSwitch.visibility = if (store.showSwitch) View.VISIBLE else View.GONE
        btnMulti.visibility = if (store.showMulti) View.VISIBLE else View.GONE
        topBar.visibility = if (store.showTopBar || recorder != null) View.VISIBLE else View.GONE
        updateMultiLabel()
        layoutControls()
    }

    private fun updateMultiLabel() {
        btnMulti.text = "▦ " + visibleCount + " 路"
    }

    private fun updateTitle() {
        val camera = slots.getOrNull(activeIndex)
        titleLabel.text = if (visibleCount == 1) {
            camera?.displayName ?: "未分配"
        } else {
            visibleCount.toString() + " 路同屏"
        }
        hintLabel.text = if (visibleCount == 1) {
            if (camera == null) "点右侧选择摄像头" else "左右滑动切换 · 双指 / 表冠放大"
        } else {
            "点任意画面全屏放大"
        }
    }

    private fun updateButtons() {
        iconOf(btnSound)?.setImageResource(
            if (audioClient != null) R.drawable.ic_speaker else R.drawable.ic_speaker_off
        )
        iconOf(btnRecord)?.setImageResource(
            if (recorder != null) R.drawable.ic_stop else R.drawable.ic_record
        )
    }

    private fun iconOf(view: View): ImageView? {
        if (view is ImageView) return view
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                val found = iconOf(view.getChildAt(index))
                if (found != null) return found
            }
        }
        return null
    }

    private fun showHint(text: String) {
        hintToken++
        val token = hintToken
        hintLabel.text = text
        handler.postDelayed({
            if (token == hintToken) updateTitle()
        }, 4500)
    }

    private fun setOverlayVisible(show: Boolean) {
        overlayVisible = show
        handler.removeCallbacks(hideRunnable)
        val controls = ArrayList<View>()
        controls.add(btnBack)
        controls.add(btnSwitch)
        controls.add(btnMulti)
        controls.addAll(actionButtons())
        controls.add(topBar)

        if (show) {
            applyControlSettings()
            for (view in controls) {
                if (view.visibility != View.VISIBLE) continue
                view.animate().cancel()
                view.alpha = 0f
                view.animate().alpha(1f)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .setDuration(200L).start()
            }
            topBar.refreshNow()
            if (recorder == null) handler.postDelayed(hideRunnable, 6000)
        } else {
            for (view in controls) {
                if (view.visibility != View.VISIBLE) continue
                view.animate().cancel()
                view.animate().alpha(0f)
                    .setInterpolator(android.view.animation.AccelerateInterpolator())
                    .setDuration(150L).withEndAction {
                    if (!overlayVisible) view.visibility = View.GONE
                }.start()
            }
        }
    }

    private fun toggleOverlay() {
        setOverlayVisible(!overlayVisible)
    }

    // ---------------------------------------------------------- background

    private fun captureBackdrop() {
        val index = if (visibleCount == 1) 0 else activeIndex.coerceIn(0, visibleCount - 1)
        val tile = tiles.getOrNull(index) ?: return
        val frame = runCatching { tile.frameBitmap(88) }.getOrNull() ?: return
        val previous = backdropOwned
        backdropFrame = frame
        backdropOwned = if (tile.isShowingVideo()) frame else null
        if (previous != null && previous !== frame && !previous.isRecycled) previous.recycle()
        if (overlayVisible) topBar.refreshNow()
    }

    // -------------------------------------------------------------- engines

    private inner class TileEngine(
        private val index: Int,
        private val camera: Camera,
        private val tile: VideoTile
    ) {
        private var rtsp: RtspPlayer? = null
        private var poller: SnapshotPoller? = null
        private var stopped = false
        private var usedSnapshotFallback = false

        fun start() {
            stopped = false
            tile.showVideo()
            tile.setName(camera.displayName)
            tile.applyAspect(store.aspectMode, store.customAspect)
            if (camera.mode == Camera.MODE_SNAPSHOT) {
                startSnapshot()
                return
            }
            if (visibleCount > 1 && !store.gridAllLive && index != activeIndex) {
                startSnapshot()
                return
            }
            tile.setStatus("连接中…")
            // 清晰度设置决定用主码流还是子码流
            val playCamera = camera.copy(subStream = store.subStreamFor(camera))
            val player = RtspPlayer(this@LiveActivity, playCamera, tile.texture, object : RtspPlayer.Callback {
                override fun onState(text: String) {
                    if (!stopped) tile.setStatus(text)
                }

                override fun onAspect(aspect: Float) {
                    tile.setSourceAspect(aspect)
                }

                override fun onFirstFrame() {
                    if (!stopped) {
                        tile.setStatus("")
                        tile.setBadge("")
                    }
                }

                override fun onFatal(message: String) {
                    if (stopped) return
                    if (camera.mode == Camera.MODE_AUTO && !usedSnapshotFallback) {
                        usedSnapshotFallback = true
                        tile.setBadge("抓拍模式")
                        startSnapshot()
                    } else {
                        tile.setStatus("连接失败：" + message)
                    }
                }
            })
            rtsp = player
            player.start()
        }

        private fun startSnapshot() {
            rtsp?.stop()
            rtsp = null
            tile.setBadge("抓拍模式")
            // 抓拍用主码流地址，画质更好
            val snapCamera = camera.copy(subStream = false)
            val pollerInstance = SnapshotPoller(
                snapCamera,
                450,
                object : SnapshotPoller.Callback {
                    override fun onFrame(bitmap: Bitmap) {
                        if (stopped) return
                        tile.showSnapshot(bitmap)
                        tile.setStatus("")
                    }

                    override fun onError(message: String) {
                        if (!stopped) tile.setStatus(message)
                    }
                }
            )
            poller = pollerInstance
            pollerInstance.start(scope)
        }

        fun stop() {
            stopped = true
            rtsp?.stop()
            rtsp = null
            poller?.stop()
            poller = null
        }
    }

    private fun startEngines() {
        for (index in 0 until visibleCount) {
            val camera = slots.getOrNull(index) ?: continue
            val tile = tiles.getOrNull(index) ?: continue
            engines.getOrNull(index)?.stop()
            val engine = TileEngine(index, camera, tile)
            engines[index] = engine
            engine.start()
        }
    }

    private fun stopEngines() {
        for (index in engines.indices) {
            engines[index]?.stop()
            engines[index] = null
        }
    }

    // --------------------------------------------------------------- tiles

    private fun rebuildTiles() {
        stopEngines()
        gridHost.removeAllViews()
        tiles.clear()
        engines.clear()
        repeat(9) {
            tiles.add(null)
            engines.add(null)
        }
        for (index in 0 until visibleCount) {
            val camera = slots.getOrNull(index)
            val tile = VideoTile(this)
            tile.inscribed = visibleCount == 1
            tile.fillScreen = store.fillScreen && store.aspectMode == CameraStore.ASPECT_FILL
            tile.zoomEnabled = visibleCount == 1
            tile.swipeEnabled = visibleCount == 1
            tile.compact = visibleCount >= 6
            tile.applyAspect(store.aspectMode, store.customAspect)
            tile.setName(camera?.displayName ?: "未分配")
            if (camera == null) tile.setStatus("点右侧选择摄像头")
            tile.onTap = { onTileTap(index) }
            tile.onLongPress = { showTileMenu(index) }
            tile.onSwipe = { direction -> switchCamera(direction) }
            // 手势进行中暂停背景抓帧：TextureView.getBitmap 要等 GPU 回收，
            // 和缩放帧抢主线程时会明显掉帧（这是"双指缩放发涩"的主因之一）
            tile.onGestureActive = { active ->
                gestureHold = active
                topBar.paused = active
                if (!active) {
                    handler.removeCallbacks(backdropTick)
                    if (backdropRunning) handler.postDelayed(backdropTick, 120L)
                }
            }
            gridHost.addView(
                tile,
                FrameLayout.LayoutParams(Ui.dp(this, 20f), Ui.dp(this, 20f))
            )
            tiles[index] = tile
        }
        arrangeTiles()
        gridHost.post { arrangeTiles() }
        updateTitle()
        updateButtons()
        updateMultiLabel()
    }

    private fun columnsFor(count: Int): Int = when {
        count <= 2 -> 1
        count <= 6 -> 2
        else -> 3
    }

    private fun arrangeTiles() {
        val width = gridHost.width
        val height = gridHost.height
        if (width <= 0 || height <= 0) return
        val columns = columnsFor(visibleCount)
        val rows = (visibleCount + columns - 1) / columns
        val cellWidth = width / columns
        val cellHeight = height / rows
        for (index in 0 until visibleCount) {
            val tile = tiles.getOrNull(index) ?: continue
            val params = tile.layoutParams as? FrameLayout.LayoutParams
                ?: FrameLayout.LayoutParams(cellWidth, cellHeight)
            val row = index / columns
            val column = index % columns
            params.width = cellWidth
            params.height = cellHeight
            params.leftMargin = column * cellWidth
            params.topMargin = row * cellHeight
            params.gravity = Gravity.TOP or Gravity.START
            tile.layoutParams = params
            tile.inscribed = visibleCount == 1
            tile.zoomEnabled = visibleCount == 1
            tile.swipeEnabled = visibleCount == 1
            tile.compact = visibleCount >= 6
            tile.fillScreen = store.fillScreen && store.aspectMode == CameraStore.ASPECT_FILL
            tile.setLabelAnchor(labelAnchor(row, column, columns, rows))
        }
    }

    private fun labelAnchor(row: Int, column: Int, columns: Int, rows: Int): Int {
        if (columns == 1 && rows == 1) return Gravity.TOP or Gravity.START
        if (columns == 1) return if (row == 0) Gravity.BOTTOM or Gravity.START else Gravity.TOP or Gravity.START
        val vertical = if (row * 2 < rows) Gravity.BOTTOM else Gravity.TOP
        val horizontal = if (column * 2 < columns) Gravity.END else Gravity.START
        return vertical or horizontal
    }

    // ----------------------------------------------------------- interaction

    // -------------------------------------------------------- 表冠缩放 (v1.0.3)

    private var crownLastAt = 0L
    private var crownSeenLogged = false
    private var rawMotionLogged = false
    private var rawKeyLogged = false

    /**
     * 表冠旋转 → 缩放当前单路画面。
     *
     * 兼容策略：不再要求 SOURCE_ROTARY_ENCODER。Wear OS 走 ACTION_SCROLL，
     * ColorOS Watch / 部分 MTK 方案会把表冠塞进 AXIS_VSCROLL/WHEEL，
     * 还有一类系统直接下发 DPAD_UP/DOWN —— 三种都在这里接住。
     */
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        // 首次收到非触摸类 generic motion 时打点，方便确认这台设备到底有没有表冠事件
        if (!rawMotionLogged && (ev.source and InputDevice.SOURCE_TOUCHSCREEN) == 0) {
            rawMotionLogged = true
            com.hikwatch.util.CrashLog.log(
                this,
                "generic motion: action=${ev.actionMasked} source=${Integer.toHexString(ev.source)}" +
                    " scroll=${ev.getAxisValue(MotionEvent.AXIS_SCROLL)}" +
                    " vs=${ev.getAxisValue(MotionEvent.AXIS_VSCROLL)}" +
                    " wheel=${ev.getAxisValue(MotionEvent.AXIS_WHEEL)}"
            )
        }
        if (consumeCrownScroll(ev)) return true
        return super.dispatchGenericMotionEvent(ev)
    }

    /** Activity 兜底：个别系统把未消费的 generic motion 从这条链路回传 */
    override fun onGenericMotionEvent(ev: MotionEvent): Boolean {
        if (consumeCrownScroll(ev)) return true
        return super.onGenericMotionEvent(ev)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (!rawKeyLogged) {
                rawKeyLogged = true
                com.hikwatch.util.CrashLog.log(
                    this,
                    "key: code=${event.keyCode} repeat=${event.repeatCount}" +
                        " source=${Integer.toHexString(event.source)}"
                )
            }
            val fromCrown = (event.source and InputDevice.SOURCE_ROTARY_ENCODER) != 0
            val step = when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PAGE_UP -> 1f
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> -1f
                // 音量键只有在明确来自旋转编码器时才接管，避免抢掉正常音量调节
                KeyEvent.KEYCODE_VOLUME_UP -> if (fromCrown) 1f else 0f
                KeyEvent.KEYCODE_VOLUME_DOWN -> if (fromCrown) -1f else 0f
                else -> 0f
            }
            if (step != 0f && crownStep(step)) return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun consumeCrownScroll(ev: MotionEvent): Boolean {
        if (ev.actionMasked != MotionEvent.ACTION_SCROLL) return false
        val delta = VideoTile.rotaryDelta(ev)
        if (delta == 0f) return false
        if (!crownSeenLogged) {
            crownSeenLogged = true
            com.hikwatch.util.CrashLog.log(
                this,
                "crown event: axis=${ev.getAxisValue(MotionEvent.AXIS_SCROLL)}" +
                    " vs=${ev.getAxisValue(MotionEvent.AXIS_VSCROLL)}" +
                    " source=${Integer.toHexString(ev.source)}"
            )
        }
        return crownZoom(delta)
    }

    /** 方向键一次性触发（长按连发时按 40ms 节流，避免一按就冲到 5×） */
    private fun crownStep(step: Float): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - crownLastAt < 40L) return crownZoom(step, silent = true)
        crownLastAt = now
        return crownZoom(step)
    }

    private fun crownZoom(delta: Float, silent: Boolean = false): Boolean {
        if (visibleCount != 1) {
            if (!silent) showHint("表冠缩放仅单路画面可用")
            return true
        }
        val tile = tiles.getOrNull(0) ?: return false
        if (!tile.zoomEnabled) return false
        if (!tile.rotateZoom(if (silent) delta * 0.4f else delta)) {
            if (!silent) {
                showHint(
                    if (tile.zoomLevel >= 4.99f) "已是最大 5.0×"
                    else "已回到原始大小 1.0×"
                )
            }
            return true
        }
        if (!silent) {
            showHint(String.format(java.util.Locale.US, "画面 %.1f×  ·  表冠缩放", tile.zoomLevel))
        }
        return true
    }

    private fun onTileTap(index: Int) {
        activeIndex = index
        if (visibleCount == 1) {
            toggleOverlay()
            return
        }
        focusTile(index)
    }

    private fun focusTile(index: Int) {
        if (index < 0 || index >= visibleCount) return
        if (index != 0) {
            val swap = slots[0]
            slots[0] = slots[index]
            slots[index] = swap
        }
        previousCount = visibleCount
        visibleCount = 1
        activeIndex = 0
        val camera = slots[0]
        if (camera != null) {
            cameraCursor = allCameras.indexOfFirst { it.id == camera.id }.coerceAtLeast(0)
        }
        rebuildTiles()
        if (started) startEngines()
        setOverlayVisible(true)
    }

    /** 单路左右滑动切换摄像头：direction +1 下一台，-1 上一台 */
    private fun switchCamera(direction: Int) {
        if (visibleCount != 1 || allCameras.isEmpty()) return
        cameraCursor = (cameraCursor + direction).mod(allCameras.size)
        val camera = allCameras[cameraCursor]
        slots[0] = camera
        stopAudio()
        rebuildTiles()
        if (started) startEngines()
        setOverlayVisible(true)
        Ui.toast(this, camera.displayName)
    }

    private fun showAspectMenu() {
        val sheet = SheetDialog(this, "画面比例")
        sheet.addItem("撑满全屏（裁切）") { setAspect(CameraStore.ASPECT_FILL) }
        sheet.addItem("完整画面（黑边）") { setAspect(CameraStore.ASPECT_FIT) }
        sheet.addItem("16 : 9") { setAspect(CameraStore.ASPECT_16_9) }
        sheet.addItem("4 : 3") { setAspect(CameraStore.ASPECT_4_3) }
        sheet.addItem("自定义比例…") { askCustomAspect() }
        sheet.showSheet()
    }

    private fun setAspect(mode: String) {
        store.aspectMode = mode
        for (index in 0 until visibleCount) {
            tiles.getOrNull(index)?.fillScreen = store.fillScreen && mode == CameraStore.ASPECT_FILL
            tiles.getOrNull(index)?.applyAspect(mode, store.customAspect)
        }
        Ui.toast(this, "画面比例：" + store.aspectLabel(mode, store.customAspect))
    }

    private fun askCustomAspect() {
        startActivityForResult(
            TextInputActivity.intent(
                this,
                "自定义画面比例",
                "宽 / 高，例如 1.85",
                String.format("%.2f", store.customAspect),
                true
            ),
            REQ_ASPECT
        )
    }

    private fun showMultiMenu() {
        val sheet = SheetDialog(this, "同时观看")
        val cameraCount = store.cameras().size.coerceAtLeast(1)
        for (count in listOf(1, 2, 4, 6, 9)) {
            val enabled = count <= cameraCount
            sheet.addItem(
                count.toString() + " 路" + if (count == visibleCount) "  ✓" else "",
                enabled = enabled
            ) {
                visibleCount = count
                store.simultaneous = count
                activeIndex = 0
                previousCount = count
                rebuildTiles()
                if (started) startEngines()
            }
        }
        sheet.addText("当前共 " + store.cameras().size + " 个监控")
        sheet.showSheet()
    }

    private fun showTileMenu(index: Int) {
        val camera = slots.getOrNull(index)
        val sheet = SheetDialog(this, camera?.displayName ?: "第 " + (index + 1) + " 路")
        sheet.addItem("选择摄像头") { showCameraPicker(index) }
        if (camera != null) {
            if (visibleCount > 1 && !store.gridAllLive && index != activeIndex) {
                sheet.addItem("让这一路实时") {
                    activeIndex = index
                    rebuildTiles()
                    if (started) startEngines()
                }
            }
            if (visibleCount > 1) {
                sheet.addItem("全屏放大这一路") { focusTile(index) }
            } else if (previousCount > 1) {
                sheet.addItem("返回 " + previousCount + " 路同屏") {
                    visibleCount = previousCount
                    rebuildTiles()
                    if (started) startEngines()
                }
            }
            sheet.addItem(if (audioCameraId == camera.id) "关闭声音" else "听这一路的声音") {
                if (audioCameraId == camera.id) stopAudio() else startAudio(camera)
            }
            sheet.addItem("截图") { takeSnapshotAt(index) }
            sheet.addItem("画面比例") { showAspectMenu() }
        }
        sheet.showSheet()
    }

    private fun showCameraPicker(index: Int) {
        val all = store.sortedCameras()
        val sheet = SheetDialog(this, "第 " + (index + 1) + " 路选择")
        if (all.isEmpty()) sheet.addText("还没有监控，请先回首页添加")
        for (camera in all) {
            val current = slots.getOrNull(index)?.id == camera.id
            sheet.addItem((if (current) "✓ " else "") + camera.displayName) {
                slots[index] = camera
                activeIndex = index
                rebuildTiles()
                if (started) startEngines()
            }
        }
        sheet.addItem("清空这一路", danger = true) {
            slots[index] = null
            rebuildTiles()
            if (started) startEngines()
        }
        sheet.showSheet()
    }

    private fun showMainMenu() {
        val sheet = SheetDialog(this, "更多")
        sheet.addItem("画面比例") { showAspectMenu() }
        sheet.addItem("同时观看") { showMultiMenu() }
        sheet.addItem("隐藏操作栏") { setOverlayVisible(false) }
        sheet.addItem("返回首页") { finish() }
        sheet.showSheet()
    }

    // ----------------------------------------------------------------- audio

    private fun toggleAudio() {
        if (audioClient != null) {
            stopAudio()
            return
        }
        val camera = slots.getOrNull(activeIndex) ?: slots.getOrNull(0) ?: run {
            Ui.toast(this, "没有可听的画面")
            return
        }
        startAudio(camera)
    }

    private fun startAudio(camera: Camera) {
        stopAudioInternal()
        val token = camera.id
        val client = RtspAudioClient(
            camera.host,
            camera.rtspPort,
            camera.user,
            camera.pass,
            "/Streaming/Channels/" + camera.channelPath,
            object : RtspAudioClient.Listener {
                override fun onStatus(text: String) = postAudioHint(token, text)
                override fun onError(text: String) = postAudioError(token, text)
                override fun onCodec(text: String) = postAudioHint(token, "声音：" + text)
            }
        )
        audioClient = client
        audioCameraId = token
        client.start()
        updateButtons()
        showHint("正在连接声音…")
    }

    private fun postAudioHint(token: String, text: String) {
        runOnUiThread {
            if (audioCameraId == token) showHint(text)
        }
    }

    private fun postAudioError(token: String, text: String) {
        runOnUiThread {
            if (audioCameraId == token) {
                showHint(text)
                Ui.toast(this, text)
                stopAudio()
            }
        }
    }

    private fun stopAudioInternal() {
        val client = audioClient ?: return
        audioClient = null
        audioCameraId = null
        runCatching { client.stop() }
        updateButtons()
    }

    private fun stopAudio() {
        if (audioClient == null) return
        stopAudioInternal()
        showHint("已关闭声音")
    }

    // -------------------------------------------------------------- snapshot

    private fun takeSnapshot() {
        val index = if (visibleCount == 1) 0 else activeIndex.coerceIn(0, visibleCount - 1)
        takeSnapshotAt(index)
    }

    private fun takeSnapshotAt(index: Int) {
        if (snapshotBusy) return
        val camera = slots.getOrNull(index) ?: run {
            Ui.toast(this, "这一路还没有摄像头")
            return
        }
        val tile = tiles.getOrNull(index) ?: return
        snapshotBusy = true
        showHint("正在截图…")
        scope.launch {
            val bytes = withContext(Dispatchers.IO) {
                runCatching { HikApi.snapshotBytes(camera) }.getOrNull()
            }
            var ok = false
            if (bytes != null) {
                ok = withContext(Dispatchers.IO) {
                    runCatching {
                        MediaSaver.saveJpeg(this@LiveActivity, bytes, camera.displayName) != null
                    }.getOrDefault(false)
                }
            }
            if (!ok) {
                val bitmap = tile.currentBitmap()
                if (bitmap != null) {
                    ok = withContext(Dispatchers.IO) {
                        runCatching {
                            val out = java.io.ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                            MediaSaver.saveJpeg(
                                this@LiveActivity,
                                out.toByteArray(),
                                camera.displayName
                            ) != null
                        }.getOrDefault(false)
                    }
                }
            }
            snapshotBusy = false
            val message = if (ok) "截图已保存 Pictures/HikWatch" else "截图失败"
            showHint(message)
            Ui.toast(this@LiveActivity, message)
        }
    }

    // ------------------------------------------------------------- recording

    private fun toggleRecording() {
        if (recorder != null) {
            stopRecording()
            return
        }
        pendingAudio = store.recordWithAudio
        if (pendingAudio &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        if (manager == null) {
            Ui.toast(this, "当前系统不支持屏幕录制")
            return
        }
        Ui.toast(this, "请在弹窗中选择「开始录制」")
        runCatching {
            startActivityForResult(manager.createScreenCaptureIntent(), REQ_PROJECTION)
        }.onFailure {
            Ui.toast(this, "无法打开录屏授权：" + (it.message ?: "未知错误"))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_AUDIO) return
        pendingAudio = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (!pendingAudio) Ui.toast(this, "未授予录音权限，将只录画面")
        requestProjection()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ASPECT) {
            if (resultCode != RESULT_OK) return
            val value = data?.getStringExtra(TextInputActivity.EXTRA_RESULT).orEmpty()
            val ratio = value.replace(',', '.').toFloatOrNull()
            if (ratio == null || ratio < 0.3f || ratio > 4f) {
                Ui.toast(this, "请输入 0.3 ~ 4.0 之间的比例")
            } else {
                store.customAspect = ratio
                setAspect(CameraStore.ASPECT_CUSTOM)
            }
            return
        }
        if (requestCode != REQ_PROJECTION) return
        if (resultCode != RESULT_OK || data == null) {
            Ui.toast(this, "已取消录像")
            return
        }
        try {
            startRecording(resultCode, data)
        } catch (t: Throwable) {
            Ui.toast(this, "录像启动失败：" + (t.message ?: t.javaClass.simpleName))
            cleanRecordingState()
        }
    }

    private fun startRecording(resultCode: Int, data: Intent) {
        val manager = getSystemService(MediaProjectionManager::class.java) ?: return
        val projection = manager.getMediaProjection(resultCode, data)
        if (projection == null) {
            Ui.toast(this, "无法获取录屏权限")
            return
        }
        val camera = slots.getOrNull(activeIndex) ?: slots.getOrNull(0)
        val target = MediaSaver.createVideoTarget(this, camera?.displayName ?: "camera")
        if (target == null) {
            Ui.toast(this, "创建录像文件失败")
            runCatching { projection.stop() }
            return
        }
        val metrics = resources.displayMetrics
        val screenRecorder = ScreenRecorder(
            this,
            projection,
            target.pfd,
            metrics.widthPixels,
            metrics.heightPixels,
            pendingAudio,
            onError = { message -> runOnUiThread { Ui.toast(this, message) } },
            onFinished = { runOnUiThread { finishRecording() } }
        )
        if (!screenRecorder.start()) {
            MediaSaver.abandonVideo(this, target)
            runCatching { target.pfd.close() }
            runCatching { projection.stop() }
            return
        }
        recorder = screenRecorder
        recordTarget = target
        recordStartedAt = SystemClock.elapsedRealtime()
        setOverlayVisible(false)
        topBar.animate().cancel()
        topBar.alpha = 1f
        topBar.visibility = View.VISIBLE
        updateButtons()
        handler.post(recordTick)
        Ui.toast(this, "开始录像")
    }

    private fun stopRecording() {
        val screenRecorder = recorder
        if (screenRecorder == null) {
            cleanRecordingState()
            return
        }
        // 立即复位 UI；编码器在工作线程收尾，完成后回调 finishRecording
        recorder = null
        handler.removeCallbacks(recordTick)
        hintLabel.text = "正在保存录像…"
        runCatching { screenRecorder.stop() }
        updateButtons()
        setOverlayVisible(true)
    }

    private fun finishRecording() {
        if (recordTarget == null) {
            cleanRecordingState()
            return
        }
        val target = recordTarget
        recordTarget = null
        recorder = null
        handler.removeCallbacks(recordTick)
        if (target != null) {
            MediaSaver.publishVideo(this, target)
            runCatching { target.pfd.close() }
            Ui.toast(this, "录像已保存：相册 Movies/HikWatch")
        }
        setOverlayVisible(true)
        updateButtons()
        showHint("录像已保存")
    }

    private fun cleanRecordingState() {
        handler.removeCallbacks(recordTick)
        recorder = null
        val target = recordTarget
        recordTarget = null
        target?.let { runCatching { it.pfd.close() } }
        setOverlayVisible(true)
        updateButtons()
    }
}
