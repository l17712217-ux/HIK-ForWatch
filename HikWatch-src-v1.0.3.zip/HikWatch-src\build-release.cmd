@echo off
REM ---- v1.0.3 构建入口：内置本机 JDK / Android SDK 路径，无需手动配环境变量 ----
setlocal
set "JAVA_HOME=C:\Users\klyz\Documents\Adobe\HIK-dev\jdk"
set "ANDROID_HOME=C:\Users\klyz\Documents\Adobe\HIK-dev\sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
set "PATH=%JAVA_HOME%\bin;%ANDROID_HOME%\platform-tools;%PATH%"

cd /d "%~dp0"

if "%~1"=="" (
    echo 用法: build-release.cmd assembleRelease
    echo       build-release.cmd testReleaseUnitTest
    echo       build-release.cmd clean assembleRelease
    echo 产物: app\build\outputs\apk\release\app-release.apk
    exit /b 1
)

call gradlew.bat %* --console=plain
echo.
echo exit code: %ERRORLEVEL%
endlocal
