@echo off
REM ---- 把 release APK 侧载到手表（OPPO Watch X2 / ColorOS Watch）----
setlocal
set "ANDROID_HOME=C:\Users\klyz\Documents\Adobe\HIK-dev\sdk"
set "PATH=%ANDROID_HOME%\platform-tools;%PATH%"
set "APK=%~dp0app\build\outputs\apk\release\app-release.apk"

echo [1/4] 检查设备...
adb devices
echo.
echo [2/4] 检查 APK...
if not exist "%APK%" (
    echo 找不到 %APK%
    echo 先运行: build-release.cmd assembleRelease
    exit /b 1
)
echo %APK%

echo.
echo [3/4] 安装（覆盖安装，保留数据）...
adb install -r "%APK%"
if errorlevel 1 (
    echo.
    echo 系统不允许后台拉起时，可用下面的命令手动启动：
    echo   adb shell am start -n com.hikwatch.viewer/.ui.MainActivity
    exit /b 1
)

echo.
echo [4/4] 拉起应用...
adb shell am start -n com.hikwatch.viewer/.ui.MainActivity
echo.
echo 完成。若手表没弹出画面，检查：设置 - 关于手表 - 连点版本号 - 开发者选项 - USB 调试。
endlocal
