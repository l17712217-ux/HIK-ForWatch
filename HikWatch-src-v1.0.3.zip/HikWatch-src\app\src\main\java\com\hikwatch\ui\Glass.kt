package com.hikwatch.ui

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import kotlin.math.max

/**
 * 液态玻璃面板：
 * 1) 半透明纵向渐变（上亮下暗，模拟玻璃厚度）
 * 2) 左上角镜面高光（radial，像玻璃边缘的反光）
 * 3) 底部内阴影（让面板"嵌"进背景）
 * 4) 1dp 渐变描边 + 顶部一道高光横线
 * 5) 圆角轮廓，可供投影
 */
class GlassPanelDrawable(
    private val radiusPx: Float,
    private val baseColor: Int,
    private val strokeColor: Int = 0,
    private val strokeWidthPx: Float = 0f,
    private val density: Float = Resources.getSystem().displayMetrics.density,
    /** 纵向渐变顶部相对基色的提亮量，实底面板用小值，避免叠成灰白 */
    private val topLift: Int = 46,
    /** 镜面高光强度（0..255），实底面板适当压低 */
    private val specularAlpha: Int = 70
) : Drawable() {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val specularPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val rect = RectF()
    private val cachedBounds = Rect()
    private var fillShader: Shader? = null
    private var specularShader: Shader? = null
    private var shadeShader: Shader? = null
    private var borderShader: Shader? = null
    private var shineShader: Shader? = null

    private fun dp(value: Float) = value * density

    override fun draw(canvas: Canvas) {
        val area = bounds
        if (area.width() <= 0 || area.height() <= 0) return
        if (cachedBounds != area) {
            cachedBounds.set(area)
            buildShaders(area)
        }

        rect.set(area.left.toFloat(), area.top.toFloat(), area.right.toFloat(), area.bottom.toFloat())
        path.reset()
        path.addRoundRect(rect, radiusPx, radiusPx, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(path)

        fillPaint.shader = fillShader
        canvas.drawRect(rect, fillPaint)

        specularPaint.shader = specularShader
        canvas.drawRect(rect, specularPaint)

        shadePaint.shader = shadeShader
        canvas.drawRect(rect, shadePaint)

        canvas.restore()

        if (area.width() > dp(26f)) {
            shinePaint.strokeWidth = dp(1.1f)
            shinePaint.shader = shineShader
            val inset = max(radiusPx * 0.8f, dp(7f))
            canvas.drawLine(
                area.left + inset, area.top + dp(0.7f),
                area.right - inset, area.top + dp(0.7f),
                shinePaint
            )
        }

        borderPaint.strokeWidth = if (strokeWidthPx > 0f) strokeWidthPx else dp(1f)
        if (strokeColor != 0) {
            borderPaint.shader = null
            borderPaint.color = strokeColor
        } else {
            borderPaint.shader = borderShader
        }
        canvas.drawPath(path, borderPaint)

        fillPaint.shader = null
        specularPaint.shader = null
        shadePaint.shader = null
        borderPaint.shader = null
        shinePaint.shader = null
    }

    private fun buildShaders(area: Rect) {
        val alpha = Color.alpha(baseColor)
        val width = area.width().toFloat()
        val height = area.height().toFloat()

        val top = Color.argb(
            alpha,
            (Color.red(baseColor) + topLift).coerceAtMost(255),
            (Color.green(baseColor) + (topLift + 4)).coerceAtMost(255),
            (Color.blue(baseColor) + (topLift + 18)).coerceAtMost(255)
        )
        val bottom = Color.argb(
            alpha,
            (Color.red(baseColor) - 10).coerceAtLeast(0),
            (Color.green(baseColor) - 6).coerceAtLeast(0),
            Color.blue(baseColor)
        )
        fillShader = LinearGradient(
            0f, area.top.toFloat(), 0f, area.bottom.toFloat(),
            top, bottom, Shader.TileMode.CLAMP
        )

        specularShader = RadialGradient(
            area.left + width * 0.26f,
            area.top + height * 0.06f,
            max(width, height) * 0.92f,
            intArrayOf(
                Color.argb(specularAlpha, 255, 255, 255),
                Color.argb(0, 255, 255, 255)
            ),
            null, Shader.TileMode.CLAMP
        )

        shadeShader = LinearGradient(
            0f, area.top + height * 0.55f, 0f, area.bottom.toFloat(),
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(44, 0, 0, 0)),
            null, Shader.TileMode.CLAMP
        )

        // 液态玻璃边缘光：上沿强高光、中段近乎透明、下沿一道折射回光
        borderShader = LinearGradient(
            0f, area.top.toFloat(), 0f, area.bottom.toFloat(),
            intArrayOf(
                Color.argb(150, 255, 255, 255),
                Color.argb(34, 255, 255, 255),
                Color.argb(12, 255, 255, 255),
                Color.argb(84, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.32f, 0.68f, 1f),
            Shader.TileMode.CLAMP
        )

        shineShader = LinearGradient(
            area.left.toFloat(), 0f, area.right.toFloat(), 0f,
            intArrayOf(
                Color.argb(0, 255, 255, 255),
                Color.argb(96, 255, 255, 255),
                Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun setAlpha(alpha: Int) {
        // 由 baseColor 的 alpha 控制
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        borderPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radiusPx)
    }
}

/** 模糊工具：降采样 + 多次盒式模糊，等效于高斯，适合小尺寸背景图。 */
object Glass {

    fun blur(source: Bitmap, radius: Int): Bitmap {
        if (radius <= 0) return source
        val width = source.width
        val height = source.height
        if (width < 2 || height < 2) return source
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)
        val buffer = IntArray(pixels.size)
        var a = pixels
        var b = buffer
        repeat(2) {
            boxBlurHorizontal(a, b, width, height, radius)
            boxBlurVertical(b, a, width, height, radius)
        }
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, width, 0, 0, width, height)
        return out
    }

    private fun boxBlurHorizontal(src: IntArray, dst: IntArray, width: Int, height: Int, radius: Int) {
        val divisor = 2 * radius + 1
        for (y in 0 until height) {
            val row = y * width
            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0
            for (offset in -radius..radius) {
                val color = src[row + offset.coerceIn(0, width - 1)]
                sumA += (color ushr 24) and 0xFF
                sumR += (color ushr 16) and 0xFF
                sumG += (color ushr 8) and 0xFF
                sumB += color and 0xFF
            }
            for (x in 0 until width) {
                dst[row + x] = ((sumA / divisor) shl 24) or
                    ((sumR / divisor) shl 16) or
                    ((sumG / divisor) shl 8) or
                    (sumB / divisor)
                val outColor = src[row + (x - radius).coerceIn(0, width - 1)]
                val inColor = src[row + (x + radius + 1).coerceIn(0, width - 1)]
                sumA += ((inColor ushr 24) and 0xFF) - ((outColor ushr 24) and 0xFF)
                sumR += ((inColor ushr 16) and 0xFF) - ((outColor ushr 16) and 0xFF)
                sumG += ((inColor ushr 8) and 0xFF) - ((outColor ushr 8) and 0xFF)
                sumB += (inColor and 0xFF) - (outColor and 0xFF)
            }
        }
    }

    private fun boxBlurVertical(src: IntArray, dst: IntArray, width: Int, height: Int, radius: Int) {
        val divisor = 2 * radius + 1
        for (x in 0 until width) {
            var sumA = 0
            var sumR = 0
            var sumG = 0
            var sumB = 0
            for (offset in -radius..radius) {
                val color = src[offset.coerceIn(0, height - 1) * width + x]
                sumA += (color ushr 24) and 0xFF
                sumR += (color ushr 16) and 0xFF
                sumG += (color ushr 8) and 0xFF
                sumB += color and 0xFF
            }
            for (y in 0 until height) {
                dst[y * width + x] = ((sumA / divisor) shl 24) or
                    ((sumR / divisor) shl 16) or
                    ((sumG / divisor) shl 8) or
                    (sumB / divisor)
                val outColor = src[(y - radius).coerceIn(0, height - 1) * width + x]
                val inColor = src[(y + radius + 1).coerceIn(0, height - 1) * width + x]
                sumA += ((inColor ushr 24) and 0xFF) - ((outColor ushr 24) and 0xFF)
                sumR += ((inColor ushr 16) and 0xFF) - ((outColor ushr 16) and 0xFF)
                sumG += ((inColor ushr 8) and 0xFF) - ((outColor ushr 8) and 0xFF)
                sumB += (inColor and 0xFF) - (outColor and 0xFF)
            }
        }
    }
}
