package com.hikwatch.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * 单路画面容器：TextureView（实时）或 ImageView（抓拍）。
 * 支持：画面比例（撑满/完整/16:9/4:3/自定义）、捏合缩放、双击、拖动、左右滑动切换、紧凑模式。
 */
@SuppressLint("ViewConstructor")
class VideoTile(context: Context) : FrameLayout(context) {

    val texture = TextureView(context)
    val image = ImageView(context)
    private val nameLabel = TextView(context)
    private val statusLabel = TextView(context)
    private val badgeLabel = TextView(context)

    private var videoAspect: Float = 16f / 9f

    /** true：画面完整落在圆屏内接区域（单路放大 + 完整画面时用） */
    var inscribed: Boolean = false

    /** 是否按「撑满」裁切（由 applyAspect 维护，保留旧字段兼容） */
    var fillScreen: Boolean = false

    var zoomEnabled: Boolean = false
    var swipeEnabled: Boolean = false
    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null

    /** +1 左滑（下一台），-1 右滑（上一台） */
    var onSwipe: ((Int) -> Unit)? = null

    /** 紧凑模式：6/9 宫格时隐藏名字，缩小状态字 */
    var compact: Boolean = false
        set(value) {
            field = value
            applyCompact()
        }

    private var aspectMode: String = "fill"
    private var ratio: Float = 0f

    private var scaleFactor = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var childWidth = 0
    private var childHeight = 0

    /** 手势进行中（双指缩放 / 放大后拖动）时置 true，外部可据此暂停背景抓帧 */
    var onGestureActive: ((Boolean) -> Unit)? = null
    private var gestureActive = false
    private var transformScheduled = false
    private var zoomAnimator: ValueAnimator? = null

    private val applyTransformTask = Runnable {
        transformScheduled = false
        applyTransform()
    }

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (!zoomEnabled) return false
                setGestureActive(true)
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (!zoomEnabled) return false
                val target = (scaleFactor * detector.scaleFactor).coerceIn(1f, 5f)
                applyScaleAround(detector.focusX, detector.focusY, target)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                setGestureActive(false)
            }
        }
    ).apply { isQuickScaleEnabled = false }

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onTap?.invoke()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                onLongPress?.invoke()
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!zoomEnabled) return false
                animateZoom(e.x, e.y, if (scaleFactor > 1.05f) 1f else 2.5f)
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (!zoomEnabled || scaleFactor <= 1.01f) return false
                setGestureActive(true)
                offsetX -= distanceX
                offsetY -= distanceY
                clampOffsets()
                postTransform()
                return true
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (!swipeEnabled || !zoomEnabled && scaleFactor > 1.05f) return false
                if (scaleFactor > 1.05f || e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dx) > abs(dy) * 1.6f && abs(dx) > Ui.dp(context, 30f)) {
                    onSwipe?.invoke(if (dx < 0) 1 else -1)
                    return true
                }
                return false
            }
        }
    )

    init {
        setBackgroundColor(Color.BLACK)
        clipChildren = true
        clipToPadding = true

        image.visibility = View.GONE
        image.scaleType = ImageView.ScaleType.MATRIX
        // v1.0.3：画面在容器内居中（原实现贴左上，非撑满比例时画面偏到左侧）
        addView(image, LayoutParams(1, 1, Gravity.CENTER))
        addView(texture, LayoutParams(1, 1, Gravity.CENTER))

        nameLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        nameLabel.setTextColor(Color.WHITE)
        nameLabel.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        nameLabel.maxLines = 1
        nameLabel.background = Ui.solid(Color.argb(120, 6, 10, 16), Ui.dp(context, 7f).toFloat())
        nameLabel.setPadding(
            Ui.dp(context, 6f), Ui.dp(context, 2f),
            Ui.dp(context, 6f), Ui.dp(context, 2f)
        )
        addView(
            nameLabel,
            LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply {
                leftMargin = Ui.dp(context, 7f)
                topMargin = Ui.dp(context, 6f)
            }
        )

        statusLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        statusLabel.setTextColor(Ui.TEXT2)
        statusLabel.gravity = Gravity.CENTER
        statusLabel.background = Ui.solid(Color.argb(96, 4, 7, 12), Ui.dp(context, 10f).toFloat())
        statusLabel.setPadding(
            Ui.dp(context, 8f), Ui.dp(context, 3f),
            Ui.dp(context, 8f), Ui.dp(context, 3f)
        )
        statusLabel.visibility = View.GONE
        addView(
            statusLabel,
            LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )

        badgeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8f)
        badgeLabel.setTextColor(Ui.WARN)
        badgeLabel.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        badgeLabel.visibility = View.GONE
        badgeLabel.background = Ui.solid(Color.argb(120, 6, 10, 16), Ui.dp(context, 7f).toFloat())
        badgeLabel.setPadding(
            Ui.dp(context, 5f), Ui.dp(context, 1f),
            Ui.dp(context, 5f), Ui.dp(context, 1f)
        )
        addView(
            badgeLabel,
            LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply {
                rightMargin = Ui.dp(context, 7f)
                topMargin = Ui.dp(context, 6f)
            }
        )
    }

    // ------------------------------------------------------------------ api

    fun setName(text: String) {
        nameLabel.text = text
    }

    fun setStatus(text: String) {
        statusLabel.text = text
        statusLabel.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    fun setBadge(text: String) {
        badgeLabel.text = text
        badgeLabel.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    /** 视频源宽高比（例如 1.777） */
    fun setSourceAspect(value: Float) {
        if (value <= 0.1f) return
        videoAspect = value
        requestLayout()
        applyChildLayout()
    }

    fun setAspect(value: Float) = setSourceAspect(value)

    /** 画面比例：fill / fit / 16:9 / 4:3 / custom */
    fun applyAspect(mode: String, custom: Float = 0f) {
        aspectMode = mode
        ratio = custom
        fillScreen = mode == "fill"
        requestLayout()
        applyChildLayout()
    }

    fun setLabelAnchor(anchor: Int) {
        if (compact) return
        val params = nameLabel.layoutParams as LayoutParams
        params.gravity = anchor
        val inset = Ui.dp(context, 8f)
        params.leftMargin = if (anchor and Gravity.END != 0) 0 else inset
        params.rightMargin = if (anchor and Gravity.END != 0) inset else 0
        params.topMargin = if (anchor and Gravity.BOTTOM != 0) 0 else inset
        params.bottomMargin = if (anchor and Gravity.BOTTOM != 0) inset else 0
        nameLabel.layoutParams = params
    }

    fun setActive(active: Boolean) {
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.BLACK)
            if (active) setStroke(Ui.dp(context, 1.5f), Ui.ACCENT)
        }
    }

    fun showSnapshot(bitmap: Bitmap) {
        image.setImageBitmap(bitmap)
        image.visibility = View.VISIBLE
        texture.visibility = View.INVISIBLE
        if (bitmap.width > 0 && bitmap.height > 0) {
            videoAspect = bitmap.width.toFloat() / bitmap.height
            applyChildLayout()
        }
    }

    fun showVideo() {
        image.visibility = View.GONE
        texture.visibility = View.VISIBLE
    }

    fun resetZoom() {
        scaleFactor = 1f
        offsetX = 0f
        offsetY = 0f
        applyTransform()
    }

    /** 当前缩放倍数（1.0 表示原始） */
    val zoomLevel: Float
        get() = scaleFactor

    /**
     * v1.0.3：表冠（旋转编码器）缩放。
     * [delta] 为 AXIS_SCROLL 的增量，正值放大、负值缩小。
     * 返回 false 表示当前状态不接受缩放（非单路 / 缩放下限且继续缩小）。
     */
    fun rotateZoom(delta: Float): Boolean {
        if (!zoomEnabled) return false
        if (delta == 0f || delta.isNaN()) return false
        val step = 0.085f
        val next = (scaleFactor * (1f + delta.coerceIn(-2f, 2f) * step)).coerceIn(1f, 5f)
        if (abs(next - scaleFactor) < 0.0005f) return false
        // 表冠缩放以画面中心为锚点，与双指焦点缩放共用同一套变换管线
        applyScaleAround(width / 2f, height / 2f, next)
        return true
    }

    /** 处理表冠滚动事件（视图自身收到时生效，Activity 也会主动转发） */
    @SuppressLint("ClickableViewAccessibility")
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (handleRotaryEvent(event)) return true
        return super.onGenericMotionEvent(event)
    }

    fun handleRotaryEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_SCROLL) return false
        val delta = rotaryDelta(event)
        if (delta == 0f) return false
        return rotateZoom(delta)
    }

    companion object {
        /**
         * 从滚动事件里取旋转增量。不同厂商（Wear OS / ColorOS Watch / 部分 MTK 方案）
         * 把表冠塞在不同的轴上，也可能不标 SOURCE_ROTARY_ENCODER，所以逐轴回退、不卡 source。
         */
        fun rotaryDelta(event: MotionEvent): Float {
            if (event.actionMasked != MotionEvent.ACTION_SCROLL) return 0f
            var delta = event.getAxisValue(MotionEvent.AXIS_SCROLL)
            if (delta == 0f) delta = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (delta == 0f) delta = event.getAxisValue(MotionEvent.AXIS_WHEEL)
            if (delta == 0f) delta = event.getAxisValue(MotionEvent.AXIS_HSCROLL)
            if (delta == 0f || delta.isNaN()) return 0f
            // 有的设备一次上报 ±3 甚至更大，统一压到 ±1，手感才稳定
            return delta.coerceIn(-1f, 1f)
        }
    }

    fun currentBitmap(): Bitmap? = runCatching {
        if (image.visibility == View.VISIBLE) {
            (image.drawable as? BitmapDrawable)?.bitmap
        } else {
            texture.bitmap
        }
    }.getOrNull()

    fun isShowingVideo(): Boolean = image.visibility != View.VISIBLE

    fun frameBitmap(maxSize: Int = 96): Bitmap? = runCatching {
        if (image.visibility == View.VISIBLE) {
            (image.drawable as? BitmapDrawable)?.bitmap
        } else {
            texture.getBitmap(maxSize, maxSize)
        }
    }.getOrNull()

    // -------------------------------------------------------------- layout

    private fun applyCompact() {
        nameLabel.visibility = if (compact) View.GONE else View.VISIBLE
        statusLabel.setTextSize(
            TypedValue.COMPLEX_UNIT_SP,
            if (compact) 8.5f else 10.5f
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyChildLayout()
    }

    private fun applyChildLayout() {
        val width = width
        val height = height
        if (width <= 0 || height <= 0) return
        val source = if (videoAspect > 0.1f) videoAspect else 16f / 9f

        var targetAspect = source
        var cover = false
        when (aspectMode) {
            "16:9" -> targetAspect = 16f / 9f
            "4:3" -> targetAspect = 4f / 3f
            "custom" -> if (ratio > 0.3f) targetAspect = ratio
            "fill" -> cover = true
        }

        var viewWidth: Int
        var viewHeight: Int
        if (cover) {
            viewWidth = width
            viewHeight = (width / source).toInt()
            if (viewHeight < height) {
                viewHeight = height
                viewWidth = (height * source).toInt()
            }
        } else if (inscribed) {
            val radius = min(width, height) / 2f
            val denominator = sqrt(targetAspect * targetAspect + 1.0).toFloat()
            val maxWidth = (2f * radius * targetAspect / denominator).toInt()
            val maxHeight = (2f * radius / denominator).toInt()
            viewWidth = min(width, maxWidth)
            viewHeight = (viewWidth / targetAspect).toInt()
            if (viewHeight > height || viewHeight > maxHeight) {
                viewHeight = min(height, maxHeight)
                viewWidth = (viewHeight * targetAspect).toInt()
            }
        } else {
            viewWidth = width
            viewHeight = (width / targetAspect).toInt()
            if (viewHeight > height) {
                viewHeight = height
                viewWidth = (height * targetAspect).toInt()
            }
        }

        if (viewWidth <= 0 || viewHeight <= 0) return
        childWidth = viewWidth
        childHeight = viewHeight
        for (view in arrayOf<View>(texture, image)) {
            val params = view.layoutParams as LayoutParams
            if (params.width != viewWidth || params.height != viewHeight) {
                params.width = viewWidth
                params.height = viewHeight
                view.layoutParams = params
            }
            // pivot 固定为画面中心，只需在尺寸变化时写一次（原来是每帧重设）
            view.pivotX = viewWidth / 2f
            view.pivotY = viewHeight / 2f
        }
        applyTransform()
    }

    private fun applyTransform() {
        if (childWidth <= 0 || childHeight <= 0) return
        transformScheduled = false
        applyTransformTo(texture)
        if (image.visibility == View.VISIBLE) applyTransformTo(image)
    }

    private fun applyTransformTo(view: View) {
        view.scaleX = scaleFactor
        view.scaleY = scaleFactor
        view.translationX = offsetX
        view.translationY = offsetY
    }

    /** 一帧只应用一次变换，避免双指移动中每来一个事件就重排一次 */
    private fun postTransform() {
        if (transformScheduled) return
        transformScheduled = true
        postOnAnimation(applyTransformTask)
    }

    /** 以手势焦点为锚点缩放：手指下的内容保持不动，缩放才跟手 */
    private fun applyScaleAround(focusX: Float, focusY: Float, target: Float) {
        val safeTarget = target.coerceIn(1f, 5f)
        val k = safeTarget / scaleFactor
        if (k <= 0f || abs(k - 1f) < 0.00005f) return
        // 子视图以自身中心为 pivot、并在容器中居中，所以变换轴心就是容器中心
        val cx = width / 2f
        val cy = height / 2f
        offsetX += (focusX - cx - offsetX) * (1f - k)
        offsetY += (focusY - cy - offsetY) * (1f - k)
        scaleFactor = safeTarget
        clampOffsets()
        postTransform()
    }

    /** 双击缩放：短动画过渡，避免硬跳变 */
    private fun animateZoom(focusX: Float, focusY: Float, target: Float) {
        zoomAnimator?.cancel()
        val start = scaleFactor
        val end = target.coerceIn(1f, 5f)
        if (abs(end - start) < 0.001f) return
        val anim = ValueAnimator.ofFloat(start, end)
        anim.duration = if (end > start) 190L else 150L
        anim.interpolator = DecelerateInterpolator(1.7f)
        anim.addUpdateListener { zoomAnimator ->
            val value = zoomAnimator.animatedValue as Float
            val k = value / scaleFactor
            if (k > 0f) {
                val cx = width / 2f
                val cy = height / 2f
                // 回到 1.0 时把偏移按比例收敛到 0，避免残留位移
                offsetX = if (end <= 1.001f) offsetX * k else offsetX + (focusX - cx - offsetX) * (1f - k)
                offsetY = if (end <= 1.001f) offsetY * k else offsetY + (focusY - cy - offsetY) * (1f - k)
                scaleFactor = value
                clampOffsets()
                postTransform()
            }
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (end <= 1.001f) {
                    offsetX = 0f
                    offsetY = 0f
                }
                clampOffsets()
                applyTransform()
            }
        })
        zoomAnimator = anim
        anim.start()
    }

    private fun setGestureActive(active: Boolean) {
        if (gestureActive == active) return
        gestureActive = active
        onGestureActive?.invoke(active)
    }

    private fun clampOffsets() {
        val maxX = (childWidth * (scaleFactor - 1f)) / 2f
        val maxY = (childHeight * (scaleFactor - 1f)) / 2f
        offsetX = offsetX.coerceIn(-maxX, maxX)
        offsetY = offsetY.coerceIn(-maxY, maxY)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                // 自己接管手势，避免被父容器抢走导致缩放中途断续
                parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                setGestureActive(false)
                // 手势结束时把还没落地的那一帧补齐
                if (transformScheduled) {
                    removeCallbacks(applyTransformTask)
                    applyTransform()
                }
            }
        }
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress && event.pointerCount <= 1) {
            gestureDetector.onTouchEvent(event)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        zoomAnimator?.cancel()
        removeCallbacks(applyTransformTask)
        setGestureActive(false)
        super.onDetachedFromWindow()
    }
}
