package com.hikwatch

import android.view.MotionEvent
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.hikwatch.ui.VideoTile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

/**
 * v1.0.3 回归测试：
 * 1) 表冠增量解析 —— Wear OS / ColorOS / MTK 各家用不同轴与 source，都要能取到
 * 2) 焦点缩放不变量 —— 缩放时手指下的画面内容不能跑
 * 3) 手势状态回调 —— 外部据此暂停背景抓帧
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33], qualifiers = "w240dp-h240dp-xhdpi")
class GestureCrownTest {

    private val context: android.content.Context = ApplicationProvider.getApplicationContext()

    private fun scrollEvent(axes: Map<Int, Float>, source: Int = 0): MotionEvent {
        val pc = MotionEvent.PointerCoords()
        axes.forEach { (axis, value) -> pc.setAxisValue(axis, value) }
        val props = MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_UNKNOWN
        }
        return MotionEvent.obtain(
            0L, 0L, MotionEvent.ACTION_SCROLL, 1,
            arrayOf(props), arrayOf(pc),
            0, 0, 1f, 1f, 0, 0, source, 0
        )
    }

    private fun tile(width: Int = 480, height: Int = 480): VideoTile {
        val t = VideoTile(context)
        t.zoomEnabled = true
        t.setSourceAspect(16f / 9f)
        t.applyAspect("fill", 0f)
        t.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
        )
        t.layout(0, 0, width, height)
        return t
    }

    private fun privateFloat(target: Any, name: String): Float {
        val f = target.javaClass.getDeclaredField(name)
        f.isAccessible = true
        return (f.get(target) as Float)
    }

    @Test
    fun rotaryDeltaReadsScrollAxis() {
        assertEquals(1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_SCROLL to 1f))), 0.001f)
        assertEquals(-1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_SCROLL to -1f))), 0.001f)
    }

    @Test
    fun rotaryDeltaFallsBackToVerticalWheelHorizontal() {
        // ColorOS / 部分方案把表冠放竖直轴，一次还会给 ±3
        assertEquals(1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_VSCROLL to 3f))), 0.001f)
        assertEquals(-1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_VSCROLL to -2f))), 0.001f)
        assertEquals(1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_WHEEL to 1f))), 0.001f)
        assertEquals(-1f, VideoTile.rotaryDelta(scrollEvent(mapOf(MotionEvent.AXIS_HSCROLL to -1f))), 0.001f)
    }

    @Test
    fun rotaryDeltaIgnoresEmptyAndNonScroll() {
        assertEquals(0f, VideoTile.rotaryDelta(scrollEvent(emptyMap())), 0.001f)
        val down = MotionEvent.obtain(0L, 0L, MotionEvent.ACTION_DOWN, 10f, 10f, 0)
        assertEquals(0f, VideoTile.rotaryDelta(down), 0.001f)
        down.recycle()
    }

    @Test
    fun rotaryDeltaWorksWithoutRotarySource() {
        // 关键回归：不再依赖 SOURCE_ROTARY_ENCODER
        val plain = scrollEvent(mapOf(MotionEvent.AXIS_SCROLL to 1f), source = 0)
        assertEquals(1f, VideoTile.rotaryDelta(plain), 0.001f)
    }

    @Test
    fun rotateZoomClampsBetweenOneAndFive() {
        val t = tile()
        repeat(200) { t.rotateZoom(1f) }
        assertEquals(5f, t.zoomLevel, 0.01f)
        repeat(400) { t.rotateZoom(-1f) }
        assertEquals(1f, t.zoomLevel, 0.01f)
    }

    @Test
    fun focusedZoomKeepsContentUnderFinger() {
        val t = tile()
        val width = 480f
        val height = 480f
        val focusX = width / 2f + 18f
        val focusY = height / 2f - 12f

        val scaleField = t.javaClass.getDeclaredField("scaleFactor").apply { isAccessible = true }
        scaleField.set(t, 1.4f)

        // 先把画面挪一点，模拟拖动后的状态
        val offsetXField = t.javaClass.getDeclaredField("offsetX").apply { isAccessible = true }
        val offsetYField = t.javaClass.getDeclaredField("offsetY").apply { isAccessible = true }
        offsetXField.set(t, 6f)
        offsetYField.set(t, -4f)

        val before = contentPointAt(t, focusX, focusY, width, height)
        val apply = t.javaClass.getDeclaredMethod(
            "applyScaleAround", Float::class.javaPrimitiveType,
            Float::class.javaPrimitiveType, Float::class.javaPrimitiveType
        )
        apply.isAccessible = true
        apply.invoke(t, focusX, focusY, 2.1f)
        val after = contentPointAt(t, focusX, focusY, width, height)

        assertEquals(2.1f, t.zoomLevel, 0.01f)
        assertEquals("焦点处内容 X 不应漂移", before.first, after.first, 0.6f)
        assertEquals("焦点处内容 Y 不应漂移", before.second, after.second, 0.6f)
    }

    /** 焦点 (fx,fy) 下方的内容坐标（以子视图中心为原点、未缩放单位） */
    private fun contentPointAt(t: VideoTile, fx: Float, fy: Float, w: Float, h: Float): Pair<Float, Float> {
        val s = privateFloat(t, "scaleFactor")
        val ox = privateFloat(t, "offsetX")
        val oy = privateFloat(t, "offsetY")
        return Pair((fx - w / 2f - ox) / s, (fy - h / 2f - oy) / s)
    }

    @Test
    fun gestureCallbackFires() {
        val t = tile()
        var last: Boolean? = null
        t.onGestureActive = { last = it }
        val method = t.javaClass.getDeclaredMethod("setGestureActive", Boolean::class.javaPrimitiveType)
        method.isAccessible = true
        method.invoke(t, true)
        assertEquals(true, last)
        method.invoke(t, false)
        assertEquals(false, last)
    }

    @Test
    fun zoomDisabledIgnoresCrown() {
        val t = tile()
        t.zoomEnabled = false
        assertFalse(t.rotateZoom(1f))
        assertEquals(1f, t.zoomLevel, 0.001f)
    }
}
